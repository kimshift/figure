### 项目结构

- client:vue 前端部分
- server:node 服务端

### 技术栈

1. node-->http,异常
2. node 框架：express
3. json-web-token 校验账号
4. mysql 的使用，了解
5. ORM,sequelize 使用<npx sequelize db:migrate>
6. axios 前后端数据交互
7. 前端引入 vue.js element

### 部署项目相关操作

1. 该项目使用的是 MySQL 数据库，先要在本地先创建数据库

2. 将所给的导入本地数据库使用(**管理员账号：admin,密码：123456**)

3. 修改 server/db/config/config.json 文件中的数据库连接配置

   ```json
   "username"://MySQL数据库的用户名
   "password"://MySQL数据库的密码
   "database"://本地创建的数据库名
   ```

4. 数据库迁移

```shell
npx sequelize-cli db:migrate
```

### 安装依赖

```shell
#安装后端依赖
cd server   //进入server目录
npm install //安装依赖
```

```shell
#安装前端依赖
cd  client  //进入client目录
npm install //安装依赖
```

### 启动服务

```shell
#启动后端服务器
cd server //进入server目录
npm run serve //启动服务
```

```shell
#启动前端服务器
cd client //进入client目录
npm run serve //启动服务
```
