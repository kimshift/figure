/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 50729
 Source Host           : localhost:3306
 Source Schema         : lost_found_new

 Target Server Type    : MySQL
 Target Server Version : 50729
 File Encoding         : 65001

 Date: 17/05/2024 15:49:29
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cates
-- ----------------------------
DROP TABLE IF EXISTS `cates`;
CREATE TABLE `cates`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cateName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `introduce` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of cates
-- ----------------------------
INSERT INTO `cates` VALUES (1, '日用类', '生活用品');
INSERT INTO `cates` VALUES (2, '证件类', '各种证件');
INSERT INTO `cates` VALUES (3, '现金类', '各种现金');
INSERT INTO `cates` VALUES (4, '电子类', '数码产品');
INSERT INTO `cates` VALUES (5, '书籍类', '各种书籍');

-- ----------------------------
-- Table structure for claims
-- ----------------------------
DROP TABLE IF EXISTS `claims`;
CREATE TABLE `claims`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NULL DEFAULT NULL,
  `goodsId` int(11) NULL DEFAULT NULL,
  `type` int(11) NULL DEFAULT NULL,
  `createTime` datetime NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `explain` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `distribution` int(11) NULL DEFAULT NULL,
  `nikeName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `introduce` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `examineStatus` int(11) NULL DEFAULT NULL,
  `opinion` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `claimStatus` int(11) NULL DEFAULT NULL,
  `status1` int(11) NULL DEFAULT NULL,
  `status2` int(11) NULL DEFAULT NULL,
  `status3` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of claims
-- ----------------------------
INSERT INTO `claims` VALUES (1, 5, 6, 0, '2024-04-10 01:21:23', '\\uploads\\apply\\upload_9ab245d104c47e649b7ceb0b3aa02a37.jpg', '1313', 0, '小张', '15325468958', '江西南昌', '123', 0, NULL, 0, 1, 1, 1);
INSERT INTO `claims` VALUES (2, 5, 7, 0, '2024-04-10 01:23:38', '\\uploads\\apply\\upload_02f0d3ee5dcd20ab7ed0cc997cc6791d.jpg', '12431', 0, '小陈', '15906696689', '江西赣州', '3124', 2, '请补充材料', 0, 1, 1, 1);
INSERT INTO `claims` VALUES (3, 5, 9, 1, '2024-04-10 01:25:15', '\\uploads\\apply\\upload_2d01c4af18faa5838948bdbc9ef65081.jpeg', '5252', 0, '小李', '18306696689', '江西余干', '2524', 1, '好的', 2, 1, 1, 1);
INSERT INTO `claims` VALUES (4, 5, 10, 1, '2024-04-10 01:30:22', '\\uploads\\apply\\upload_fde06e1c599286ce0e9904a079722506.jpeg', '1111', 0, '小王', '18806696689', '江西上饶', '333', -1, '不行', -1, 1, 1, 1);
INSERT INTO `claims` VALUES (5, 3, 3, 0, '2024-04-10 01:32:00', '\\uploads\\apply\\upload_3cd99d6eb80b19b5f7eba521e673de19.jpg', '1111', 0, '李四', '15104990525', '江西婺源', '1111', 1, '好', 1, 1, 1, 1);
INSERT INTO `claims` VALUES (6, 3, 2, 0, '2024-04-10 01:32:47', '\\uploads\\apply\\upload_7cb0f5b577e859372b27f975f2a6aa4a.jpg', '23234', 1, '李五', '18104990525', '江西龙南', '222', 1, NULL, 1, 1, 1, 1);
INSERT INTO `claims` VALUES (7, 3, 5, 1, '2024-04-10 01:33:31', '\\uploads\\apply\\upload_eadd9674afb98bc765bfd3f587081c14.jpg', '6547', 1, '李六', '1522436188', '江西九江', '543', 2, '修改地址', 0, 1, 1, 1);
INSERT INTO `claims` VALUES (8, 3, 4, 1, '2024-04-10 01:34:06', '\\uploads\\apply\\upload_6ad8b379ae8e5669e3fe8fc076a8dd2e.jpg', '87697', 0, '李七', '15922436189', '江西吉安', '352345', 2, '修改名字', 0, 1, 1, 1);
INSERT INTO `claims` VALUES (10, 2, 2, 0, '2024-04-10 15:53:10', '\\uploads\\apply\\upload_263b2109982299a41c836209a83052a4.jpg', '要吗', 1, '张三', '15322436186', '江西宜春', '999', -1, '该物品已被别人认领/寻回', -1, 1, 1, 1);
INSERT INTO `claims` VALUES (11, 1, 12, 0, '2024-04-18 15:24:58', '\\uploads\\apply\\upload_4b41a1e6d245b0ef9dd93b6727d896f0.jpg', 'efs', 0, 'joen', '15642345684', 'sf', 'sf', 1, '', 2, -1, 1, 1);

-- ----------------------------
-- Table structure for forumcommentreply
-- ----------------------------
DROP TABLE IF EXISTS `forumcommentreply`;
CREATE TABLE `forumcommentreply`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `reply_uid` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of forumcommentreply
-- ----------------------------

-- ----------------------------
-- Table structure for forumcomments
-- ----------------------------
DROP TABLE IF EXISTS `forumcomments`;
CREATE TABLE `forumcomments`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of forumcomments
-- ----------------------------
INSERT INTO `forumcomments` VALUES (4, 1, 1, '777888', '2024-05-14 17:34:06');
INSERT INTO `forumcomments` VALUES (5, 1, 1, '九命', '2024-05-16 17:08:53');
INSERT INTO `forumcomments` VALUES (6, 1, 1, '噼里啪啦', '2024-05-16 17:09:45');

-- ----------------------------
-- Table structure for forumposts
-- ----------------------------
DROP TABLE IF EXISTS `forumposts`;
CREATE TABLE `forumposts`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of forumposts
-- ----------------------------
INSERT INTO `forumposts` VALUES (1, 1, '测试', '123', '2024-05-13 17:54:46');

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `goodsName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cateId` int(11) NOT NULL,
  `introduce` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `createTime` datetime NULL DEFAULT NULL,
  `updateTime` datetime NULL DEFAULT NULL,
  `type` int(11) NULL DEFAULT NULL,
  `claimStatus` int(11) NULL DEFAULT NULL,
  `findStatus` int(11) NULL DEFAULT NULL,
  `need` int(11) NULL DEFAULT NULL,
  `status` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES (1, 5, '小音响', 4, '1111', '\\uploads\\goods\\upload_e3d9151f4eb36e9a1647364fb64ac59f.jpg', '2024-04-10 00:54:09', '2024-04-10 00:54:09', 0, -1, 0, 1, 1);
INSERT INTO `goods` VALUES (2, 5, '蓝牙耳机', 4, '222', '\\uploads\\goods\\upload_9891a9c4fe63fbb7eda9347ddefc45e2.jpg', '2024-04-10 00:54:37', '2024-05-03 23:06:46', 0, -1, 1, 0, 1);
INSERT INTO `goods` VALUES (3, 5, '新华字典', 5, '的好地方', '\\uploads\\goods\\upload_0d190bdebdee4ec124d0754e315afbfb.jpg', '2024-04-10 00:54:57', '2024-05-03 23:07:00', 0, -1, 1, 0, 1);
INSERT INTO `goods` VALUES (4, 5, 'iphone x', 4, '3454235', '\\uploads\\goods\\upload_2ca853ef96faedb1f57ea595b1239e42.jpg', '2024-04-10 00:55:23', '2024-05-03 23:15:05', 1, 0, -1, 0, 1);
INSERT INTO `goods` VALUES (5, 5, '四级真题', 5, 'qwer', '\\uploads\\goods\\upload_dfde244b4c6ee4cec628ecc284707eaa.jpg', '2024-04-10 00:56:02', '2024-05-03 23:14:29', 1, 0, -1, 0, 1);
INSERT INTO `goods` VALUES (6, 1, '尼康相机', 4, '443432', '\\uploads\\goods\\upload_5e346e2b172527d796728c90ea38c796.jpg', '2024-04-10 00:57:14', '2024-05-03 23:16:33', 0, -1, 0, 1, 1);
INSERT INTO `goods` VALUES (7, 1, '有线运动耳机', 4, '2542', '\\uploads\\goods\\upload_f1989e4602b78313cb724dc0fd16e140.jpg', '2024-04-10 00:57:48', '2024-05-03 23:07:29', 0, -1, 0, 0, 1);
INSERT INTO `goods` VALUES (8, 1, '头戴耳机', 4, '124', '\\uploads\\goods\\upload_a81491e83a55ebd774abf9f8355a1627.jpg', '2024-04-10 00:58:42', '2024-05-03 23:13:29', 1, 0, -1, 0, 1);
INSERT INTO `goods` VALUES (9, 1, '帆布鞋', 1, '253425', '\\uploads\\goods\\upload_8a7608fc67f97da5992663f8c180590f.jpg', '2024-04-10 00:59:18', '2024-05-03 23:13:01', 1, 1, -1, 0, 1);
INSERT INTO `goods` VALUES (10, 1, '方便面', 1, '4356436', '\\uploads\\goods\\upload_258c29b5ec3dd6e5fa9a59738e49eb6b.jpg', '2024-04-10 00:59:38', '2024-05-03 23:12:50', 1, 0, -1, 0, 1);
INSERT INTO `goods` VALUES (12, 6, '剃须刀', 1, 'hhhhhhh', '\\uploads\\goods\\upload_b4ff878c25cf90a1129d3678c13218e0.jpg', '2024-04-18 15:23:39', '2024-05-03 23:08:19', 0, -1, 1, 0, 1);
INSERT INTO `goods` VALUES (13, 7, '小米11', 4, '111111', '\\uploads\\goods\\upload_2de237bda59e745487360efe9d31ed0e.jpg', '2024-05-03 21:14:29', '2024-05-03 21:14:29', 0, -1, 0, 0, 1);
INSERT INTO `goods` VALUES (15, 1, '显卡', 4, '4090', '\\uploads\\goods\\upload_eb49ce569018fccb19092aa0288a8d8b.jpg', '2024-05-03 23:12:06', '2024-05-03 23:12:06', 0, -1, 0, 1, 1);
INSERT INTO `goods` VALUES (16, 7, '口红', 1, '13543', '\\uploads\\goods\\upload_915a89eb1ad4baabb06cfab28e5cecd2.jpg', '2024-05-03 23:18:01', '2024-05-03 23:18:01', 1, 0, -1, 0, 1);
INSERT INTO `goods` VALUES (17, 6, '拖鞋', 1, '拖鞋', '\\uploads\\goods\\upload_109a0fd25bcb11c17de2dc26ad1c1682.jpg', '2024-05-04 00:37:25', '2024-05-04 00:37:25', 0, -1, 0, 0, 1);

-- ----------------------------
-- Table structure for infos
-- ----------------------------
DROP TABLE IF EXISTS `infos`;
CREATE TABLE `infos`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `nikeName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` int(11) NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `authImage` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `status` int(11) NULL DEFAULT NULL,
  `opinion` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of infos
-- ----------------------------
INSERT INTO `infos` VALUES (1, 1, '小王', '\\uploads\\image\\upload_c06e40de5548d321762dc6c11ea41dfa.jpg', '15049905253', 1, '江西赣州', NULL, 1, NULL);
INSERT INTO `infos` VALUES (2, 2, '张三', '\\uploads\\image\\upload_f64aecb71c10a98b5161998c91340ed3.jpg', '15104990521', 1, '江西南昌', '\\uploads\\auth\\upload_bec47d3a00278209e3216cd61addbf73.png', 1, '');
INSERT INTO `infos` VALUES (3, 3, '李四', '\\uploads\\image\\upload_6ac3a439bcb2bf01baba37836cfe9636.jpg', '18104990522', 0, '江西九江', '\\uploads\\auth\\upload_c0c9fb7322ecbe9fb9799401ad3539eb.png', 1, '');
INSERT INTO `infos` VALUES (4, 4, '王五', NULL, '19104990523', 1, '江西余干', NULL, 0, NULL);
INSERT INTO `infos` VALUES (5, 5, '赵六', '\\uploads\\image\\upload_520b164f8c441dd54925fb22d0f6e503.jpg', '17306696699', 1, '江西丰城', '\\uploads\\auth\\upload_ecc10e90a454c3945a00fbd4e19c65a2.png', 1, '');
INSERT INTO `infos` VALUES (6, 6, 'jay', '\\uploads\\image\\upload_ab2bd1b6b58f6060e9552c09508b7564.png', '15912461528', 1, '万达广场', '\\uploads\\auth\\upload_8aa9022cc316bf0021b797d07db367d8.jpg', 1, '');
INSERT INTO `infos` VALUES (7, 7, '小赵', '\\uploads\\image\\upload_140ca7958a5a9affc9f38907637e9ad0.png', '15625465897', 1, '不知道', '\\uploads\\auth\\upload_c3dd54282b2b254a440fb08faf954b14.png', 1, '通过');

-- ----------------------------
-- Table structure for issues
-- ----------------------------
DROP TABLE IF EXISTS `issues`;
CREATE TABLE `issues`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `replyContent` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of issues
-- ----------------------------
INSERT INTO `issues` VALUES (1, 6, '一楼站位', NULL, '2024-05-17 10:49:16');
INSERT INTO `issues` VALUES (2, 6, '带好板凳来了', '坐好咯', '2024-05-17 10:51:06');

-- ----------------------------
-- Table structure for sequelizemeta
-- ----------------------------
DROP TABLE IF EXISTS `sequelizemeta`;
CREATE TABLE `sequelizemeta`  (
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`name`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sequelizemeta
-- ----------------------------
INSERT INTO `sequelizemeta` VALUES ('20240304105848-create-good.js');
INSERT INTO `sequelizemeta` VALUES ('20240304110822-create-cate.js');
INSERT INTO `sequelizemeta` VALUES ('20240314071728-create-info.js');
INSERT INTO `sequelizemeta` VALUES ('20240316083550-create-user.js');
INSERT INTO `sequelizemeta` VALUES ('20240319095007-create-slideshow.js');
INSERT INTO `sequelizemeta` VALUES ('20240329030112-create-claim.js');
INSERT INTO `sequelizemeta` VALUES ('20240506081336-add-author-to-forumposts.js');
INSERT INTO `sequelizemeta` VALUES ('20240506081340-add-author-to-forumcomments.js');
INSERT INTO `sequelizemeta` VALUES ('forumCommentReply.js');
INSERT INTO `sequelizemeta` VALUES ('forumComments.js');
INSERT INTO `sequelizemeta` VALUES ('forumPosts.js');
INSERT INTO `sequelizemeta` VALUES ('issues.js');

-- ----------------------------
-- Table structure for slideshows
-- ----------------------------
DROP TABLE IF EXISTS `slideshows`;
CREATE TABLE `slideshows`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goodsId` int(11) NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` int(11) NULL DEFAULT NULL,
  `introduce` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `status` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of slideshows
-- ----------------------------
INSERT INTO `slideshows` VALUES (2, NULL, '\\uploads\\carousel\\upload_8559885b6fcbd1e9d894f78aefe008e4.jpg', NULL, '没有关联', 0);
INSERT INTO `slideshows` VALUES (4, NULL, '\\uploads\\carousel\\upload_30cd771028e7038572b3e1be0fc7fc6c.png', NULL, '没有关联', 1);
INSERT INTO `slideshows` VALUES (5, NULL, '\\uploads\\carousel\\upload_7a43d723350f413f90ef415322f6389b.png', NULL, NULL, 1);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isAdmin` int(11) NULL DEFAULT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `status` int(11) NOT NULL,
  `createTime` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 1, 'admin', '00N00O00P00Q00R00S', 1, '2024-03-29 13:33:37');
INSERT INTO `users` VALUES (2, 0, 'zhangsan', '00N00O00P00Q00R00S', 1, '2024-03-30 09:06:11');
INSERT INTO `users` VALUES (3, 0, 'lisi', '00N00O00P00Q00R00S', 1, '2024-03-30 09:06:22');
INSERT INTO `users` VALUES (4, 0, 'wangwu', '00N00O00P00Q00R00S', 1, '2024-03-30 09:06:32');
INSERT INTO `users` VALUES (5, 0, 'zhaoliu', '00N00O00P00Q00R00S', 1, '2024-03-30 09:06:43');
INSERT INTO `users` VALUES (6, 0, 'test', '00N00O00P00Q00R00S', 1, '2024-04-17 17:29:19');
INSERT INTO `users` VALUES (7, 0, 'test1', '00N00O00P00Q00R00S', 1, '2024-05-03 19:59:50');

SET FOREIGN_KEY_CHECKS = 1;
