'use strict'
const { Model } = require('sequelize')
module.exports = (sequelize, DataTypes) => {
  class Claim extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // 在此处定义关联表
      models.Claim.belongsTo(models.User, {
        foreignKey: 'uid',
        targetKey: 'id',
      }) //关联用户表
      models.Claim.belongsTo(models.Good, {
        foreignKey: 'goodsId',
        targetKey: 'id',
      }) //关联物品表
    }
  }
  /* 认领-寻物对接记录表模型 */
  Claim.init(
    {
      uid: DataTypes.INTEGER, //失主/拾主 id
      goodsId: DataTypes.INTEGER, //失物/拾物 id
      type: DataTypes.INTEGER, //类型<0:还物申请,1:认领申请>
      createTime: DataTypes.DATE, //申请时间
      image: DataTypes.STRING, //申请材料
      explain: DataTypes.STRING, //申请说明
      distribution: DataTypes.INTEGER, //交接方式 <0:自取,1:邮寄 >
      nikeName: DataTypes.STRING, //失主/拾主姓名
      phone: DataTypes.STRING, //失主/拾主联系电话
      address: DataTypes.STRING, //失主/拾主备联系地址
      introduce: DataTypes.STRING, //失主/拾主备注
      examineStatus: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      }, //审核状态 <-1:不通过,0:待审核,1:通过,2:回退>
      opinion: DataTypes.STRING, //审核意见
      claimStatus: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      }, //交接状态 <-1:交接终止,0:交接暂停,1:交接中,2:交接完成>
      status1: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
      }, //数据状态 <1:正常,-1:管理员删除>
      status2: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
      }, //数据状态 <1:正常,-1:发布者删除>
      status3: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
      }, //数据状态 <1:正常,-1:申请者删除>
    },
    {
      sequelize,
      timestamps: false,
      modelName: 'Claim',
    }
  )
  return Claim
}
