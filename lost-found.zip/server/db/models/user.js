'use strict'
const { Model } = require('sequelize')
module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    // 原始查询语句
    //  const result = await sequelize.query('SELECT * FROM users', { model: User })
    static associate(models) {
      //在此处定义关联模型
      models.User.hasOne(models.Info, { foreignKey: 'uid' }) //关联用户信息表uid为外键
      models.User.hasMany(models.Good, { foreignKey: 'uid', sourceKey: 'id' }) //关联物品表
      models.User.hasMany(models.Claim, { foreignKey: 'uid', sourceKey: 'id' }) //认领/寻物对接表
    }
  }
  /* 用户表模型 */
  User.init(
    {
      username: DataTypes.STRING, //用户名
      password: DataTypes.STRING, //密码
      isAdmin: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      }, //是否是管理员
      createTime: DataTypes.DATE, //注册时间
      status: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
      }, //状态
    },
    {
      sequelize,
      modelName: 'User',
      timestamps: false, //让`createdAt`, `updatedAt`属性不自动添加
    }
  )
  return User
}
