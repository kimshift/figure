'use strict'
const { Model } = require('sequelize')
module.exports = (sequelize, DataTypes) => {
  class ForumComment extends Model {
    static associate(models) {
      // associations can be defined here
      ForumComment.belongsTo(models.User, { foreignKey: 'uid' })
      ForumComment.hasMany(models.ForumCommentReply, {
        foreignKey: 'comment_id',
        sourceKey: 'id',
      })
    }
  }
  ForumComment.init(
    {
      uid: DataTypes.INTEGER,
      post_id: DataTypes.INTEGER,
      content: DataTypes.TEXT,
      create_time: DataTypes.DATE,
    },
    {
      sequelize,
      modelName: 'ForumComment',
      timestamps: false,
    }
  )
  return ForumComment
}
