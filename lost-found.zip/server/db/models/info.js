'use strict'
const { Model } = require('sequelize')
module.exports = (sequelize, DataTypes) => {
  class Info extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // 多对一、一对一，属于
      models.Info.belongsTo(models.User, { foreignKey: 'uid', targetKey: 'id' }) //关联用户表
    }
  }
  /* 用户地址表模型 */
  Info.init(
    {
      uid: DataTypes.INTEGER, // 用户ID
      nikeName: {
        type: DataTypes.STRING,
        defaultValue: null,
      }, //姓名
      image: {
        type: DataTypes.STRING,
        defaultValue: null,
      }, //头像
      phone: {
        type: DataTypes.STRING,
        defaultValue: null,
      }, //联系方式
      sex: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
      }, //性别
      address: {
        type: DataTypes.STRING,
        defaultValue: null,
      }, //地址
      authImage: {
        type: DataTypes.STRING,
        defaultValue: null,
      }, //认证资料
      opinion: {
        type: DataTypes.STRING,
        defaultValue: null,
      }, //审核意见
      status: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      }, //认证状态
    },
    {
      sequelize,
      modelName: 'Info',
      timestamps: false,
    }
  )
  return Info
}
