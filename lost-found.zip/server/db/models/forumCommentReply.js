'use strict'
const { Model } = require('sequelize')
module.exports = (sequelize, DataTypes) => {
  class ForumCommentReply extends Model {
    static associate(models) {
      // associations can be defined here
      ForumCommentReply.belongsTo(models.User, { foreignKey: 'uid' })
      // forumCommentReply.belongsTo(models.ForumComment, {
      //   foreignKey: 'comment_id',
      //   targetKey: 'id',
      // })
    }
  }
  ForumCommentReply.init(
    {
      comment_id: DataTypes.INTEGER,
      uid: DataTypes.INTEGER,
      reply_uid: DataTypes.INTEGER,
      content: DataTypes.TEXT,
      create_time: DataTypes.DATE,
    },
    {
      sequelize,
      modelName: 'ForumCommentReply',
      tableName: 'forumcommentreply',
      timestamps: false,
    }
  )
  return ForumCommentReply
}
