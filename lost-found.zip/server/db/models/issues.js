'use strict'
const { Model } = require('sequelize')
module.exports = (sequelize, DataTypes) => {
  class Issues extends Model {
    static associate(models) {
      // associations can be defined here
      Issues.belongsTo(models.User, { foreignKey: 'uid' })
    }
  }
  Issues.init(
    {
      uid: DataTypes.INTEGER,
      content: DataTypes.TEXT,
      replyContent: {
        type: DataTypes.TEXT,
        defaultValue: null,
      },
      create_time: DataTypes.DATE,
    },
    {
      sequelize,
      modelName: 'Issues',
      tableName: 'issues',
      timestamps: false,
    }
  )
  return Issues
}
