'use strict'
const { Model } = require('sequelize')
module.exports = (sequelize, DataTypes) => {
  class Cate extends Model {
    static associate(models) {
      // define association here
      // 多对一
      models.Cate.hasMany(models.Good, {
        foreignKey: 'cateId',
        sourceKey: 'id'
      })
    }
  }
  /* 物品分类表模型 */
  Cate.init(
    {
      cateName: DataTypes.STRING, //分类名称
      introduce: DataTypes.STRING //描述
    },
    {
      sequelize,
      modelName: 'Cate',
      timestamps: false
    }
  )
  return Cate
}
