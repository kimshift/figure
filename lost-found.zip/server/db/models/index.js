'use strict';

const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');
const basename = path.basename(__filename);//当前文件名
const env = process.env.NODE_ENV || 'development';
const config = require(__dirname + '/../config/config.json')[env];//数据库配置
const db = {};

let sequelize;
// 利用Sequelize初始化建立数据库连接
// 实例化Sequelize时，需要传入数据库名、用户名和密码，还可以传入一个可选的options参数对象。
if (config.use_env_variable) {
  sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
  sequelize = new Sequelize(config.database, config.username, config.password, config);
}

//过滤且获取当前目录下的模型:获取模型类
fs.readdirSync(__dirname).filter(file => {
  return (file.indexOf('.') !== 0) && (file !== basename) && (file.slice(-3) === '.js');
}).forEach(file => {
  const model = require(path.join(__dirname, file))(sequelize, Sequelize.DataTypes);
  db[model.name] = model;//将获取到的模型存储到db对象中
});

Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});
db.sequelize = sequelize;//导出实例化数据库
db.Sequelize = Sequelize;//导入Sequelize库

module.exports = db;
