'use strict'
const { Model } = require('sequelize')
module.exports = (sequelize, DataTypes) => {
  class ForumPost extends Model {
    static associate(models) {
      // associations can be defined here
      models.ForumPost.belongsTo(models.User, {
        foreignKey: 'uid',
        targetKey: 'id',
      }) //关联用户表
      ForumPost.hasMany(models.ForumComment, { foreignKey: 'post_id' })
    }
  }
  ForumPost.init(
    {
      uid: DataTypes.INTEGER,
      title: DataTypes.STRING,
      content: DataTypes.TEXT,
      create_time: DataTypes.DATE,
    },
    {
      sequelize,
      modelName: 'ForumPost',
      timestamps: false,
    }
  )
  return ForumPost
}
