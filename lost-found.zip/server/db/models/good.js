'use strict'
const { Model } = require('sequelize')
module.exports = (sequelize, DataTypes) => {
  class Good extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      models.Good.belongsTo(models.Cate, {
        foreignKey: 'cateId',
        targetKey: 'id',
      }) //关联分类表
      models.Good.belongsTo(models.User, { foreignKey: 'uid', targetKey: 'id' }) //关联用户表
      models.Good.hasMany(models.Claim, {
        foreignKey: 'goodsId',
        sourceKey: 'id',
      }) //关联认领-寻物对接表
      models.Good.hasMany(models.Slideshow, {
        foreignKey: 'goodsId',
        sourceKey: 'id',
      }) //关联轮播图
    }
  }
  /* 商品表模型 */
  Good.init(
    {
      uid: DataTypes.INTEGER, //发布者id
      goodsName: DataTypes.STRING, //物品名称
      cateId: DataTypes.INTEGER, //分类ID
      introduce: DataTypes.TEXT, //描述
      image: DataTypes.STRING, //图片
      createTime: DataTypes.DATE, //创建时间
      updateTime: DataTypes.DATE, //更新时间
      type: DataTypes.INTEGER, //物品类型
      claimStatus: {
        type: DataTypes.INTEGER,
        defaultValue: -1,
      }, //失物认领状态
      findStatus: {
        type: DataTypes.INTEGER,
        defaultValue: -1,
      }, //拾物认领状态
      need: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      }, //急需状态
      status: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
      }, //状态
    },
    {
      sequelize,
      timestamps: false,
      modelName: 'Good',
    }
  )
  return Good
}
