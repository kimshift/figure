'use strict'
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Goods', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      uid: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      goodsName: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      cateId: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      introduce: {
        allowNull: false,
        type: Sequelize.TEXT,
      },
      image: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      createTime: {
        type: Sequelize.DATE,
      },
      updateTime: {
        type: Sequelize.DATE,
      },
      type: {
        type: Sequelize.INTEGER,
      },
      claimStatus: {
        type: Sequelize.INTEGER,
      },
      findStatus: {
        type: Sequelize.INTEGER,
      },
      need: {
        type: Sequelize.INTEGER,
      },
      status: {
        type: Sequelize.INTEGER,
      },
    })
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Goods')
  },
}
