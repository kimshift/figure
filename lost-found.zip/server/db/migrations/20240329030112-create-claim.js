'use strict'
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Claims', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      uid: {
        type: Sequelize.INTEGER,
      },
      goodsId: {
        type: Sequelize.INTEGER,
      },
      type: {
        type: Sequelize.INTEGER,
      },
      createTime: {
        type: Sequelize.DATE,
      },
      image: {
        type: Sequelize.STRING,
      },
      explain: {
        type: Sequelize.STRING,
      },
      distribution: {
        type: Sequelize.INTEGER,
      },
      nikeName: {
        type: Sequelize.STRING,
      },
      phone: {
        type: Sequelize.STRING,
      },
      address: {
        type: Sequelize.STRING,
      },
      introduce: {
        type: Sequelize.STRING,
      },
      examineStatus: {
        type: Sequelize.INTEGER,
      },
      opinion: {
        type: Sequelize.STRING,
      },
      claimStatus: {
        type: Sequelize.INTEGER,
      },
      status1: {
        type: Sequelize.INTEGER,
      },
      status2: {
        type: Sequelize.INTEGER,
      },
      status3: {
        type: Sequelize.INTEGER,
      },
    })
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Claims')
  },
}
