import fs from 'fs'
/**
 *
 *用于判断路径目录是否存在， 如果不存在，则创建一个
 * @author piante
 * @date 23/03/2021
 * @param {*} absPath：文件路径
 * @return {*}
 */
export const mkdirPath = absPath => {
  try {
    fs.stat(absPath, (err, stats) => {
      if (!stats) {
        // 如果目录不存在则创建(支持递归创建 recursive: true)
        fs.mkdir(absPath, { recursive: true }, err => {
          if (err) throw err
        })
      } else {
        // console.log('文件创建的时间:', stats.birthtime.toLocaleString())
        // console.log('文件最后一次访问时间:', stats.atime.toLocaleString())
        // console.log('文件最后一次修改时间:', stats.mtime.toLocaleString())
      }
    })
    return true
  } catch (error) {}
}
/**
 *
 *用于判断路径目录是否存在， 如果不存在，则创建一个
 * @author piante
 * @date 23/03/2021
 * @param {*} filesPath:文件路径
 * @return {*}
 */
export const delPath = filesPath => {
  fs.stat(filesPath, (err, stats) => {
    if (stats) {
      // 如果路径存在则删除
      fs.unlink(filesPath, err => {
        if (err) throw err
        console.log('文件:' + filesPath + '删除成功！')
      })
    } else console.log(`${filesPath}文件不存在`)
  })
}
