/*******
 * @description: 校验空值参数:在判断参数是否为空时，希望把null,undefined,{},[],"",NaN这六类都判定为空
 * @author: Mr.Ye
 * @param {params} [需要校验的参数]
 * @return {*} [返回值：布尔值（空：true，非空：false）]
 */
export const isEmpty = (params) => {
  /* 检验字符串类型 */
  /* 空字符串/字符串null/字符串undefined/字符串{}/字符串[]==>判断为空 */
  const array = ['', 'null', 'undefined', '{}', '[]']
  if (array.some((element) => params === element)) return true
  if (params === 0 || params === 1) return false //过滤0/1
  if (!Boolean(params)) return true //校验undefined/null/NaN
  /* 检验空对象 */
  if (Array.prototype.isPrototypeOf(params) && params.length === 0) return true //检验空数组[]
  if (
    Object.prototype.isPrototypeOf(params) &&
    Object.keys(params).length === 0
  )
    return true //检验空对象{}
  /* 经过层层判断，确定为非空则返回true */
  return false
}
