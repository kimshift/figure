/*生成指定长度的随机数字*/
export const randomCode = length => {
  let result = ''
  let arr = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
  for (let i = 0; i < length; i++) {
    //随机生成一位0~9的数:index作为list的下标
    let index = Math.floor(Math.random() * 10)
    result += arr[index]
  }
  return result
}
