import path from 'path'
import { mkdirPath } from '../utils/file' //引入监听文件夹工具
const publicPath = path.join(__dirname, '../public') //静态资源存放文件夹
const uploadsGoodsPath = path.join(__dirname, '../public/uploads/goods') // 上传物品图片所放置的文件夹
const uploadsApplyPath = path.join(__dirname, '../public/uploads/apply') // 上传申请材料所放置的文件夹
const uploadsImgPath = path.join(__dirname, '../public/uploads/image') // 上传头像图片所放置的文件夹
const uploadsAuthImgPath = path.join(__dirname, '../public/uploads/auth') // 上传认证材料所放置的文件夹
const uploadsSlideshowPath = path.join(__dirname, '../public/uploads/carousel') // 上传轮播图所放置的文件夹
const arr = [
  uploadsGoodsPath,
  uploadsImgPath,
  uploadsAuthImgPath,
  uploadsApplyPath,
  uploadsSlideshowPath,
]
// 检测文件目录是否存在，不存在则创建
try {
  arr.forEach(element => mkdirPath(element))
} catch (e) {
  throw Error(e.msg)
}
module.exports = {
  publicPath,
  uploadsGoodsPath, // 上传物品图片所放置的文件夹
  uploadsApplyPath, // 上传申请材料所放置的文件夹
  uploadsImgPath, // 上传头像所放置的文件夹
  uploadsAuthImgPath, // 上传认证材料所放置的文件夹
  uploadsSlideshowPath, //上传轮播图所放置的文件夹
  port: 3000, // 后端服务监听端口号
  host: '127.0.0.1',
  jwt_config: {
    secretKey: 'www.kim-shift.cn', // jwt秘钥
    expiresIn: 86400, //1天：24*60*60 单位秒（jwt生命周期）
  },
}
