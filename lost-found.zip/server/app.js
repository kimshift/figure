const express = require('express')
const createError = require('http-errors')
const path = require('path')
// const bodyPaser = require("body-parser")
const mount = require('mount-routes') //挂载目录多个路由
const config = require('./config') //导入配置文件
const app = express() //创建express实例对象

app.use(express.json()) //解析json数据
app.use(express.urlencoded({ extended: true })) //解析x-ww-form-urlencoded请求体
app.use(express.static(config.publicPath)) //设置静态资源路径

// 设置跨域和相应数据格式
app.all('/api/*', function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*') //允许所有主机访问
  res.setHeader('Content-Type', 'application/json;charset=utf-8') //json数据格式
  res.header(
    'Access-Control-Allow-Headers',
    'Content-Type,Content-Length, Authorization, Accept,X-Requested-With'
  ) //添加响应头
  res.header('Access-Control-Allow-Methods', 'PUT,POST,GET,DELETE,OPTIONS') //允许的请求方式
  res.header('X-Powered-By', 'www.kim-shift.cn') //隐藏服务器框架
  if (req.method == 'OPTIONS') res.send(200)
  /*让options请求快速返回*/ else next()
})
// 初始化统一响应客户端机制
const responseData = require('./modules/responseData')
app.use(responseData)
//自动挂载routes目录下面的所有路由，以文件名称作为路由的根
mount(app, path.join(process.cwd(), '/routes'), false) //true输出所有路由到控制台

// 捕获404并转发到错误处理程序
app.use(function (req, res, next) {
  next(createError(404))
})
// 处理500错误
app.use((err, req, res, next) => {
  if (err) {
    const { referer, host } = req.headers
    const params = {
      referer,
      host,
      url: req.url,
      method: req.method
    }
    res.status(err.status || 500).json({
      code: err.status || 500,
      data: null,
      ...params,
      message: err.message
    })
    console.log('系统错误:', err.status, err.message)
  }
  next()
})
// 设置监听端口
app.listen(config.port, () => {
  console.log(`服务器启动成功:http://${config.host}:${config.port}`)
})
