/* 新增功能中间件 */
import models from '../db/models' //引入sequelize模型对数据库操作
import formidable from 'formidable' //解析formData对象
import { uploadsGoodsPath, uploadsSlideshowPath, uploadsApplyPath } from '../config' //引入上传文件路径配置
import { delPath } from '../utils/file' //删除文件函数

/* 物品分类新增功能模块中间件 */
export const createCate = async (req, res, next) => {
  try {
    if (!req.user.isAdmin) return res.sendResult(null, '权限不足', 500)
    let { cateName, introduce } = req.body
    if (!cateName) return res.sendResult(null, '参数错误', 500)
    let result = await models.Cate.findOrCreate({
      where: { cateName },
      defaults: {
        cateName,
        introduce,
      },
    })
    if (!result[1]) {
      return res.sendResult(null, '分类已存在', 500)
    }
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

/* 物品上架功能模块中间件 */
export const createGoods = async (req, res, next) => {
  try {
    // 创建formidable表单解析对象
    const form = new formidable.IncomingForm()
    // 设置客户端上传文件的存储路径
    form.uploadDir = uploadsGoodsPath
    // 保留上传文件的后缀名字
    form.keepExtensions = true
    // 解析客户端传递过来的FormData对象
    form.parse(req, async (err, fields, files) => {
      if (err) {
        return res.sendResult(null, '系统繁忙', 500)
      }
      const goodsInfo = JSON.parse(fields.goodsInfo)
      const image = files.image.path.split('public')[1]
      const createTime = new Date()
      const uid = req.user.id
      //返回值为数组，[json,created] 第一位是查询或创建的数据，第二位标识是否新建
      const result = await models.Good.findOrCreate({
        where: {
          uid,
          cateId: goodsInfo?.cateId,
          goodsName: goodsInfo?.goodsName,
          type: goodsInfo?.type,
        },
        defaults: {
          ...goodsInfo,
          uid,
          image,
          createTime,
          updateTime: createTime,
        },
      })
      if (!result[1]) {
        delPath(files.image.path)
        return res.sendResult(null, '物品已存在', 500)
      }
      next()
    })
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

/* 轮播图功能模块中间件 */
export const createSlideshow = async (req, res, next) => {
  try {
    // 创建formidable表单解析对象
    const form = new formidable.IncomingForm()
    // 设置客户端上传文件的存储路径
    form.uploadDir = uploadsSlideshowPath
    // 保留上传文件的后缀名字
    form.keepExtensions = true
    // 解析客户端传递过来的FormData对象
    form.parse(req, async (err, fields, files) => {
      if (err) {
        return res.sendResult(null, '系统繁忙', 500)
      }
      const slideshowInfo = JSON.parse(fields.slideshowInfo)
      const image = files.image.path.split('public')[1]
      //返回值为数组，[json,created] 第一位是查询或创建的数据，第二位标识是否新建
      const result = await models.Slideshow.findOrCreate({
        where: {
          image,
        },
        defaults: {
          ...slideshowInfo,
          image,
        },
      })
      if (!result[1]) {
        return res.sendResult(null, '轮播图已存在', 500)
      }
      next()
    })
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

/* 认领-还物申请功能模块中间件 */
export const createClaim = async (req, res, next) => {
  try {
    const uid = req.user.id //当前用户
    const claims = req.claims //申请表数据
    const goods = req.goods
    if (!goods) return res.sendResult(500, '参数错误', null)
    if (!goods.User || !goods.status) {
      return res.sendResult(500, '物品状态异常', null)
    }
    if (goods.uid == uid) {
      return res.sendResult(500, '不能申请自己发布的物品', null)
    }
    if (goods.claimStatus === 1) {
      return res.sendResult(500, '该物品已被认领了', null)
    }
    if (goods.findStatus === 1) {
      return res.sendResult(500, '该物品已寻回了', null)
    }
    if (claims) {
      return res.sendResult(null, `已有申请正在进行中，不能重复申请！`, 500)
    }
    const form = new formidable.IncomingForm() // 创建formidable表单解析对象
    form.uploadDir = uploadsApplyPath // 设置客户端上传文件的存储路径
    form.keepExtensions = true // 保留上传文件的后缀名字
    // 解析客户端传递过来的FormData对象
    form.parse(req, async (err, fields, files) => {
      if (err) {
        return res.sendResult(null, '系统繁忙', 500)
      }
      const claimInfo = JSON.parse(fields.claimInfo)
      const image = files.image.path.split('public')[1]
      const createTime = new Date()
      await models.Claim.create({ uid, createTime, image, ...claimInfo })
      next()
    })
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

/* 创建论坛帖子功能模块中间件 */
export const createForumPost = async (req, res, next) => {
  try {
    const { uid, title, content } = req.body
    if (!title || !content) return res.sendResult(null, '标题和内容不能为空', 400)

    const newPost = await models.ForumPost.create({
      uid,
      title,
      content,
      create_time: new Date(),
    })

    req.newPost = newPost
    next()
  } catch (error) {
    return res.sendResult(null, `创建帖子时发生错误: ${error.message}`, 500)
  }
}

/* 创建论坛评论功能模块中间件 */
export const createForumComment = async (req, res, next) => {
  try {
    const uid = req.user.id
    const { postId, content } = req.body
    if (!content) return res.sendResult(null, '评论内容不能为空', 400)
    const newComment = await models.ForumComment.create({
      uid,
      post_id: postId,
      content,
      create_time: new Date(),
    })
    req.newComment = newComment
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(null, '创建评论时发生错误', 500)
  }
}

export const createForumCommentReply = async (req, res, next) => {
  try {
    const uid = req.user.id
    await models.ForumCommentReply.create({
      uid,
      ...req.body,
      create_time: new Date(),
    })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(null, '回复评论时发生错误', 500)
  }
}

// 创建留言
export const createIssues = async (req, res, next) => {
  try {
    const uid = req.user.id
    await models.Issues.create({
      uid,
      ...req.body,
      create_time: new Date(),
    })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(null, '创建留言时发生错误', 500)
  }
}
