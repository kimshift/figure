/* 该中间件是修改操作模块中间件 */
import formidable from 'formidable'
import models from '../db/models'
const Op = models.Sequelize.Op
import { toCode, checkCode } from '../utils/encryption'
import { uploadsGoodsPath, uploadsSlideshowPath, uploadsApplyPath } from '../config'
import { delPath } from '../utils/file'
// 管理员重置密码
export const resetPwd = async (req, res, next) => {
  try {
    let { password, userList } = req.body
    password = toCode(password) //密码加密
    userList.forEach(async id => {
      await models.User.update({ password }, { where: { id } })
    })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 修改个人基本信息
export const updateInfo = async (req, res, next) => {
  try {
    const user = req.user //查询的用户数据
    const userInfo = req.body
    if (!user) return res.sendResult(null, '参数错误', 500)
    await models.Info.update(userInfo, { where: { uid: user.id } })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 修改账户密码
export const updatePwd = async (req, res, next) => {
  try {
    let user = req.user
    if (!user) return res.sendResult(null, '参数错误', 500)
    let { oldPassword, password, passwords } = req.body
    if (password !== passwords) {
      return res.sendResult(null, '两次密码不一致', 500)
    }
    //密码匹配:一致则返回true
    let isPasswordValid = checkCode(
      oldPassword, //请求数据
      user.password //数据库数据
    )
    if (!isPasswordValid) return res.sendResult(null, '原密码不正确', 500)
    if (oldPassword === password) {
      return res.sendResult(null, '新密码不能跟原密码一样', 500)
    }
    let news = await models.User.update({ password: toCode(password) }, { where: { id: user.id } })
    if (!news[0]) return res.sendResult(null, '系统繁忙', 500)
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 修改用户状态
export const updateUserStatus = async (req, res, next) => {
  try {
    let { id, status } = req.params
    await models.User.update({ status }, { where: { id } })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 审核数据
export const updateUserAuth = async (req, res, next) => {
  try {
    const { id } = req.params
    await models.Info.update({ ...req.body }, { where: { id } })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 修改物品状态
export const updateGoodsStatus = async (req, res, next) => {
  try {
    const { id, status } = req.params
    if (!req.goods) return res.sendResult(null, '参数错误', 500)
    if (req.goods.uid !== req.user.id && !req.user.isAdmin) {
      return res.sendResult(null, '权限不足！', 500)
    }
    await models.Good.update({ status }, { where: { id } })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 修改分类信息
export const updateCate = async (req, res, next) => {
  try {
    const { id } = req.params
    const cateInfo = req.body
    if (!cateInfo) return res.sendResult(null, '参数错误', 500)
    await models.Cate.update(cateInfo, { where: { id } })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 修改物品信息
export const updateGoodsInfo = async (req, res, next) => {
  try {
    if (!req.goods) return res.sendResult(null, '参数错误', 500)
    if (req.goods.uid !== req.user.id && !req.user.isAdmin) {
      return res.sendResult(null, '权限不足！', 500)
    }
    // 创建formidable表单解析对象
    const form = new formidable.IncomingForm()
    // 设置客户端上传文件的存储路径
    form.uploadDir = uploadsGoodsPath
    // 保留上传文件的后缀名字
    form.keepExtensions = true
    // 解析客户端传递过来的FormData对象
    form.parse(req, async (err, fields, files) => {
      if (err) {
        return res.sendResult(null, '系统繁忙', 500)
      }
      const goodsInfo = JSON.parse(fields.goodsInfo)
      if (files.image) {
        const oldImg = req.goods.image
        if (oldImg) {
          // 删除图片
          const filesPath = uploadsGoodsPath + oldImg.split('goods')[1]
          delPath(filesPath)
        }
        goodsInfo.image = files.image.path.split('public')[1]
      }
      goodsInfo.updateTime = new Date()
      await models.Good.update(goodsInfo, { where: { id: req.goods.id } })
      next()
    })
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 修改轮播图信息
export const updateSlideshowInfo = async (req, res, next) => {
  try {
    if (!req.slideshow) return res.sendResult(null, '参数错误', 500)
    // 创建formidable表单解析对象
    const form = new formidable.IncomingForm()
    // 设置客户端上传文件的存储路径
    form.uploadDir = uploadsSlideshowPath
    // 保留上传文件的后缀名字
    form.keepExtensions = true
    // 解析客户端传递过来的FormData对象
    form.parse(req, async (err, fields, files) => {
      if (err) {
        return res.sendResult(null, '系统繁忙', 500)
      }
      const slideshowInfo = JSON.parse(fields.slideshowInfo)
      if (files.image) {
        const oldImg = req.slideshow.image
        if (oldImg) {
          // 删除图片
          const filesPath = uploadsSlideshowPath + oldImg.split('carousel')[1]
          delPath(filesPath)
        }
        slideshowInfo.image = files.image.path.split('public')[1]
      }
      await models.Slideshow.update(slideshowInfo, {
        where: { id: req.slideshow.id },
      })
      next()
    })
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 修改轮播图状态
export const updateSlideshowStatus = async (req, res, next) => {
  try {
    let { id, status } = req.params
    await models.Slideshow.update({ status }, { where: { id } })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 修改申请状态
export const updateClaimStatus = async (req, res, next) => {
  try {
    const { id, goodsId, claimStatus, goodsStatus } = req.body
    await models.Claim.update({ claimStatus }, { where: { id } })
    if (claimStatus === 2) {
      await models.Good.update(goodsStatus, { where: { id: goodsId } }) //更新物品状态
      // 更新其他申请状态
      const params = {
        examineStatus: -1,
        opinion: '该物品已被别人认领/寻回',
        claimStatus: -1,
      }
      await models.Claim.update(params, {
        where: {
          id: { [Op.ne]: id },
          claimStatus: 0,
          goodsId,
        },
      })
    }
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 修改申请数据
export const updateClaimInfo = async (req, res, next) => {
  try {
    if (!req.claims) return res.sendResult(null, '参数错误', 500)
    // 创建formidable表单解析对象
    const form = new formidable.IncomingForm()
    // 设置客户端上传文件的存储路径
    form.uploadDir = uploadsApplyPath
    // 保留上传文件的后缀名字
    form.keepExtensions = true
    // 解析客户端传递过来的FormData对象
    form.parse(req, async (err, fields, files) => {
      if (err) {
        return res.sendResult(null, '系统繁忙', 500)
      }
      const claimInfo = JSON.parse(fields.claimInfo)
      if (files.image) {
        const oldImg = req.claims.image
        if (oldImg) {
          // 删除图片
          const filesPath = uploadsApplyPath + oldImg.split('apply')[1]
          delPath(filesPath)
        }
        claimInfo.image = files.image.path.split('public')[1]
      }
      claimInfo.examineStatus = 0 //重置审核状态
      claimInfo.opinion = null //重置审核意见
      await models.Claim.update(claimInfo, { where: { id: req.claims.id } })
      next()
    })
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 审核申请数据
export const authClaimInfo = async (req, res, next) => {
  try {
    const { id } = req.body
    await models.Claim.update({ ...req.body }, { where: { id } })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 回复留言
export const replyIssues = async (req, res, next) => {
  try {
    const { id, content } = req.body
    await models.Issues.update({ replyContent: content }, { where: { id } })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(null, '回复留言时发生错误', 500)
  }
}
