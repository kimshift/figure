/* 该中间件是删除操作模块中间件 */
import models from '../db/models'
import { uploadsGoodsPath, uploadsSlideshowPath, uploadsApplyPath } from '../config'
import { delPath } from '../utils/file'
/* 删除分类 */
export const removeCate = async (req, res, next) => {
  try {
    if (req.goods) {
      return res.sendResult(null, '该分类存在着关联商品，暂时不能删除!', 500)
    }
    const { id } = req.params
    const result = await models.Cate.destroy({ where: { id } })
    if (!result) return res.sendResult(null, '参数异常!', 500)
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
/* 逻辑删除商品：将商品状态改成-1;查询已自动过滤屏蔽 */
// 因为直接把商品从数据库中删除，如果订单中存在则会影响关联查询
export const removeGoods = async (req, res, next) => {
  try {
    const { id } = req.params
    if (!req.goods) return res.sendResult(null, '参数错误', 500)
    if (req.goods.uid !== req.user.id && !req.user.isAdmin) {
      return res.sendResult(null, '权限不足！', 500)
    }
    const { claimsIng, claimsOne } = req.claims
    if (claimsIng) {
      return res.sendResult(null, '申请流程进行中,暂时不能删除', 500)
    }
    if (claimsOne) {
      // 逻辑删除
      const result = await models.Good.update({ status: -1 }, { where: { id } })
      if (!result[0]) return res.sendResult(null, '参数异常!', 500)
      next()
    } else {
      // 彻底删除
      const oldImg = req.goods.image
      const result = await models.Good.destroy({ where: { id } })
      if (!result) return res.sendResult(null, '参数异常!', 500)
      if (oldImg) {
        // 删除物品图片
        const filesPath = uploadsGoodsPath + oldImg.split('goods')[1]
        delPath(filesPath)
      }
      next()
    }
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 删除轮播图
export const removeSlideshow = async (req, res, next) => {
  try {
    if (!req.user.isAdmin) return res.sendResult(null, '权限不足', 500)
    if (!req.slideshow) return res.sendResult(null, '参数异常', 500)
    const { id } = req.params
    const result = await models.Slideshow.destroy({ where: { id } })
    if (!result) return res.sendResult(null, '参数异常!', 500)
    const oldImg = req.slideshow.image
    if (oldImg) {
      // 删除图片
      const filesPath = uploadsSlideshowPath + oldImg.split('carousel')[1]
      delPath(filesPath)
    }
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

/* 删除认领申请数据 */
export const removeClaimInfo = async (req, res, next) => {
  try {
    const { id, status, auth } = req.body
    if (auth) {
      await models.Claim.destroy({ where: { id } })
      const oldImg = req.claims.image
      if (oldImg) {
        // 删除申请材料
        const filesPath = uploadsApplyPath + oldImg.split('apply')[1]
        delPath(filesPath)
      }
    } else {
      // 逻辑删除
      await models.Claim.update(status, { where: { id } })
    }
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 删除评论
export const removeComment = async (req, res, next) => {
  try {
    const { id } = req.params
    await models.ForumComment.destroy({ where: { id } })
    await models.ForumCommentReply.destroy({ where: { comment_id: id } })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

/* 删除留言 */
export const removeIssues = async (req, res, next) => {
  try {
    const { id } = req.params
    await models.Issues.destroy({ where: { id } })
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
