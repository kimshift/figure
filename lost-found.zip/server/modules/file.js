/* 图片上传中间件 */
import formidable from 'formidable'
import { uploadsImgPath, uploadsAuthImgPath } from '../config'
import { delPath } from '../utils/file'
import models from '../db/models'
// 更新头像
export const uploadImage = async (req, res, next) => {
  const user = req.user //查询的用户数据
  if (!user) return res.sendResult(null, '参数错误', 500)
  try {
    // 创建formidable表单解析对象
    const form = new formidable.IncomingForm()
    // 设置客户端上传文件的存储路径
    form.uploadDir = uploadsImgPath
    // 保留上传文件的后缀名字
    form.keepExtensions = true
    // 解析客户端传递过来的FormData对象
    form.parse(req, async (err, fields, files) => {
      if (err || !files || !files.image) {
        return res.sendResult(null, '系统繁忙', 500)
      }
      const image = files.image.path.split('public')[1]
      const oldImg = user.Info.image
      if (!image) {
        delPath(files.image.path)
        return res.sendResult(null, '参数错误', 500)
      }
      await models.Info.update({ image }, { where: { uid: user.id } })
      if (oldImg) {
        // 删除原头像
        const filesPath = uploadsImgPath + oldImg.split('image')[1]
        delPath(filesPath)
      }
      next()
    })
  } catch (error) {
    console.log('头像上传:', error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

// 实名认证
export const uploadAuth = async (req, res, next) => {
  const user = req.user //查询的用户数据
  if (!user) return res.sendResult(null, '参数错误', 500)
  try {
    // 创建formidable表单解析对象
    const form = new formidable.IncomingForm()
    // 设置客户端上传文件的存储路径
    form.uploadDir = uploadsAuthImgPath
    // 保留上传文件的后缀名字
    form.keepExtensions = true
    // 解析客户端传递过来的FormData对象
    form.parse(req, async (err, fields, files) => {
      if (err) {
        return res.sendResult(null, '系统繁忙', 500)
      }
      const authImage = files.authImage.path.split('public')[1]
      if (!authImage) {
        delPath(files.authImage.path)
        return res.sendResult(null, '参数错误', 500)
      }
      const oldImg = user.Info.authImage
      await models.Info.update(
        { authImage, status: 2 },
        { where: { uid: user.id } }
      )
      if (oldImg) {
        // 删除附件
        const filesPath = uploadsAuthImgPath + oldImg.split('auth')[1]
        delPath(filesPath)
      }
      next()
    })
  } catch (error) {
    return res.sendResult(error, '系统繁忙', 500)
  }
}
