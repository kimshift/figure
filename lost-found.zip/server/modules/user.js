/* 用户登录注册中间件 */
import jwt from 'jsonwebtoken'
import { jwt_config } from '../config'
import models from '../db/models'
import { toCode, checkCode } from '../utils/encryption'
/* 用户注册模块中间件 */
export const register = async (req, res, next) => {
  try {
    let { username, password, passwords } = req.body
    if (!username || password != passwords) {
      return res.sendResult(null, '参数错误', 500)
    }
    password = toCode(password) //密码数据加密
    //返回值为数组，[json,created] 第一位是查询或创建的数据，第二位标识是否新建
    let result = await models.User.findOrCreate({
      where: { username },
      defaults: {
        username,
        password,
        createTime: new Date(),
      },
    })
    if (!result[1]) {
      return res.sendResult(null, '用户名已存在', 500)
    }
    await models.Info.create({ uid: result[0]?.id })
    next()
  } catch (error) {
    console.log('register:', error)
    return res.sendResult(null, '系统繁忙', 500)
  }
}
/* 用户登录模块中间件 */
export const login = async (req, res, next) => {
  try {
    let { username, password, auth } = req.body
    const params = { username }
    if (auth) params['isAdmin'] = '1'
    let user = await models.User.findOne({
      where: { ...params },
      include: [models.Info],
    })
    if (!user) return res.sendResult(null, '用户名不存在', 500)
    //密码匹配:一致则返回true
    let isPasswordValid = checkCode(
      password, //请求数据
      user.password //数据库数据
    )
    if (!isPasswordValid) return res.sendResult(null, '密码不正确', 500)
    if (!user.status) {
      return res.sendResult(null, '该账号已封停,如有疑问请联系管理员!', 500)
    }
    // 生成token
    let token = jwt.sign(
      { id: user.id, username: user.username },
      jwt_config.secretKey,
      { expiresIn: jwt_config.expiresIn }
    )
    delete user.dataValues['password'] //禁止密码数据提交给客户端
    req.token = 'Bearer ' + token
    req.user = user
    next()
  } catch (error) {
    console.log('login:', error)
    return res.sendResult(null, '系统繁忙', 500)
  }
}
