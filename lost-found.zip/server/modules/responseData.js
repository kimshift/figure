/* 统一的返回客户端结果方法模块 */
module.exports = function (req, res, next) {
  const responseData = {
    code: 200,
    message: '',
    data: null,
  }
  res.sendResult = (data, message, code = responseData.code) => {
    responseData.code = code
    responseData.message = message
    responseData.data = data
    res.json(responseData)
  }
  next()
}
