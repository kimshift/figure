import models from '../db/models' //数据模型
import { jwt_config } from '../config' //引入配置文件
import jwt from 'jsonwebtoken'
/* 验证token模块 */
export const token = (req, res, next) => {
  // split(' ')通过空格对字符串进行切割，返回一个数组
  // pop()删除数组的第一个值
  let token = String(req.headers.authorization).split(' ').pop()
  jwt.verify(
    token,
    jwt_config.secretKey,
    jwt_config.expiresIn,
    async (err, result) => {
      if (err)
        return res.sendResult(err.message, '登录状态已失效，请重新登录！', 500) // // 无token值,或者token格式错误
      try {
        // 有token值
        let { username } = result
        // 查询用户表
        let user = await models.User.findOne({
          where: { username },
          include: [models.Info],
        })
        if (!user)
          return res.sendResult(null, '登录状态已失效，请重新登录！', 500) //用户不存在，终止操作反馈信息回浏览器
        req.user = user //将查询到的用户信息传递出去
        next()
      } catch (error) {
        console.log(error)
      }
    }
  )
}

/* 验证权限 */
export const auth = (req, res, next) => {
  if (!req.user.isAdmin) return res.sendResult(null, '权限不足！', 500)
  next()
}