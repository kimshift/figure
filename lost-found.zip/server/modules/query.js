/* 该中间件是查询操作模块中间件 */
import models from '../db/models'
const Op = models.Sequelize.Op
// 根据id查询的用户表中间件
export const findByUid = async (req, res, next) => {
  try {
    let { id } = req.params
    let user = await models.User.findOne({
      where: { id },
      attributes: {
        exclude: ['password'],
      },
      // include: [{ model: models.Info }],
      include: [models.Info],
    })
    req.userInfo = user
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 根据id查询物品表
export const findByGoodsId = async (req, res, next) => {
  try {
    const id = req.params.id || req.params.goodsId
    const goods = await models.Good.findOne({
      where: { id },
      include: [
        {
          // include关键字表示关联查询
          model: models.User, // 指定关联的model
          attributes: {
            exclude: ['password'],
          },
          include: [models.Info],
        },
        {
          model: models.Cate,
        },
      ],
    })
    req.goods = goods
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 根据id查询物品分类表的中间件
export const findByCateId = async (req, res, next) => {
  try {
    const { id } = req.params
    const cate = await models.Cate.findOne({ where: { id } })
    req.cate = cate
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 根据id查询认领-对接记录表
export const findByClaimsId = async (req, res, next) => {
  try {
    const id = req.params.id
    const claims = await models.Claim.findOne({
      where: { id },
      include: [
        {
          // include关键字表示关联查询
          model: models.User, // 指定关联的model
          attributes: {
            exclude: ['password'],
          },
          include: [models.Info],
        },
        {
          model: models.Good,
          include: [
            {
              // include关键字表示关联查询
              model: models.User, // 指定关联的model
              attributes: {
                exclude: ['password'],
              },
              include: [models.Info],
            },
          ],
        },
      ],
    })
    req.claims = claims
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 根据goodsId查询认领-对接记录表
export const findByGoodsIdForClaim = async (req, res, next) => {
  try {
    const { id } = req.params
    // 查询交接进行中
    const claimsIng = await models.Claim.findOne({
      where: {
        goodsId: id,
        claimStatus: {
          [Op.and]: [{ [Op.ne]: -1 }, { [Op.ne]: 2 }],
        },
      },
    })
    const claimsOne = await models.Claim.findOne({
      where: {
        goodsId: id,
      },
    })
    req.claims = { claimsIng, claimsOne }
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 根据分类id查询关联的物品表的中间件
export const findByGoodsCate = async (req, res, next) => {
  try {
    const { id } = req.params
    const goods = await models.Good.findOne({ where: { cateId: id } })
    req.goods = goods
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 根据id查询轮播图表
export const findBySlideshowId = async (req, res, next) => {
  try {
    const { id } = req.params
    const slideshow = await models.Slideshow.findOne({
      where: { id },
    })
    req.slideshow = slideshow
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}
// 根据申请对接表的uid,goodsId查询的中间件
export const findByClaim = async (req, res, next) => {
  try {
    const uid = req.user.id
    const { goodsId } = req.params

    const claims = await models.Claim.findOne({
      where: {
        uid,
        goodsId,
        claimStatus: {
          [Op.and]: [{ [Op.ne]: -1 }, { [Op.ne]: 2 }],
        },
      },
    })
    req.claims = claims
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(error, '系统繁忙', 500)
  }
}

/* 查询论坛帖子列表功能模块中间件 */
export const queryForumPosts = async (req, res, next) => {
  try {
    let { page = 1, limit = 10 } = req.query

    // 验证 page 和 limit 是否为数字
    page = parseInt(page)
    limit = parseInt(limit)

    if (isNaN(page) || isNaN(limit) || page < 1 || limit < 1) {
      return res.sendResult(null, '无效的分页参数', 400)
    }

    const offset = (page - 1) * limit

    const posts = await models.ForumPost.findAndCountAll({
      limit,
      offset,
      order: [['create_time', 'DESC']],
      include: [models.User],
    })

    req.posts = posts
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(null, '查询帖子列表时发生错误', 500)
  }
}

/* 根据id查询单个论坛帖子详情功能模块中间件 */
export const queryForumPostDetail = async (req, res, next) => {
  try {
    const { id } = req.params
    const postDetail = await models.ForumPost.findOne({
      where: { id },
      include: [models.User],
    })
    if (!postDetail) return res.sendResult(null, '帖子不存在', 404)
    req.postDetail = postDetail
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(null, '查询帖子详情时发生错误', 500)
  }
}

/* 查询论坛评论列表功能模块中间件 */
export const queryForumPostsComments = async (req, res, next) => {
  try {
    let { id, page = 1, limit = 10 } = req.body
    // 验证 page 和 limit 是否为数字
    page = parseInt(page)
    limit = parseInt(limit)

    if (isNaN(page) || isNaN(limit) || page < 1 || limit < 1) {
      return res.sendResult(null, '无效的分页参数', 400)
    }

    const offset = (page - 1) * limit
    let count = await models.ForumComment.count({
      where: { post_id: id },
    })
    let rows = await models.ForumComment.findAll({
      where: { post_id: id },
      limit,
      offset,
      order: [['create_time', 'DESC']],
      include: [
        models.User,
        {
          model: models.ForumCommentReply,
          include: [models.User],
        },
      ],
    })
    rows = JSON.parse(JSON.stringify(rows))
    for (let index = 0; index < rows.length; index++) {
      const element = rows[index]
      element.replayFlag = element.ForumCommentReplies.length > 0
      element.comment_username = element.User?.username || '匿名者' //对论坛发表评论者
      if (element.replayFlag) {
        // 评论有回复
        for (let i = 0; i < element.ForumCommentReplies.length; i++) {
          const reply = element.ForumCommentReplies[i]
          reply.reply_username = reply.User?.username || '匿名者' //对评论进行回复者
          let user = await models.User.findOne({
            where: { id: reply.reply_uid },
          })
          user = JSON.parse(JSON.stringify(user))
          reply.reply_comment_username = user.username || '匿名者' //所回复的对象
        }
      }
    }
    req.result = { count, rows }
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(null, '查询评论列表时发生错误', 500)
  }
}
// 所有评论
export const queryCommentsList = async (req, res, next) => {
  try {
    let { page = 1, limit = 10 } = req.query
    // 验证 page 和 limit 是否为数字
    page = parseInt(page)
    limit = parseInt(limit)

    if (isNaN(page) || isNaN(limit) || page < 1 || limit < 1) {
      return res.sendResult(null, '无效的分页参数', 400)
    }
    const offset = (page - 1) * limit
    let count = await models.ForumComment.count()
    let rows = await models.ForumComment.findAll({
      limit,
      offset,
      order: [['create_time', 'DESC']],
      include: [
        models.User,
        {
          model: models.ForumCommentReply,
          include: [models.User],
        },
      ],
    })
    rows = JSON.parse(JSON.stringify(rows))
    for (let index = 0; index < rows.length; index++) {
      const element = rows[index]
      element.replayFlag = element.ForumCommentReplies.length > 0
      element.comment_username = element.User?.username || '匿名者' //对论坛发表评论者
      if (element.replayFlag) {
        // 评论有回复
        for (let i = 0; i < element.ForumCommentReplies.length; i++) {
          const reply = element.ForumCommentReplies[i]
          reply.reply_username = reply.User?.username || '匿名者' //对评论进行回复者
          let user = await models.User.findOne({
            where: { id: reply.reply_uid },
          })
          user = JSON.parse(JSON.stringify(user))
          reply.reply_comment_username = user.username || '匿名者' //所回复的对象
        }
      }
    }
    req.result = { count, rows }
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(null, '查询评论列表时发生错误', 500)
  }
}

/* 查询留言板列表功能模块中间件 */
export const queryIssuesList = async (req, res, next) => {
  try {
    let { page = 1, limit = 10 } = req.query
    // 验证 page 和 limit 是否为数字
    page = parseInt(page)
    limit = parseInt(limit)

    if (isNaN(page) || isNaN(limit) || page < 1 || limit < 1) {
      return res.sendResult(null, '无效的分页参数', 400)
    }

    const offset = (page - 1) * limit

    let result = await models.Issues.findAndCountAll({
      limit,
      offset,
      order: [['create_time', 'DESC']],
      include: [models.User],
    })
    result = JSON.parse(JSON.stringify(result))

    for (let index = 0; index < result.rows.length; index++) {
      const element = result.rows[index]
      element.issues_username = element.User?.username || '匿名者' //留言者
    }
    req.result = result
    next()
  } catch (error) {
    console.log(error)
    return res.sendResult(null, '查询留言列表时发生错误', 500)
  }
}
