/* 分类管理模块 */
import express from 'express'
const router = express.Router()
import { token, auth } from '../../../modules/authorization'
import { findByCateId, findByGoodsCate } from '../../../modules/query'
import { updateCate } from '../../../modules/update'
import { createCate } from '../../../modules/create'
import { removeCate } from '../../../modules/remove'
/* 添加数据 */
router.post('/create', token, auth, createCate, (req, res) => {
  res.sendResult(null, '新增成功')
})

/* 查询单个数据 */
router.get('/query/:id', token, auth, findByCateId, (req, res) => {
  if (!req.cate) return res.sendResult(null, '查询失败', 500)
  res.sendResult(req.cate, '查询成功')
})

/* 修改数据 */
router.put('/update/:id', token, auth, updateCate, (req, res) => {
  res.sendResult(null, '修改成功')
})

/* 删除数据 */
router.delete(
  '/delete/:id',
  token,
  auth,
  findByGoodsCate,
  removeCate,
  (req, res) => {
    res.sendResult(200, '删除成功')
  }
)
module.exports = router
