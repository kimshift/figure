/* 商品管理路由模块 */
import express from 'express'
const router = express.Router()
import { token, auth } from '../../../modules/authorization'
import { findBySlideshowId } from '../../../modules/query'
import {
  updateSlideshowInfo,
  updateSlideshowStatus,
} from '../../../modules/update'
import { createSlideshow } from '../../../modules/create'
import { removeSlideshow } from '../../../modules/remove'

/* 添加数据 */
router.post('/create', token, auth, createSlideshow, (req, res) => {
  res.sendResult(null, '发布成功')
})

/* 修改数据 */
router.put(
  '/update/:id',
  token,
  auth,
  findBySlideshowId,
  updateSlideshowInfo,
  (req, res) => {
    res.sendResult(null, '修改成功')
  }
)

/* 根据id修改数据状态 */
router.put(
  '/update_status/:id/:status',
  token,
  auth,
  updateSlideshowStatus,
  (req, res) => {
    res.sendResult(null, '操作成功')
  }
)

/* 删除数据==>修改状态为-1(使用逻辑删除) */
router.delete(
  '/delete/:id',
  token,
  findBySlideshowId,
  removeSlideshow,
  (req, res) => {
    res.sendResult(null, '删除成功')
  }
)

module.exports = router
