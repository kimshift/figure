/* 用户管理路由模块 */
import express from 'express'
const router = express.Router()
import models from '../../../db/models'
const Op = models.Sequelize.Op
import { token, auth } from '../../../modules/authorization'
import { isEmpty } from '../../../utils/isEmpty'
import { findByUid } from '../../../modules/query'
import {
  updateUserStatus,
  updateUserAuth,
  resetPwd,
} from '../../../modules/update'
/** 查询数据*/
router.get('/', token, auth, async (req, res) => {
  try {
    // page：当前页；limit:加载量；sort:排序；search:查询关键词；
    let { page, limit, sort, search } = req.query
    let offset = 0 //偏移量
    let where = {} //查询条件
    let order = [] //排序
    if (!isEmpty(sort)) {
      sort = JSON.parse(sort) //排序
      for (const key in sort) {
        if (Object.hasOwnProperty.call(sort, key)) {
          const value = sort[key] === 1 ? 'asc' : 'desc'
          //参数1:数据库字段，参数2:排序方式desc/asc
          order.push([key, value])
        }
      }
    }
    page = Number(page) || 1 //当前页
    limit = Number(limit) || null //加载量(不传则加载全部)
    offset = (page - 1) * limit || 0 //偏移量
    let where_info = {}
    if (search?.trim()) {
      where_info = {
        [Op.or]: [
          { nikeName: { [Op.like]: `%${search}%` } }, //Op.like模糊查询
          { address: { [Op.like]: `%${search}%` } }, //Op.like模糊查询
          { phone: { [Op.like]: `%${search}%` } },
        ],
      }
    }
    where['username'] = { [Op.ne]: `${req.user.username}` } // 过滤管理员自己
    const users = await models.User.findAndCountAll({
      where,
      order,
      limit,
      offset,
      attributes: {
        exclude: ['password'],
      },
      include: [
        {
          model: models.Info, // 指定关联的model
          where: { ...where_info }, //过滤禁用的发布者
        },
      ],
    })
    res.sendResult(users, '查询成功')
  } catch (error) {
    console.log('error:', error)
    return res.sendResult(error, '系统繁忙', 500)
  }
})
/* 查询单个用户 uid*/
router.get('/query/:id', token, auth, findByUid, (req, res) => {
  if (!req.userInfo) return res.sendResult(null, '查询失败', 500)
  res.sendResult(req.userInfo, '查询成功')
})
/* 重置用户密码 */
router.put('/reset_pwd', token, auth, resetPwd, (req, res) => {
  res.sendResult(null, '密码重置成功')
})
/* 修改数据状态 */
router.put(
  '/update_status/:id/:status',
  token,
  auth,
  updateUserStatus,
  (req, res) => {
    res.sendResult(null, '操作成功')
  }
)
// 审核数据
router.put('/update_auth/:id', token, auth, updateUserAuth, (req, res) => {
  res.sendResult(null, '操作成功')
})
module.exports = router
