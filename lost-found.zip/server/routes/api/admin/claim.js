/* 审核申请管理模块 */
import express from 'express'
const router = express.Router()
import { token, auth } from '../../../modules/authorization'
import { authClaimInfo } from '../../../modules/update'

/* 审核数据 */
router.put('/updateAuth', token, auth, authClaimInfo, async (req, res) => {
  res.sendResult(null, '审核成功')
})

module.exports = router
