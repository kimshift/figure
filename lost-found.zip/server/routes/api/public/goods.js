/* 物品管理路由模块 */
import express from 'express'
const router = express.Router()
import models from '../../../db/models'
const Op = models.Sequelize.Op
import { isEmpty } from '../../../utils/isEmpty'
import { findByGoodsId, findByGoodsIdForClaim } from '../../../modules/query'
import { token } from '../../../modules/authorization'
import { createGoods } from '../../../modules/create'
import { updateGoodsStatus, updateGoodsInfo } from '../../../modules/update'
import { removeGoods } from '../../../modules/remove'
/** 查询全部物品数据*/
router.get('/', async (req, res) => {
  try {
    let { page, limit, status, sort, search, cateId, uid, type, need } =
      req.query
    let offset = 0 //偏移量
    let where = {} //查询条件
    let order = [] //排序
    if (!isEmpty(sort)) {
      sort = JSON.parse(sort) //排序
      for (const key in sort) {
        if (Object.hasOwnProperty.call(sort, key)) {
          if (sort[key] !== null) {
            const value = sort[key] === 1 ? 'asc' : 'desc'
            //参数1:数据库字段，参数2:排序方式desc/asc
            order.push([key, value])
          }
        }
      }
    }
    page = Number(page) || 1 //当前页
    limit = Number(limit) || null //加载量(不传则加载全部)
    offset = (page - 1) * limit || 0 //偏移量
    if (search?.trim()) where['goodsName'] = { [Op.like]: `%${search}%` } //模糊查询
    if (Number(cateId)) where['cateId'] = cateId //分类筛选
    if (uid) where['uid'] = uid //发布者筛选
    if (type) where['type'] = type //类型筛选
    if (need) where['need'] = need //紧急状态筛选筛选
    if (status !== undefined) {
      if (status) where['status'] = Number(status)
      else where['status'] = { [Op.ne]: -1 } //默认不查询被删除的
    }
    const goods = await models.Good.findAndCountAll({
      where,
      order,
      limit,
      offset,
      include: [
        {
          // include关键字表示关联查询
          model: models.User, // 指定关联的model
          where: { status: 1 }, //过滤禁用的发布者
          attributes: {
            exclude: ['password'] //过滤掉密码
          },
          include: [models.Info]
        },
        {
          model: models.Cate //关联分类表
        }
      ]
    })
    res.sendResult(goods, '查询成功')
  } catch (error) {
    console.log('error:', error)
    return res.sendResult(error, '系统繁忙', 500)
  }
})

/** 查询首页物品数据*/
router.get('/home', async (req, res) => {
  try {
    let { page, limit, status, need } = req.query
    let offset = 0 //偏移量
    let where = {} //查询条件
    page = Number(page) || 1 //当前页
    limit = Number(limit) || null //加载量(不传则加载全部)
    offset = (page - 1) * limit || 0 //偏移量
    where['status'] = Number(status)
    const goods = []
    const cates = await models.Cate.findAll()
    for (let index = 0; index < cates.length; index++) {
      where['cateId'] = cates[index].id
      const temp = await models.Good.findAndCountAll({
        where,
        limit,
        offset,
        include: [
          {
            // include关键字表示关联查询
            model: models.User, // 指定关联的model
            where: { status: 1 }, //过滤禁用的发布者
            attributes: {
              exclude: ['password'] //过滤掉密码
            },
            include: [models.Info]
          },
          {
            model: models.Cate //关联分类表
          }
        ]
      })
      if (temp.count) goods.push(temp.rows)
    }
    res.sendResult(goods, '查询成功')
  } catch (error) {
    console.log('error:', error)
    return res.sendResult(error, '系统繁忙', 500)
  }
})

/* 添加数据 */
router.post('/create', token, createGoods, (req, res) => {
  res.sendResult(null, '发布成功')
})

/* 根据id修改数据状态 */
router.put(
  '/updateStatus/:id/:status',
  token,
  findByGoodsId,
  updateGoodsStatus,
  (req, res) => {
    res.sendResult(null, '操作成功')
  }
)

/* 修改数据 */
router.put('/update/:id', token, findByGoodsId, updateGoodsInfo, (req, res) => {
  res.sendResult(null, '修改成功')
})

/* 删除数据==>修改状态为-1(使用逻辑删除) */
router.delete(
  '/delete/:id',
  token,
  findByGoodsId,
  findByGoodsIdForClaim,
  removeGoods,
  (req, res) => {
    res.sendResult(null, '删除成功')
  }
)

/* 查询单个数据*/
router.get('/query/:id', findByGoodsId, async (req, res) => {
  if (!req.goods) return res.sendResult(null, '查询失败', 500)
  res.sendResult(req.goods, '查询成功')
})

module.exports = router
