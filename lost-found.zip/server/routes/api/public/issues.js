/* 留言模块 */
import express from 'express'
const router = express.Router()
import { token, auth } from '../../../modules/authorization'
import { createIssues } from '../../../modules/create'
import { queryIssuesList } from '../../../modules/query'
import { replyIssues } from '../../../modules/update'
import { removeIssues } from '../../../modules/remove'

// 创建留言
router.post('/create', token, createIssues, (req, res) => {
  return res.sendResult(null, 'success')
})

// 留言列表
router.get('/list', queryIssuesList, (req, res) => {
  return res.sendResult(req.result, 'success')
})

// 回复留言
router.post('/reply', token, replyIssues, (req, res) => {
  return res.sendResult(null, 'success')
})

// 删除留言
router.delete('/delete/:id', token, auth, removeIssues, (req, res) => {
  return res.sendResult(null, '删除成功')
})

module.exports = router
