/* 论坛模块 */
import express from 'express'
const router = express.Router()
import { auth, token } from '../../../modules/authorization'
import {
  createForumPost,
  createForumComment,
  createForumCommentReply,
} from '../../../modules/create'
import {
  queryForumPosts,
  queryForumPostDetail,
  queryForumPostsComments,
  queryCommentsList,
} from '../../../modules/query'
import { removeComment } from '../../../modules/remove'

/* 获取论坛帖子列表 */
router.get('/posts', queryForumPosts, (req, res) => {
  return res.sendResult(req.posts, '帖子列表查询成功')
})

/* 创建新论坛帖子 */
router.post('/posts', token, createForumPost, (req, res) => {
  return res.sendResult(req.newPost, '新帖子创建成功')
})

/* 获取单个论坛帖子详情 */
router.get('/posts/:id', queryForumPostDetail, (req, res) => {
  return res.sendResult(req.postDetail, '帖子详情查询成功')
})

/* 创建新论坛评论 */
router.post('/posts/comments', token, createForumComment, (req, res) => {
  return res.sendResult(req.newComment, '新评论创建成功')
})

// 论坛评论列表
router.post('/posts/comments_list', queryForumPostsComments, (req, res) => {
  return res.sendResult(req.result, 'success')
})

// 回复评论
router.post('/posts/comments/reply', token, createForumCommentReply, (req, res) => {
  return res.sendResult(req.newComment, '新评论创建成功')
})

// 所以评论数据
router.get('/comments_all_list', queryCommentsList, (req, res) => {
  return res.sendResult(req.result, 'success')
})

// 删除评论
router.delete('/posts/comments/delete/:id', token, auth, removeComment, (req, res) => {
  return res.sendResult(req.newComment, '新评论创建成功')
})

module.exports = router
