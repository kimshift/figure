/* 用户管理路由模块 */

import express from 'express'
const router = express.Router()
import { token } from '../../../modules/authorization'
import { updateInfo, updatePwd } from '../../../modules/update'
import { uploadImage } from '../../../modules/file'

/* 更新头像 */
router.put('/update_img', token, uploadImage, (req, res) => {
  return res.sendResult(null, '上传成功')
})
/* 修改基本数据 */
router.put('/update_info', token, updateInfo, async (req, res) => {
  return res.sendResult(null, '修改成功')
})
/* 修改密码 */
router.put('/update_pwd', token, updatePwd, async (req, res) => {
  return res.sendResult(null, '修改成功')
})

module.exports = router
