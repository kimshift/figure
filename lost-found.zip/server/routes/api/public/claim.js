/* 认领-还物申请管理模块 */
import express from 'express'
const router = express.Router()
import models from '../../../db/models'
const Op = models.Sequelize.Op
import { token } from '../../../modules/authorization'
import { createClaim } from '../../../modules/create'
import {
  findByGoodsId,
  findByClaim,
  findByClaimsId,
} from '../../../modules/query'
import { removeClaimInfo } from '../../../modules/remove'
import { updateClaimInfo, updateClaimStatus } from '../../../modules/update'
import { isEmpty } from '../../../utils/isEmpty'
/** 查询数据*/
router.get('/', token, async (req, res) => {
  try {
    let { page, limit, sort, search, type, select, status } = req.query
    let offset = 0 //偏移量
    let where = {} //查询条件
    let where_good = {}
    let order = [] //排序
    if (!isEmpty(sort)) {
      sort = JSON.parse(sort) //排序
      for (const key in sort) {
        if (Object.hasOwnProperty.call(sort, key)) {
          if (sort[key] !== null) {
            const value = sort[key] === 1 ? 'asc' : 'desc'
            //参数1:数据库字段，参数2:排序方式desc/asc
            order.push([key, value])
          }
        }
      }
    }
    page = Number(page) || 1 //当前页
    limit = Number(limit) || null //加载量(不传则加载全部)
    offset = (page - 1) * limit || 0 //偏移量
    if (search?.trim()) where_good['goodsName'] = { [Op.like]: `%${search}%` } //模糊查询
    if (type) where['type'] = type //类型筛选
    if (status) {
      where[status] = { [Op.ne]: -1 } //默认不查询删除的数据
      where['uid'] = req.user.id //申请人筛选
      if (select && select !== 'null') where['claimStatus'] = select //交接状态
    } else {
      where['status1'] = { [Op.ne]: -1 } //默认不查询管理员删除的数据
      if (select && select !== 'null') where['examineStatus'] = select //审核状态
    }
    const claims = await models.Claim.findAndCountAll({
      where,
      order,
      limit,
      offset,
      include: [
        {
          // include关键字表示关联查询
          model: models.User, // 指定关联的model
          attributes: {
            exclude: ['password'], //过滤掉密码
          },
          include: [models.Info],
        },
        {
          model: models.Good, //关联分类表
          where: { ...where_good },
          include: [
            {
              model: models.User, // 指定关联的model
              attributes: {
                exclude: ['password'], //过滤掉密码
              },
              include: [models.Info],
            },
          ],
        },
      ],
    })
    res.sendResult(claims, '查询成功')
  } catch (error) {
    console.log('error:', error)
    return res.sendResult(error, '系统繁忙', 500)
  }
})

/** 查询交接数据*/
router.get('/dock', token, async (req, res) => {
  try {
    let { page, limit, sort, search, type, select, status } = req.query
    let offset = 0 //偏移量
    let where = {} //查询条件
    let where_good = {}
    let order = [] //排序
    if (!isEmpty(sort)) {
      sort = JSON.parse(sort) //排序
      for (const key in sort) {
        if (Object.hasOwnProperty.call(sort, key)) {
          if (sort[key] !== null) {
            const value = sort[key] === 1 ? 'asc' : 'desc'
            //参数1:数据库字段，参数2:排序方式desc/asc
            order.push([key, value])
          }
        }
      }
    }
    page = Number(page) || 1 //当前页
    limit = Number(limit) || null //加载量(不传则加载全部)
    offset = (page - 1) * limit || 0 //偏移量
    if (search?.trim()) where_good['goodsName'] = { [Op.like]: `%${search}%` } //模糊查询
    if (type) where['type'] = type //类型筛选
    if (select) where['claimStatus'] = select //交接状态
    if (status) {
      where[status] = { [Op.ne]: -1 } //默认不查询删除的数据
      where_good['uid'] = req.user.id //发布者筛选
    }else{
      where['status1'] = { [Op.ne]: -1 } //默认不查询管理员删除的数据
    }
    const claims = await models.Claim.findAndCountAll({
      where,
      order,
      limit,
      offset,
      include: [
        {
          // include关键字表示关联查询
          model: models.User, // 指定关联的model
          attributes: {
            exclude: ['password'], //过滤掉密码
          },
          include: [models.Info],
        },
        {
          model: models.Good, //关联分类表
          where: { ...where_good },
          include: [
            {
              model: models.User, // 指定关联的model
              attributes: {
                exclude: ['password'], //过滤掉密码
              },
              include: [models.Info],
            },
          ],
        },
      ],
    })
    res.sendResult(claims, '查询成功')
  } catch (error) {
    console.log('error:', error)
    return res.sendResult(error, '系统繁忙', 500)
  }
})

// 查询单个数据
router.get('/query/:id', token, findByClaimsId, (req, res) => {
  res.sendResult(req.claims, '查询成功!')
})

// 申请操作
router.post(
  '/create/:goodsId',
  token,
  findByGoodsId,
  findByClaim,
  createClaim,
  (req, res) => {
    res.sendResult(null, '申请成功，等待审核!')
  }
)
/* 修改数据 */
router.put(
  '/update/:id',
  token,
  findByClaimsId,
  updateClaimInfo,
  async (req, res) => {
    res.sendResult(null, '更新成功!')
  }
)

/* 修改数据状态 */
router.put('/updateStatus', token, updateClaimStatus, async (req, res) => {
  res.sendResult(null, '更新成功')
})

/* 根据ID删除数据 */
router.post('/delete', token, removeClaimInfo, async (req, res) => {
  res.sendResult(null, '删除成功')
})
module.exports = router
