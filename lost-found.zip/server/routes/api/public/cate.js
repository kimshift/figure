/* 分类管理路由模块 */
import express from 'express'
const router = express.Router()
import models from '../../../db/models'
const Op = models.Sequelize.Op
import { isEmpty } from '../../../utils/isEmpty'
/** 查询数据*/
router.get('/', async (req, res) => {
  try {
    let { page, limit, sort, search } = req.query
    let offset = 0 //偏移量
    let where = {} //查询条件
    let order = [] //排序
    if (!isEmpty(sort)) {
      sort = JSON.parse(sort) //排序
      for (const key in sort) {
        if (Object.hasOwnProperty.call(sort, key)) {
          const value = sort[key] === 1 ? 'asc' : 'desc'
          //参数1:数据库字段，参数2:排序方式desc/asc
          order.push([key, value])
        }
      }
    }
    page = Number(page) || 1 //当前页
    limit = Number(limit) || null //加载量(不传则加载全部)
    offset = (page - 1) * limit || 0 //偏移量
    if (search?.trim()) where['cateName'] = { [Op.like]: `%${search}%` } //模糊查询
    const cates = await models.Cate.findAndCountAll({
      where,
      order,
      limit,
      offset,
    })
    res.sendResult(cates, '查询成功')
  } catch (error) {
    console.log('error:', error)
    return res.sendResult(error, '系统繁忙', 500)
  }
})

module.exports = router
