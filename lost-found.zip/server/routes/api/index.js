/* 信息验证路由模块 */
import express from 'express'
import fs from 'fs'
const router = express.Router()
import { token } from '../../modules/authorization'
import { login, register } from '../../modules/user'
import { uploadAuth } from '../../modules/file'
import { publicPath } from '../../config'
/* 登录验证 */
router.post('/login', login, (req, res) => {
  let userInfo = {
    user: req.user,
    token: req.token,
  }
  res.sendResult(userInfo, '登录成功')
})
/* 注册验证 */
router.post('/register', register, (req, res) => {
  res.sendResult(null, '注册成功')
})
/* token验证信息 */
router.get('/userInfo', token, (req, res, next) => {
  delete req.user.dataValues['password'] //禁止密码数据提交给客户端
  res.sendResult(req.user, '验证成功')
})
/* 实名认证 */
router.put('/update_auth', token, uploadAuth, async (req, res) => {
  res.sendResult(null, '申请成功，等待管理员审核！')
})

/* 读取markdown文件 */
router.get('/getMdFile', (req, res, next) => {
  try {
    const data = fs.readFileSync(`${publicPath}\\docs\\README.md`, 'utf8')
    res.sendResult(data, '查询成功')
  } catch (err) {
    console.error(err)
    res.sendResult(err, '系统繁忙', 500)
  }
})

module.exports = router
