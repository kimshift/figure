module.exports = {
  // 代理配置
  //vue-cli3.0 里面的 vue.config.js做配置
  devServer: {
    port: '8080', //前端端口
    open: false, //启动后自动打开客户端
    disableHostCheck: true, //禁用主机检查<内网穿透测试使用>
    // cli3 代理是从指定的target后面开始匹配的，不是任意位置；配置pathRewrite可以做替换
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:3000', //代理目标端口
        changeOrigin: true, //如果接口跨域，需要进行这个参数配置
        ws: false,
        // pathRewrite: {
        //   '^/api': '', //路径重写
        // },
      },
      // 图片资源代理
      '/uploads': {
        target: 'http://127.0.0.1:3000', //代理目标端口
        changeOrigin: true, //如果接口跨域，需要进行这个参数配置
        ws: false,
      },
    },
  },
  // 打包配置
  chainWebpack: config => {
    // 当前编译模式为项目开发模式
    config.when(process.env.NODE_ENV === 'development', config => {
      config.entry('app').clear().add('./src/main.js')
      config.plugin('html').tap(args => {
        args[0].isProd = false
        return args
      })
    })
  },
}
