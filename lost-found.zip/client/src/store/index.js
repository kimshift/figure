import Vue from 'vue'
import Vuex from 'vuex'

import state from './state'
import mutations from './mutations'
import actions from './actions'

//使用vuex
Vue.use(Vuex)

//输出vuex的store对象
export default new Vuex.Store({
  state,
  mutations,
  actions
})
