/* 定义同步处理方法 mutations*/
/**
 * import { mapMutations } from "vuex";
 * vue组件调用方式：...mapMutations(["方法名"])
 * 一般放到vue组件的methods作用域内
 */

//所有的state的修改都是在mutations中做的，这是唯一一个可以修改state的地方
export default {
  // 控制登录注册弹窗框
  setShowLoginOrRegister(state, { showLogin, showRegister }) {
    state.showLogin = showLogin
    state.showRegister = showRegister
  },
  // 同步用户的信息状态
  syncUserInfo(state, info) {
    // const { isAdmin, username } = info
    state.userInfo = info
    // state.isLogin = Boolean(username)
    // state.isAdmin = Boolean(isAdmin)
    state.isLogin = Boolean(info.username)
    state.isAdmin = Boolean(info.isAdmin)
  },
  // 清除登录状态
  syncLogout(state) {
    window.sessionStorage.clear()
    state.userInfo = {}
    state.isLogin = false
    state.isAdmin = false
    state.orderList = []
  },
  // 同步物品分类数据
  setCateList(state, { rows }) {
    state.cateList = rows
  },
  // 同步首页物品数据
  setHomeGoodsList(state, data) {
    state.homeGoodsList = data
  },
  // 同步物品数据
  setGoodsList(state, { rows, count }) {
    state.total = count
    state.goodsList = rows
  },
  // 同步物品详情数据
  setGoodsInfo(state, data) {
    state.goodsInfo = data
  },
  //同步轮播图数据
  setSlideshow(state, { rows }) {
    state.carousel = rows
  },
  // 同步查询全部物品的参数体
  setQueryParams(state, queryParams) {
    state.queryParams = queryParams
  },
  // 同步申请物品详情数据
  setClaimInfo(state, data) {
    state.claimInfo = data
  },
  // 同步论坛帖子列表
  setForumPosts(state, { rows, count }) {
    state.forumPosts = rows
    state.forumTotal = count
  }
}
