// 定义状态管理对象：state
// 外部调用方式：
//   import { mapState } from "vuex";
//   ...mapState(['key'])  ===> 获取用户信息： ...mapState(['userInfo'])
//   mapState一般在vue组件的计算函数中引用
export default {
  userInfo: {}, // 用户数据
  showLogin: false, //展示登录框
  showRegister: false, //展示登注册框
  isLogin: false, //登录状态
  isAdmin: false, //是否是管理员
  carousel: [], // 首页轮播图
  homeGoodsList: [], //首页物品数据
  goodsList: [], //物品列表
  cateList: [], //物品分类数据
  goodsInfo: [], // 物品详细信息
  claimInfo: {}, //认领信息

  //物品数据请求参数体
  queryParams: {
    search: '', //查询参数
    page: 1, // 当前的页数
    limit: 10, // 当前每页显示多少条数据
    status: 1, //默认查询上架物品
    cateId: '0' //默认全部
  }, //物品数据请求参数体
  total: 0, //总数据

  //论坛数据
  forumPosts: [], // 论坛帖子列表
  forumTotal: 0 // 论坛帖子总数
}
