/* 定义异步处理方法 action*/
/**
 * import { mapActions } from "vuex";
 * vue组件调用方式：...mapActions(["方法名"])
 * 一般放到vue组件的methods作用域内
 */
import {
  getSlideshowList,
  getGoodsList,
  getCateList,
  getGoodsInfo,
  getHomeGoodsList,
  getClaimInfo,
  fetchPosts
} from '../api'
import Vue from 'vue' //vue配合elementUI消息提示组件使用
export default {
  // 获取首页的轮播图
  async reqHomeCasual({ commit }) {
    try {
      const res = await getSlideshowList({ status: 1 })
      if (res.code !== 200) return this.$message.error(res.message)
      commit('setSlideshow', res.data)
    } catch (error) {
      console.log('action:', error)
    }
  },

  // 获取首页商品数据
  async reqHomeGoodsList({ commit }, params) {
    try {
      const res = await getHomeGoodsList(params)
      if (res.code !== 200) return Vue.prototype.$message.error(res.message)
      commit('setHomeGoodsList', res.data)
    } catch (error) {
      console.log('action:', error)
    }
  },

  // 获取商品数据
  async reqGoodsList({ commit }, params) {
    try {
      const res = await getGoodsList(params)
      if (res.code !== 200) return Vue.prototype.$message.error(res.message)
      commit('setGoodsList', res.data)
    } catch (error) {
      console.log('action:', error)
    }
  },

  // 获取所有商品分类数据
  async reqCateList({ commit }, params) {
    try {
      const res = await getCateList(params)
      if (res.code !== 200) return Vue.prototype.$message.error(res.message)
      res.data.rows.unshift({ id: 0, cateName: '全部' })
      commit('setCateList', res.data)
    } catch (error) {
      console.log('action:', error)
    }
  },

  // 获取商品详情数据
  async reqGoodsInfo({ commit }, id) {
    try {
      const res = await getGoodsInfo(id)
      if (res.code !== 200) return Vue.prototype.$message.error(res.message)
      commit('setGoodsInfo', res.data)
    } catch (error) {
      console.log('action:', error)
    }
  },

  // 获取商品详情数据
  async reqClaimInfo({ commit }, id) {
    try {
      const res = await getClaimInfo(id)
      if (res.code !== 200) return Vue.prototype.$message.error(res.message)
      commit('setClaimInfo', res.data)
    } catch (error) {
      console.log('action:', error)
    }
  },

  // 获取论坛帖子列表
  async reqForumPosts({ commit }, params) {
    try {
      const res = await fetchPosts(params)
      if (res.code !== 200) return Vue.prototype.$message.error(res.message)
      commit('setForumPosts', res.data)
    } catch (error) {
      console.log('action: reqForumPosts error:', error)
    }
  }
}
