<template>
  <div class="main">
    <Shelf title="个人资料">
      <div slot="content" class="info1">
        <div class="ibox-content">
          <div class="text-center">
            <p class="user-info-head">
              <img
                class="img-lg"
                v-if="userInfo.Info && userInfo.Info.image"
                :src="userInfo.Info.image"
                @click="showEditAvatarDrawer"
              />
              <img
                class="img-lg"
                v-else
                :src="imageDefault"
                @click="showEditAvatarDrawer"
              />
            </p>
            <p>
              <a href="#!" @click="showEditAvatarDrawer">修改头像</a>
            </p>
          </div>
          <ul class="list-group list-group-striped">
            <li class="list-group-item">
              <i class="fa fa-user"></i>
              <b class="font-noraml">账号名称：</b>
              <p class="pull-right">{{ userInfo.username }}</p>
            </li>
            <li class="list-group-item">
              <i class="fa fa-group"></i>
              <b class="font-noraml">用户姓名：</b>
              <p class="pull-right" v-if="userInfo.Info">
                {{ userInfo.Info.nikeName }}
              </p>
            </li>
            <li class="list-group-item">
              <i class="fa fa-group"></i>
              <b class="font-noraml">用户性别：</b>
              <p
                class="pull-right"
                v-if="userInfo.Info && userInfo.Info.sex === 1"
              >
                男
              </p>
              <p class="pull-right" v-else>女</p>
            </li>
            <li class="list-group-item">
              <i class="fa fa-phone"></i>
              <b class="font-noraml">手机号码：</b>
              <p class="pull-right" v-if="userInfo.Info">
                {{ userInfo.Info.phone }}
              </p>
            </li>
            <li class="list-group-item">
              <i class="fa fa-map-marker"></i>
              <b class="font-noraml">地址：</b>
              <p class="pull-right" v-if="userInfo.Info">
                {{ userInfo.Info.address }}
              </p>
            </li>
            <li class="list-group-item">
              <i class="fa fa-calendar"></i>
              <b class="font-noraml">注册时间：</b>
              <p class="pull-right">{{ userInfo.createTime | dayFormat }}</p>
            </li>
          </ul>
        </div>
      </div>
    </Shelf>
    <Shelf title="基本资料">
      <div slot="content" class="info2">
        <el-tabs
          type="border-card"
          v-model="activeName"
          style="border: none; box-shadow: none"
        >
          <el-tab-pane name="first" label="基本资料">
            <el-form
              :model="editForm"
              :rules="editFormRules"
              ref="editFormRef"
              label-width="70px"
            >
              <el-form-item label="姓名：" prop="nikeName">
                <el-input v-model="editForm.nikeName"></el-input>
              </el-form-item>
              <el-form-item label="性别：" prop="sex">
                <template>
                  <el-radio v-model="editForm.sex" :label="1">男</el-radio>
                  <el-radio v-model="editForm.sex" :label="0">女</el-radio>
                </template>
              </el-form-item>
              <el-form-item label="电话：" prop="phone">
                <el-input v-model="editForm.phone"></el-input>
              </el-form-item>
              <el-form-item label="地址：" prop="address">
                <el-input v-model="editForm.address"></el-input>
              </el-form-item>
              <el-form-item>
                <el-button @click="reseted">重 置</el-button>
                <el-button type="primary" @click="editSubmit">保 存</el-button>
              </el-form-item>
            </el-form>
          </el-tab-pane>
          <el-tab-pane name="second" label="修改密码">
            <el-form
              :model="addForm"
              :rules="addFormRules"
              ref="addFormRef"
              label-width="80px"
            >
              <el-form-item label="旧密码" prop="oldPassword">
                <el-input
                  type="password"
                  v-model="addForm.oldPassword"
                  autocomplete="off"
                  show-password
                ></el-input>
              </el-form-item>
              <el-form-item label="新密码" prop="password">
                <el-input
                  type="password"
                  v-model="addForm.password"
                  autocomplete="off"
                  show-password
                ></el-input>
              </el-form-item>
              <el-form-item label="确认密码" prop="passwords">
                <el-input
                  type="password"
                  v-model="addForm.passwords"
                  autocomplete="off"
                  show-password
                ></el-input>
              </el-form-item>
              <el-form-item>
                <el-button @click="reseted">重 置</el-button>
                <el-button type="primary" @click="editPwdSubmit"
                  >保 存</el-button
                >
              </el-form-item>
            </el-form>
          </el-tab-pane>
          <el-tab-pane name="third" label="实名认证" v-if="!isAdmin">
            <el-form label-width="90px">
              <el-form-item label="认证状态:">
                <el-tag
                  v-if="userInfo.Info && userInfo.Info.status === 1"
                  type="success"
                  >已实名</el-tag
                >
                <el-tag
                  type="warning"
                  v-else-if="userInfo.Info && userInfo.Info.status === 2"
                  >待审核</el-tag
                >
                <el-tag type="info" v-else>未实名</el-tag>
              </el-form-item>
              <el-form-item label="申请材料:" v-if="userInfo.Info">
                <img
                  v-if="userInfo.Info.authImage"
                  :src="userInfo.Info.authImage"
                  width="90px"
                  @click="handlePreview(userInfo.Info.authImage)"
                />
                <span v-else>暂无</span>
              </el-form-item>
              <el-form-item
                label="审核意见:"
                v-if="
                  userInfo.Info &&
                  userInfo.Info.status === 0 &&
                  userInfo.Info.opinion
                "
              >
                <p>{{ userInfo.Info.opinion }}</p>
              </el-form-item>
              <el-form-item
                label="上传材料:"
                v-if="userInfo.Info && userInfo.Info.status === 0"
              >
                <el-upload
                  ref="auth"
                  class="upload-demo"
                  action
                  :auto-upload="false"
                  :multiple="false"
                  :limit="limit"
                  :on-change="handleUpload"
                  :on-preview="handlePreview"
                  :file-list="fjList"
                >
                  <el-button slot="trigger" size="small" type="primary"
                    >选择材料</el-button
                  >
                </el-upload>
              </el-form-item>
              <el-form-item
                label="实名认证:"
                v-if="userInfo.Info && userInfo.Info.status === 0"
              >
                <el-button size="small" type="success" @click="uploadSubmit"
                  >申请实名</el-button
                >
              </el-form-item>
            </el-form>
          </el-tab-pane>
        </el-tabs>
      </div>
    </Shelf>
    <!-- 嵌套抽屉，用于修改头像（嵌套多层 Drawer,一定要设置 append-to-body 属性为 true） -->
    <el-drawer
      :visible.sync="editAvatarDrawer"
      title="修改头像"
      :append-to-body="true"
      size="30%"
      direction="rtl"
      :modal="false"
    >
      <el-form label-width="70px" ref="editImgFormRef">
        <el-row :gutter="20">
          <el-col :span="24">
            <el-form-item label="原头像:">
              <img
                v-if="userInfo.Info && userInfo.Info.image"
                :src="userInfo.Info.image"
                style="width: 100%; max-width: 90px; height: auto"
              />
              <img
                v-else
                :src="imageDefault"
                style="width: 100%; max-width: 90px; height: auto"
              />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="新头像:">
              <el-upload
                ref="upload"
                class="avatar-uploader"
                list-type="picture-card"
                :on-change="handleChange"
                :auto-upload="false"
                :multiple="false"
                :limit="limit"
                action
              >
                <i class="el-icon-plus"></i>
              </el-upload>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-button style="margin-left: 70px" @click="editAvatarDrawer = false"
        >取 消</el-button
      >
      <el-button type="primary" @click="editImgSubmit">确 定</el-button>
    </el-drawer>
    <!-- 图片预览 -->
    <el-dialog
      :visible.sync="dialogVisible"
      width="35%"
      title="审核文件"
      @close="dialogVisible = false"
    >
      <img width="100%" :src="dialogImageUrl" alt />
    </el-dialog>
  </div>
</template>

<script>
  import Shelf from '@/common/Shelf'
  import { mapState, mapMutations } from 'vuex'
  import { checkMobile } from '@/utils/regexp.js'
  import {
    changeUserImage,
    changeUserInfo,
    changeUserPwd,
    changeUserAuth
  } from '../../api'
  export default {
    components: {
      Shelf
    },
    data() {
      const checkPwd = (rule, value, callback) => {
        let pattern = /^[A-Za-z0-9]{6,16}$/
        if (value != this.addForm.oldPassword) {
          if (!pattern.test(value)) {
            callback(new Error('密码只能由英文、数字组成的6-16位!'))
          } else {
            callback()
          }
        } else {
          callback(new Error('新密码不能跟旧密码一样'))
        }
      }
      // 验证二次密码的规则
      const checkPwdS = (rule, value, callback) => {
        if (value === this.addForm.password) return callback()
        callback(new Error('两次密码不一致'))
      }
      return {
        activeName: 'first',
        imageDefault: require('../../assets/image/el-avatar.png'),
        limit: 1,
        addForm: {
          oldPassword: '',
          password: '',
          passwords: ''
        },
        addFormRules: {
          oldPassword: [
            { required: true, message: '请输入旧密码', trigger: 'blur' }
          ],
          password: [
            { required: true, message: '请输入新密码', trigger: 'blur' },
            { validator: checkPwd, trigger: 'blur' }
          ],
          passwords: [
            { required: true, message: '两次密码不一致', trigger: 'blur' },
            { validator: checkPwdS, trigger: 'blur' }
          ]
        },
        editAvatarDrawer: false, // 控制修改头像抽屉的显示
        fileList: [], //上传头像列表
        fjList: [], //申请实名材料
        // 查询到的用户信息对象
        editForm: {},
        // 修改表单的验证规则对象
        editFormRules: {
          sex: [{ required: true, message: '请选择性别', trigger: 'blur' }],
          nikeName: [
            { required: true, message: '请输入姓名', trigger: 'blur' }
          ],
          phone: [
            { required: true, message: '请输入手机号', trigger: 'blur' },
            { validator: checkMobile, trigger: 'blur' }
          ],
          address: [{ required: true, message: '请输入地址', trigger: 'blur' }]
        },
        dialogVisible: false,
        dialogImageUrl: ''
      }
    },
    created() {},
    computed: {
      ...mapState(['userInfo', 'isAdmin'])
    },
    created() {
      this.getEditfrom()
      if (this.$route.query.activeName)
        this.activeName = this.$route.query.activeName
    },
    watch: {
      $route(route) {
        this.getEditfrom()
        if (route.query.activeName) this.activeName = route.query.activeName
      }
    },
    methods: {
      ...mapMutations(['syncLogout']),
      //获取用户信息
      getEditfrom() {
        this.editForm = JSON.parse(JSON.stringify(this.userInfo))
        this.editForm = this.editForm?.Info || {}
      },
      reseted() {
        this.$refs.addFormRef?.resetFields() //重置修改修改密码表单
        this.$refs.editFormRef?.resetFields() //重置修改基本信息表单
        this.$refs.editImgFormRef?.resetFields() //重置上传头像表单
        this.$refs.upload?.clearFiles() //重置上传组件
        this.fileList = []
        this.fjList = []
        this.getEditfrom()
      },
      // 修改信息并提交
      editSubmit() {
        this.$refs.editFormRef.validate(async (valid) => {
          if (!valid) return
          const res = await changeUserInfo(this.editForm)
          if (res.code !== 200) return this.$message.error(res.message)
          this.$message.success(res.message)
          this.$router.replace({
            path: this.$route.fullPath,
            query: { _t: Date.now(), activeName: 'first' }
          })
        })
      },
      // 修改密码并提交
      editPwdSubmit() {
        this.$refs.addFormRef.validate(async (valid) => {
          if (!valid) return
          const res = await changeUserPwd(this.addForm)
          if (res.code !== 200) return this.$message.error(res.message)
          this.$message.success('修改成功，1秒后自动退出，请重新登录!')
          setTimeout((_) => {
            this.syncLogout()
            this.$router.replace({ path: '/' })
          }, 1000)
        })
      },
      // 选择头像图片
      handleChange(file, fileList) {
        if (fileList.length > 1) fileList = fileList.slice(-1)
        this.fileList = fileList
      },
      // 更换头像
      async editImgSubmit() {
        if (this.fileList.length == 0)
          return this.$message.info('新头像不能为空!')
        let formData = new FormData()
        formData.append('image', this.fileList[0].raw)
        // 发起修改数据请求
        const res = await changeUserImage(formData)
        if (res.code !== 200) return this.$message.error(res.message)
        this.$message.success(res.message)
        this.editDialogVisible = false
        this.$router.replace({
          path: this.$route.fullPath,
          query: { _t: Date.now() }
        })
        this.reseted()
      },
      // 选择附件图片
      handleUpload(file, fileList) {
        if (fileList.length > 1) fileList = fileList.slice(-1)
        this.fjList = fileList
      },
      // 申请实名
      async uploadSubmit() {
        if (
          !this.userInfo?.Info.nikeName ||
          !this.userInfo?.Info.phone ||
          !this.userInfo?.Info.address
        ) {
          return this.$message.info('请完成基本信息再进行实名认证申请!')
        }
        if (this.fjList.length === 0)
          return this.$message.info('申请材料不能为空!')
        const formData = new FormData()
        formData.append('authImage', this.fjList[0].raw)
        // 发起修改数据请求
        const res = await changeUserAuth(formData)
        if (res.code !== 200) return this.$message.error(res.message)
        this.$message.success(res.message)
        this.editDialogVisible = false
        this.$router.replace({
          path: this.$route.fullPath,
          query: { _t: Date.now(), activeName: 'third' }
        })
        this.reseted()
      },
      // 图片预览
      handlePreview(url) {
        if (url?.raw) {
          const reader = new FileReader()
          reader.readAsDataURL(url.raw)
          reader.onload = () => {
            this.dialogImageUrl = reader.result
            this.dialogVisible = true
          }
        } else {
          this.dialogImageUrl = url
          this.dialogVisible = true
        }
      },
      // 显示修改头像抽屉的方法
      showEditAvatarDrawer() {
        this.editAvatarDrawer = true
      }
    }
  }
</script>

<style lang="less" scoped>
  .main {
    // min-width: 900px;
    // min-height: 564px;
    display: flex;
    flex-direction: column;
    // align-items: center;
    padding: 0;
    box-sizing: border-box;
    width: 100%;
    .info1 {
      // width: 400px;
      width: 100%;
      // height: 486px;
      max-width: 100%;
      box-sizing: border-box;
      // 个人资料
      .ibox-content {
        clear: both;
        background-color: #ffffff;
        color: inherit;
        padding: 15px 20px 20px 20px;
        border-color: #e7eaec;
        -webkit-border-image: none;
        -o-border-image: none;
        border-image: none;
        border-style: solid solid none;
        border-width: 1px 0px;
        .text-center {
          text-align: center;
          .user-info-head {
            position: relative;
            display: inline-block;
            .img-lg {
              width: 120px;
              height: 120px;
              border-radius: 50%;
              vertical-align: middle;
              border: 0;
            }
          }
          p {
            margin: 0 0 10px;
          }
        }
        ul {
          display: block;
          list-style-type: disc;
          margin-block-start: 1em;
          margin-inline-end: 0px;
          padding-inline-start: 40px;
        }
        .list-group {
          padding-left: 0;
          margin-bottom: 20px;

          .list-group-item {
            border: 1px solid #e7eaec;
            display: block;
            margin-bottom: -1px;
            padding: 10px 15px;
            position: relative;
            .font-noraml {
              font-weight: 400;
              margin-left: 5px;
            }
            p {
              margin: 0 0 10px;
            }
          }
        }
      }
    }
    .info2 {
      // min-width: 750px;
      // height: 486px;
      width: 100%;
      max-width: 100%;
      box-sizing: border-box;
    }

    el-tab-pane {
      padding: 15px 20px 20px;
    }

    .shelf {
      margin: 0;
      padding: 0;
      width: 100%;
      box-sizing: border-box;
    }
  }
</style>
