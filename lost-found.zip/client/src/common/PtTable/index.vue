<template>
  <div>
    <!-- 自定义高级搜索插槽 -->
    <el-row><slot name="searchBox"></slot></el-row>
    <el-row :gutter="30">
      <el-col :span="6" v-if="search">
        <el-input
          :placeholder="searchTitle"
          v-model="queryParams.search"
          clearable
          @clear="onSearch"
          @keyup.enter.native="handleSearch"
        >
          <el-button
            slot="append"
            icon="el-icon-search"
            @click="handleSearch"
          ></el-button>
        </el-input>
      </el-col>
      <el-col :span="4" v-if="selectList.length">
        <el-select
          v-model="queryParams.select"
          :placeholder="selectTitle"
          clearable
          @change="handleChoose"
        >
          <el-option
            v-for="(item, index) in selectList"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-col>
      <el-col :span="13">
        <template>
          <slot name="operateBtn"></slot>
        </template>
      </el-col>
    </el-row>
    <!-- :header-cell-style="{ textAlign: `${headerStyle}` }"
      :cell-style="{ textAlign: `${cellStyle}` }" -->
    <el-table
      class="public-table"
      ref="PtTable"
      :max-height="tableHeight ? tableHeight : ''"
      :data="newItems"
      :size="size"
      :border="border"
      :stripe="stripe"
      :show-header="showHeader"
      :fit="fit"
      :row-class-name="handleClassName"
      @selection-change="handleSelect"
      @row-click="handleClick"
      @sort-change="handleSort"
      v-loading="newLoading"
      :element-loading-text="loadingText"
    >
      <!-- 自定义操作列作用域插槽 -->
      <el-table-column type="expand" v-if="expand">
        <template slot-scope="scope">
          <slot name="expandBox" :row="scope.row"></slot>
        </template>
      </el-table-column>

      <el-table-column
        class="selection"
        type="selection"
        width="55"
        v-if="select"
        :align="cellStyle"
      ></el-table-column>

      <el-table-column
        v-for="(item, index) in columns"
        :class="item.prop"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :fixed="item.fixed"
        :align="item.align || 'center'"
        :sortable="item.sortable"
        :index="index"
        show-overflow-tooltip
      >
        <template slot-scope="{ row, $index }">
          <!-- Input默认展示 -->
          <span v-if="item.type === 'Input' && !item.editRow">{{
            row[item.prop]
          }}</span>
          <!-- Object三级对象展示 -->
          <span v-if="item.type === 'Object' && row[item.prop]">{{
            row[item.prop][item.children]
          }}</span>
          <!-- Custom自定义返回内容 -->
          <span v-if="item.type === 'Custom' && item.prop">{{
            item.callback(row[item.prop], $index)
          }}</span>
          <span v-if="item.type === 'Custom' && !item.prop">{{
            item.callback(row, $index)
          }}</span>
          <!-- switch开关 -->
          <el-switch
            v-if="item.type === 'Switch'"
            :value="row[item.prop]"
            :active-color="item.activeColor || '#13ce66'"
            :inactive-color="item.inactiveColor || '#ff4949'"
            :active-value="
              item.activeValue !== undefined ? item.activeValue : 1
            "
            :inactive-value="
              item.inactiveValue !== undefined ? item.inactiveValue : 0
            "
            :inactive-text="
              item.text ? (row[item.prop] ? item.openText : item.closeText) : ''
            "
            @change="handleSwitch(row, $index, item.prop)"
          ></el-switch>
          <!-- Image图片支持预览view -->
          <el-popover trigger="hover" placement="top" popper-class="popper">
            <template
              v-if="item.type === 'Image' && item.view && row[item.prop]"
            >
              <img
                v-if="row[item.prop]"
                :src="row[item.prop]"
                :width="item.imgW"
                :height="item.imgH || '400px'"
              />
              <el-image
                slot="reference"
                v-if="row[item.prop]"
                :src="row[item.prop]"
              ></el-image>
            </template>
            <!-- 三级对象展示图片 -->
            <template
              v-if="item.type === 'ObjectImg' && item.view && row[item.prop]"
            >
              <img
                v-if="row[item.prop][item.children]"
                :src="row[item.prop][item.children]"
                :width="item.imgW"
                :height="item.imgH || '400px'"
              />
              <el-image
                slot="reference"
                v-if="row[item.prop][item.children]"
                :src="row[item.prop][item.children]"
              ></el-image>
            </template>
          </el-popover>
          <!-- mltImg多图点击预览:未封装完成 -->
          <template v-if="item.type === 'mltImg'">
            <el-image
              slot="reference"
              v-if="row[item.prop]"
              :src="row[item.prop]"
              :preview-src-list="srcList"
            ></el-image>
          </template>
          <!-- 图片不支持预览view -->
          <template
            v-if="item.type === 'Image' && !item.view && row[item.prop]"
          >
            <el-image
              slot="reference"
              v-if="row[item.prop]"
              :src="row[item.prop]"
            ></el-image>
          </template>
          <!-- ObjectImg图片不支持预览且三级对象展示图片 -->
          <template
            v-if="item.type === 'ObjectImg' && !item.view && row[item.prop]"
          >
            <el-image
              slot="reference"
              v-if="row[item.prop][item.children]"
              :src="row[item.prop][item.children]"
            ></el-image>
          </template>

          <!-- 可编辑input，仅在text默认展示类型才可编辑 v-focus-->
          <el-input
            v-if="item.editRow && item.type === 'Input'"
            v-model="row[item.prop]"
            @blur="handleEditBlur(row, $index, item.prop, index)"
          ></el-input>
          <!-- Tag标签展示-->
          <el-tag
            v-if="item.type === 'Tag' && !item.children"
            :type="item.tagValue || item.tagType[row[item.prop]]"
          >
            {{ item.callback(row[item.prop], $index) }}
          </el-tag>
          <el-tag
            v-else-if="item.type === 'Tag' && item.children"
            :type="item.tagValue || item.tagType[row[item.prop][item.children]]"
          >
            {{ item.callback(row[item.prop], $index) }}
          </el-tag>
        </template>
      </el-table-column>

      <!-- 自定义操作列作用域插槽 -->
      <el-table-column
        class="operateBox"
        v-if="operation.value"
        :align="cellStyle"
        :label="operation.label"
        :min-width="operation.width || '240px'"
      >
        <template slot-scope="scope">
          <slot name="operateBox" :row="scope.row"></slot>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页区域 -->
    <el-pagination
      class="pagination"
      v-if="pagination"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="queryParams.page"
      :page-sizes="pageSizes"
      :page-size="queryParams.limit"
      :layout="pgLayout"
      :total="newTotal"
    ></el-pagination>
  </div>
</template>

<script>
  import { query } from '@/api/request'
  export default {
    name: 'tableContainer',
    props: {
      searchTitle: {
        type: String,
        default: '请输入内容'
      },
      selectTitle: {
        type: String,
        default: '请选择'
      },
      // 下拉选择数据源
      selectList: {
        type: Array,
        default: () => []
      },
      loading: {
        type: Boolean,
        default: true
      }, //是否开启加载效果
      loadingText: {
        type: String,
        default: '数据加载中'
      }, //加载效果
      total: {
        type: Number,
        default: 0
      },
      /*如果不传获取数据源的接口，则默认使用数据源方式展示*/
      tableData: {
        type: Array,
        default: () => []
      }, //数据源
      url: { type: String }, //获取数据源的接口
      search: {
        type: Boolean,
        default: true
      }, //搜索列
      pagination: {
        type: Boolean,
        default: true
      }, //控制分页组件

      select: {
        type: Boolean,
        default: false
      }, //多选框列-默认隐藏

      pageSizes: {
        type: Array,
        default: () => [1, 3, 5, 10]
      }, //一页加载量选择
      pgLayout: {
        type: String,
        default: 'total, sizes, prev, pager, next, jumper'
      }, //分页组件布局

      queryParams: {
        type: Object,
        default: () => {
          return {
            search: '', //搜索关键词
            page: 1, // 当前的页数
            limit: 5, // 当前每页显示多少条数据
            status: '', //默认查询条件''为对应后端操作的查询所有<除了逻辑删除的>
            sort: JSON.stringify({}), //默认排序可以不传，排序方式:按降序desc:-1,升序:1 如根据id降序排序==> JSON.stringify({id:-1})
            select: '' //下拉分类选择
          }
        }
      }, // 查询参数体
      columns: {
        type: Array,
        default: () => []
      }, //表格展示列
      operation: {
        type: Object,
        default: () => {
          return {
            label: '操作',
            value: false
          }
        }
      },
      expand: {
        type: Boolean,
        default: false
      }, //开启扩展列插槽(默认关闭)
      /* 表格样式 */
      tableHeight: {
        type: String,
        default: '600px'
      }, //表格最大高度
      headerStyle: {
        type: String,
        default: 'center' //默认居中
      }, //表头样式
      cellStyle: {
        type: String,
        default: 'center' //默认居中
      }, //内容样式
      border: {
        type: Boolean,
        default: true
      }, //外部边框
      stripe: {
        type: Boolean,
        default: true
      }, //斑马线
      size: {
        type: String,
        default: 'medium'
      }, //表格尺寸
      showHeader: {
        type: Boolean,
        default: true
      }, //是否显示表头
      fit: {
        type: Boolean,
        default: true
      } //是否自动撑开列
    },
    data() {
      return {
        items: [], //数据源
        count: 0, //总页数
        newLoading: false, //加载动效
        //TODO:未封装
        srcList: [
          'https://fuss10.elemecdn.com/8/27/f01c15bb73e1ef3793e64e6b7bbccjpeg.jpeg',
          'https://fuss10.elemecdn.com/1/8e/aeffeb4de74e2fde4bd74fc7b4486jpeg.jpeg'
        ]
      }
    },
    created() {
      this.getTableList()
    },
    computed: {
      /**
       * 子组件接收父组件数据源两种方式：url/data
       */
      newItems() {
        return Boolean(this.url) ? this.items : this.tableData
      },
      newTotal() {
        return Boolean(this.url) ? this.count : this.total
      }
    },
    methods: {
      //获取数据列表
      async getTableList() {
        this.newLoading = this.loading
        if (!Boolean(this.url)) {
          this.newLoading = false
          return
        } //不以url形式获取数据
        this.queryParams.search = this.queryParams.search.trim()
        const res = await query(this.url, this.queryParams)
        this.newLoading = false
        if (res.code !== 200) return this.$message.error(res.message)
        this.items = res.data.rows //数组对象
        this.count = res.data.count //总数据
      },
      // 点击行
      handleClick(row, column, event) {
        this.$emit('rowClick', row, column, event)
      },
      // 帮助点击行，获取点击的下标(给每行数据追加索引字段)
      handleClassName({ row, rowIndex }) {
        row.rowIndex = rowIndex
      },
      //多选框值变化回调
      handleSelect(rows) {
        this.$emit('onSelect', rows)
      },
      //搜索
      handleSearch() {
        // if (!this.queryParams.search.trim()) return;//空值暂时开放允许查询
        this.queryParams.search = this.queryParams.search.trim()
        this.onSearch()
      },
      onSearch() {
        /* 重置其他查询条件 */
        this.queryParams.page = 1 //重置初始页
        this.$emit('onSearch', this.queryParams) //向父组件传值
        this.$emit('onChange', this.queryParams) //向父组件传值
        this.getTableList()
      },
      // 监听 加载量 改变的事件
      handleSizeChange(newSize) {
        this.queryParams.limit = newSize
        this.$emit('onChange', this.queryParams) //向父组件传值
        this.getTableList()
      },
      // 监听 页码值 改变的事件
      handleCurrentChange(newPage) {
        this.queryParams.page = newPage
        this.$emit('onChange', this.queryParams) //向父组件传值
        this.getTableList()
      },
      // 监听 switch 开关状态的改变
      handleSwitch(row, index, prop) {
        if (row[prop] === 1) row[prop] = 0
        else if (row[prop] === '1') row[prop] = '0'
        else if (row[prop] === 0) row[prop] = 1
        else if (row[prop] === '0') row[prop] = '1'
        else row[prop] = !row[prop]
        this.$emit('onSwitch', row[prop], row, index, prop) //向父组件传值
      },
      // 可编辑input失去焦点
      handleEditBlur(row, index, prop, columIndex) {
        this.$emit('onBlur', row, index, prop, columIndex)
      },
      // 监听下拉触发
      handleChoose(e) {
        this.$emit('onChoose', e, this.queryParams) //向父组件传值
        this.getTableList()
      },
      // 监听排序
      handleSort({ column, prop, order }) {
        const sort = {
          ascending: 1, //升序
          descending: -1 //降序
        }
        this.queryParams.sort = JSON.stringify({ [prop]: sort[order] })
        this.$emit('onSort', this.queryParams) //向父组件传值
        this.getTableList()
      }
    }
  }
</script>

<style lang="less" scoped>
  /* ElementUI表格组件样式 */
  .el-table {
    margin-top: 15px;
    font-size: 12px;
  }
  /* ElementUI分页组件样式 */
  .el-pagination {
    margin-top: 15px;
  }
  //标签
  .el-tag {
    margin: 7px;
  }
  // 顶部线条
  .bdtop {
    border-top: 1px solid #eee;
  }
  // 底部线条
  .bdbottom {
    border-bottom: 1px solid #eee;
  }
  /deep/.el-image__inner {
    height: 50px;
  }
</style>
