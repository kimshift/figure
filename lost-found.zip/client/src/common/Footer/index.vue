<template>
  <div class="footer">
    <div class="ng-promise-box">
      <div class="ng-promise">
        <p class="text">
          <a href="javascript:;">为失主寻失物</a>
          <a href="javascript:;">诚信-和谐-自由</a>
          <a style="margin-right: 0" href="javascript:;">为拾物找归宿</a>
        </p>
      </div>
    </div>

    <div class="mod_help">
      <p class="coty">平台版权所有 &copy;Mr.Ye</p>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {}
    },
    computed: {},

    methods: {}
  }
</script>

<style scoped>
  .footer {
    width: 100%;
    text-align: center;
    background: #2f2f2f;
    padding-bottom: 20px;
    /* position: fixed;
  left: 0;
  bottom: 0;
  z-index: 100; */
  }
  .footer .ng-promise-box {
    margin: 0 auto;
    border-bottom: 1px solid #3d3d3d;
    line-height: 100px;
  }
  .footer .ng-promise-box .ng-promise p a {
    color: #fff;
    font-size: 20px;
    margin-right: 210px;
    padding-left: 44px;
    height: 40px;
    display: inline-block;
    line-height: 40px;
    text-decoration: none;
    background: url('../../assets/image/us-icon.png') no-repeat left 0;
  }

  .footer .mod_help {
    text-align: center;
    color: #888888;
  }
  .footer .mod_help p {
    margin-top: 15px;
  }

  .footer .mod_help p a {
    color: #888888;
    text-decoration: none;
  }
  .footer .mod_help p a:hover {
    color: #fff;
  }
  .footer .mod_help p span {
    padding: 0 22px;
  }
</style>
