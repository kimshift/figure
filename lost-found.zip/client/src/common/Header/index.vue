<template>
  <div class="header-box">
    <div class="page-container clearfix">
      <el-row :gutter="20" class="nav">
        <el-col :span="5">
          <a href="/" title="校园失物招领">
            <img src="../../assets/image/system.png" class="logo" />
            <span style="margin-left: 1rem">校园失物招领</span>
          </a>
        </el-col>
        <el-col :span="8">
          <el-input placeholder="请输入物品名称" v-model="queryParams.search" clearable @clear="handleSearch"
            @keyup.enter.native="handleSearch">
            <el-button slot="append" icon="el-icon-search" @click="handleSearch"></el-button>
          </el-input>
        </el-col>
        <el-col :span="11">
          <div class="rBox">
            <a href="javascript:void(0)" @click="goPath('/forum')" class="mar"
              :class="{ active: this.$route.name == '论坛' }">论坛</a>
            <a href="javascript:void(0)" @click="goPath('/about')" class="mar"
              :class="{ active: this.$route.name == '公告和留言' }">公告和留言</a>
            <a href="javascript:void(0)" @click="goPath('/allGoods')" class="mar"
              :class="{ active: this.$route.name == '全部物品' }">全部物品</a>
            <a href="javascript:void(0)" class="mar" @click="goPath('/createGoods')"
              :class="{ active: this.$route.name == '信息发布中心' }">信息发布中心</a>
            <div class="user">
              <el-menu mode="horizontal">
                <el-submenu index="2" v-if="isLogin">
                  <template slot="title">
                    <el-avatar v-if="userInfo.Info && userInfo.Info.image" :size="40"
                      :src="userInfo.Info.image"></el-avatar>
                    <img src="../../assets/image/el-avatar.png" alt width="40px" v-else />
                    <span class="info">{{ userInfo.username }}</span>
                  </template>
                  <el-menu-item>
                    <!-- <router-link :to="{ path: '/user' }"> -->
                    <el-dropdown-item @click.native.prevent="showDrawer = true">
                      <span>个人中心</span>
                    </el-dropdown-item>
                    <!-- </router-link> -->
                  </el-menu-item>
                  <el-menu-item v-if="isAdmin">
                    <router-link :to="{ path: '/admin' }">
                      <el-dropdown-item>
                        <span>后台管理</span>
                      </el-dropdown-item>
                    </router-link>
                  </el-menu-item>
                  <el-menu-item v-if="isLogin">
                    <el-dropdown-item @click.native.prevent="showIssues = true">
                      <span>留言板</span>
                    </el-dropdown-item>
                  </el-menu-item>
                  <el-menu-item>
                    <el-dropdown-item @click.native="logout">
                      <span>退出登录</span>
                    </el-dropdown-item>
                  </el-menu-item>
                </el-submenu>
                <div class="info" v-else>
                  <a href="javascript:void(0);" @click.prevent="operate(1)">登录</a>
                  <span class="sep">|</span>
                  <a href="javascript:void(0);" @click.prevent="operate(0)">注册</a>
                </div>
              </el-menu>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
    <!-- 登录模块 -->
    <Login></Login>
    <!-- 注册模块 -->
    <Register></Register>

    <!-- 抽屉组件 -->
    <el-drawer :visible.sync="showDrawer" title="个人中心" size="30%" direction="rtl">
      <UserInfo :userInfo="userInfo"></UserInfo>
    </el-drawer>
    <!-- 留言对话框 -->
    <el-dialog title="留言" :visible.sync="showIssues" width="600px">
      <el-input v-model.trim="content" type="textarea" rows="3"></el-input>
      <div slot="footer" class="dialog-footer">
        <el-button @click="showIssues = false">取 消</el-button>
        <el-button type="primary" @click="postIssues">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import Login from '../../components/Login'
import Register from '../../components/Register'
import UserInfo from '../UserInfo'
import { postIssues } from '@/api'
export default {
  components: {
    Login,
    Register,
    UserInfo
  },
  data() {
    return {
      showDrawer: false, // 控制抽屉显示的变量
      showIssues: false,
      content: "",
    }
  },
  computed: {
    ...mapState(['userInfo', 'isLogin', 'isAdmin', 'queryParams'])
  },
  created() { },
  methods: {
    ...mapMutations([
      'setShowLoginOrRegister',
      'syncLogout',
      'setQueryParams'
    ]),
    operate(flag) {
      const params = {
        showLogin: flag === 1,
        showRegister: flag === 0
      }
      this.setShowLoginOrRegister(params)
    },
    handleSearch() {
      const params = {}
      const { cateId, search } = this.queryParams
      if (search?.trim()) params.search = search
      if (cateId) params.cateId = cateId
      this.queryParams.page = 1
      this.setQueryParams({ ...this.queryParams, ...params })
      this.$router.replace({
        path: '/allGoods',
        query: params
      })
    },
    goPath(url) {
      if (url === '/createGoods') {
        if (!this.isLogin) return this.notifyInfo('请先进行登录操作！')
        if (this.userInfo?.Info.status !== 1) {
          return this.notifyInfo(
            '请先前往个人中心进行实名认证，发布信息需要先进行实名认证!'
          )
        }
      }
      this.$router.push({ path: url }) //默认跳转
    },
    // 退出登录
    logout() {
      this.notifyInfo('正在退出')
      setTimeout((_) => {
        this.syncLogout()
        if (this.$route.meta.login) this.$router.replace('/')
        this.notifyInfo('退出成功')
      }, 1000)
    },
    async postIssues() {
      if (!this.content) {
        return this.$message.warning('请输入留言内容')
      }
      const res = await postIssues({ content: this.content })
      if (res.code !== 200) {
        return this.$message.error(res.message)
      }
      this.$message.success('留言成功')
      this.showIssues = false
      this.content = ''
    }
  }
}
</script>

<style lang="less">
.header-box {
  z-index: 30;
  background-image: linear-gradient(#ffffff, #ffffff);
  height: 70px;

  .page-container {
    width: 1225px;
    z-index: 30;
    // border-bottom: 1px #e6e6e6 solid;
    position: relative;
    line-height: 70px;
    margin: 0 auto;

    .logo {
      margin-left: 50px;
      width: 40px;
    }

    .rBox {
      display: flex;
      justify-content: flex-end;

      .mar {
        margin: 0 0.9rem;
      }

      .active {
        color: #c81623;
      }

      .user {
        line-height: 70px;
        height: 70px;
        vertical-align: auto;
        display: flex; //弹性
        align-items: center;

        .img {
          display: block;
        }

        .info {
          margin: 0 0 0 1rem;
          color: black;
        }
      }

      a {
        text-decoration: none;
        text-align: center;
        font-size: 16px;
        position: relative;
      }
    }

    .sep {
      margin: 0 5px;
    }
  }

  // 下拉菜单
  .el-dropdown-link {
    cursor: pointer;
    // color: #409eff;
  }

  .el-icon-arrow-down {
    font-size: 16px;
  }

  // element-ui中去掉el-menu菜单栏中下划线
  .el-menu.el-menu--horizontal {
    border: none;

    .el-menu-item {
      line-height: 67px;
    }
  }

  .el-menu--horizontal>.el-submenu.is-active .el-submenu__title {
    border-bottom: none !important;
  }

  // 修改el-menu宽度
  .user .el-menu--collapse .el-menu .el-submenu,
  .el-menu--popup {
    min-width: 120px !important;
  }

  // 隐藏el-menu的三角图标
  .el-submenu__title {
    i {
      display: none;
    }
  }

  // 去除子菜单填充样式
  .el-menu--horizontal .el-menu .el-menu-item,
  .el-menu--horizontal .el-menu .el-submenu__title {
    padding: 0;
    text-align: center;
  }

  //抽屉
  .el-drawer__header {
    // background-color: #f5faf5;
    color: #25b6f4;
    font-size: 16px;
    font-weight: 500;
    height: 50px;
    line-height: 50px;
    text-align: start;
    align-items: center;
    display: flex;
    margin-bottom: 32px;
    padding: 20px 20px 0;
  }
}
</style>
