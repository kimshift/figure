<template>
  <div class="markdown-body">
    <vue-markdown :source="md"></vue-markdown>
  </div>
</template>
<script>
import VueMarkdown from 'vue-markdown';
import { query } from '@/api/request';
export default {
  name: 'Markdown',
  components: {
    VueMarkdown,
  },
  data() {
    return {
      md: '',
    };
  },
  async created() {
    // 从后端请求README.md
    try {
      const res = await query('/getMdFile');
      if (res.code !== 200) return this.notifyError(res.message);
      this.md = res.data;
    } catch (error) {
      console.log('测试:', error)
    }
  },
};
</script>
<style>
@import '../../assets/css/github-markdown.css';

.markdown-body {
  box-sizing: border-box;
  padding: 0 40px;
}
</style>
