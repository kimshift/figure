import { timeFormat } from '@/utils/timeFormat'
/* 用户列表数据列配置 */
export const columns = [
  {
    type: 'ObjectImg', //三级对象展示头像
    prop: 'Info',
    children: 'image',
    // view: true,//支持预览
    label: '头像'
  },
  {
    type: 'Input', //正常文本
    prop: 'username',
    label: '账号'
  },
  {
    type: 'Object',
    prop: 'Info',
    children: 'nikeName',
    label: '姓名'
  },
  {
    type: 'Tag',
    label: '性别',
    prop: 'Info',
    children: 'sex',
    tagType: {
      0: 'success',
      1: ''
    },
    width: '100px',
    callback: (item) => {
      return Number(item.sex) === 1 ? '男' : '女'
    }
  },
  {
    type: 'Object',
    prop: 'Info',
    children: 'phone',
    label: '手机号码'
  },
  {
    type: 'Object',
    prop: 'Info',
    children: 'address',
    label: '地址'
  },
  {
    type: 'Tag',
    label: '实名认证',
    prop: 'Info',
    children: 'status',
    tagType: {
      0: 'info',
      1: 'success',
      2: 'warning'
    },
    width: '100px',
    callback: (item) => {
      const temp = {
        0: '未实名',
        1: '已实名',
        2: '待审核'
      }
      return temp[item.status]
    }
  },
  {
    type: 'Switch',
    prop: 'status',
    label: '状态'
  }
]

/* 操作列配置 */
export const operation = {
  label: '操作',
  value: true, //是否开启操作列
  width: '150px'
}
