import { timeFormat } from '@/utils/timeFormat'
export const columns = [
  {
    type: 'Input',
    prop: 'id',
    label: '编号',
  },
  {
    type: 'Input',
    prop: 'comment_username',
    label: '评论者',
  },
  {
    type: 'Input',
    prop: 'content',
    label: '评论内容',
  },
  {
    type: 'Custom',
    label: '评论时间',
    callback: item => {
      return timeFormat(item.create_time)
    },
  },
]

/* 操作列配置 */
export const operation = {
  label: '操作',
  value: true, //是否开启操作列
  width: '100px',
}
