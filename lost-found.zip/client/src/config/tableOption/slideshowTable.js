/* 轮播图数据列配置 */
export const columns = [
  {
    type: 'Input',
    prop: 'id',
    label: '编号',
  },
  {
    type: 'Object',
    prop: 'Good',
    children:'goodsName',
    label: '关联商品',
  },
  {
    type: 'Custom',
    label: '物品类型',
    width: '100px',
    callback: item => {
      const temp = {
        0: '失物',
        1: '拾物',
      }
      return temp[item.type]
    },
  },
  {
    type: 'Image',
    prop: 'image',
    view: true,
    label: '轮播图',
  },
  {
    type: 'Input',
    prop: 'introduce',
    label: '描述',
  },
  {
    type: 'Switch',
    prop: 'status',
    label: '状态',
  },
]

/* 操作列配置 */
export const operation = {
  label: '操作',
  value: true, //是否开启操作列
  width:'100px'
}