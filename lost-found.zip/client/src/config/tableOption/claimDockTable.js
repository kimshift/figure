import { timeFormat } from '@/utils/timeFormat'
/* 失物寻回列表数据列配置---(第一层表头配置) */
export const columns = [
  {
    type: 'ObjectImg', //三级对象展示头像
    prop: 'Good',
    children: 'image',
    // view: true,//支持预览
    label: '物品图像',
  },
  {
    type: 'Object',
    prop: 'Good',
    children: 'goodsName',
    width: '120px',
    label: '物品名称',
  },
  {
    type: 'Input',
    prop: 'nikeName',
    label: '申请人',
    width: '120px',
  },
  {
    type: 'Custom',
    prop: 'distribution',
    label: '交接方式',
    width: '120px',
    callback: item => {
      return Number(item) ? '邮寄' : '自取'
    },
  },

  {
    type: 'Custom',
    prop: 'createTime',
    label: '申请时间',
    callback: item => {
      return timeFormat(item)
    },
  },
  {
    type: 'Tag',
    label: '审核状态',
    prop: 'examineStatus',
    tagType: {
      '-1': 'danger', //不通过
      0: 'warning', //待审核
      1: 'success', //通过
      2: 'info', //回退
    },
    width: '100px',
    callback: item => {
      const label = {
        '-1': '不通过',
        0: '待审核',
        1: '通过',
        2: '回退',
      }
      return label[item]
    },
  },
  {
    type: 'Tag',
    label: '寻回状态',
    prop: 'claimStatus',
    tagType: {
      '-1': 'danger', //寻回终止
      0: 'info', //寻回暂停
      1: 'warning', //寻回中
      2: 'success', //寻回完成
    },
    width: '120px',
    callback: item => {
      const label = {
        '-1': '寻回终止',
        0: '寻回暂停',
        1: '寻回中',
        2: '寻回完成',
      }
      return label[item]
    },
  },
]

/* 操作列配置 */
export const operation = {
  label: '操作',
  value: true, //是否开启操作列
  width: '100px',
}
