import { timeFormat } from '@/utils/timeFormat'
/* 用户列表数据列配置 */
export const columns = [
  {
    type: 'Image',
    prop: 'image',
    view: true,
    label: '物品图像',
  },
  {
    type: 'Custom',
    prop: 'User',
    label: '发布者',
    callback: row => {
      return row?.Info.nikeName
    },
  },
  {
    type: 'Input',
    prop: 'goodsName',
    label: '物品名称',
  },
  {
    type: 'Object',
    prop: 'Cate',
    children: 'cateName',
    label: '物品分类',
  },
  {
    type: 'Custom',
    prop: 'createTime',
    sortable: 'custom', //后端控制排序
    label: '发布时间',
    callback: row => {
      return timeFormat(row.createTime)
    },
  },
  {
    type: 'Switch',
    prop: 'status',
    label: '发布状态',
  },
  {
    type: 'Tag',
    label: '寻回状态',
    prop: 'findStatus',
    tagType: {
      0: 'warning',
      1: 'success',
    },
    width: '100px',
    callback: item => {
      return Number(item) === 1 ? '已寻回' : '待寻回'
    },
  },
]

/* 操作列配置 */
export const operation = {
  label: '物品管理',
  value: true, //是否开启操作列
  width: '150px',
}
