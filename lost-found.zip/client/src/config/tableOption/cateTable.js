/* 分类列表数据列配置 */
export const columns = [
  {
    type: 'Input',
    prop: 'id',
    label: '分类编号',
  },
  {
    type: 'Input',
    prop: 'cateName',
    label: '分类名称',
  },
  {
    type: 'Input',
    prop: 'introduce',
    label: '分类描述',
  },
]

/* 操作列配置 */
export const operation = {
  label: '操作',
  value: true, //是否开启操作列
  width: '100px',
}
