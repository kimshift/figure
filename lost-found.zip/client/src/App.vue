<template>
  <div id="app">
    <Header v-if="!hideHeaderTop" />
    <HeaderNav v-if="!hideHeaderNav" />
    <router-view></router-view>
    <Footer v-if="!hideFooter" />
  </div>
</template>

<script>
import Header from './common/Header';
import HeaderNav from './components/HeaderNav';
import Footer from './common/Footer';
export default {
  name: 'app',
  components: {
    Header,
    HeaderNav,
    Footer,
  },
  data() {
    return {
      hideHeaderTop: true,
      hideHeaderNav: true,
      hideFooter: true,
    };
  },
  watch: {
    $route() {
      const { matched } = this.$route;
      this.hideHeaderTop = matched.some((item) => item.meta.hideHeaderTop);
      this.hideHeaderNav = matched.some((item) => item.meta.hideHeaderNav);
      this.hideFooter = matched.some((item) => item.meta.hideFooter);
    },
  },
  computed: {},
  methods: {},
};
</script>

<style scoped>
#app {
  width: 100%;
  height: 100%;
  position: relative;
  list-style: none;
}
* {
  padding: 0;
  margin: 0;
  border: 0;
  list-style: none;
}
</style>
