//验证手机号的正则表达式

export const checkMobile = (_, value, callback) => {
  const regMobile = /^1(?:3\d|4[4-9]|5[0-35-9]|6[67]|7[013-8]|8\d|9\d|)\d{8}$/
  if (regMobile.test(value)) return callback()
  callback(new Error('请输入合法的手机号'))
}
