<template>
  <div id="register">
    <el-dialog
      title="注册"
      width="400px"
      center
      :visible.sync="showRegister"
      :before-close="resetForm"
    >
      <el-form
        :model="dataForm"
        :rules="rules"
        status-icon
        ref="ruleForm"
        class="demo-ruleForm"
        label-width="100px"
      >
        <el-form-item label="账号:" prop="username">
          <el-input
            v-model="dataForm.username"
            prefix-icon="el-icon-user"
            placeholder="请输入账号"
          ></el-input>
        </el-form-item>
        <el-form-item label="密码:" prop="password">
          <el-input
            v-model="dataForm.password"
            prefix-icon="el-icon-lock"
            placeholder="请输入密码"
            show-password
          ></el-input>
        </el-form-item>
        <el-form-item label="确认密码:" prop="passwords">
          <el-input
            v-model="dataForm.passwords"
            prefix-icon="el-icon-lock"
            placeholder="请输入确认密码"
            show-password
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-button size="medium" type="primary" @click="register" style="width: 100%"
            >注册</el-button
          >
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import { mapState, mapMutations } from 'vuex';
import { Register } from '../../api';
export default {
  name: 'Register',
  data() {
    // 用户名表单验证
    const checkUsername = (rule, value, callback) => {
      let pattern = /^[A-Za-z0-9]{4,16}$/;
      if (value) {
        if (!pattern.test(value)) {
          callback(new Error('账号只能由英文、数字组成的4-16位!'));
        } else {
          callback();
        }
      } else {
        callback(new Error('请输入账号!'));
      }
    };
    //验证密码表单
    const checkPwd = (rule, value, callback) => {
      let pattern = /^[A-Za-z0-9]{6,16}$/;
      if (value) {
        if (!pattern.test(value)) {
          callback(new Error('密码只能由英文、数字组成的6-16位!'));
        } else {
          callback();
        }
      } else {
        callback(new Error('请输入密码!'));
      }
    };
    const checkPwd2 = (rule, value, callback) => {
      if (value) {
        if (value != this.dataForm.password) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      } else {
        callback(new Error('请输入确认密码!'));
      }
    };
    return {
      dataForm: {
        username: '',
        password: '',
        passwords: '',
      },
      rules: {
        username: [{ required: true, validator: checkUsername, trigger: 'blur' }],
        password: [{ required: true, validator: checkPwd, trigger: 'blur' }],
        passwords: [{ required: true, validator: checkPwd2, trigger: 'blur' }],
      },
    };
  },
  computed: {
    ...mapState(['showRegister']),
  },
  methods: {
    ...mapMutations(['setShowLoginOrRegister']),
    resetForm() {
      this.$refs['ruleForm'].resetFields();
      this.setShowLoginOrRegister({ showRegister: false });
    },
    register() {
      // 通过element自定义表单校验规则，校验用户输入的用户信息
      this.$refs['ruleForm'].validate(async (valid) => {
        if (!valid) return;
        const res = await Register(this.dataForm);
        if (res.code !== 200) return this.notifyError(res.message);
        this.notifySuccess(res.message);
        this.resetForm();
      });
    },
  },
};
</script>
<style scoped>
/* 表单验证成功图标的样式 */
.el-form-item--feedback .el-input__validateIcon {
  color: green;
}
</style>
