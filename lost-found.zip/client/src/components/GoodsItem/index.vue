<template>
  <div>
    <div v-for="item in goodsList" :key="item.id" class="itemBox">
      <router-link :to="{ path: '/goodsInfo', query: { goodsId: item.id } }">
        <img :src="item.image" alt />
        <h2>{{ item.goodsName }}</h2>
        <h3 v-if="item.User && item.User.Info">{{ item.User.Info.nikeName }}</h3>
        <div class="spanBox">
          <span v-if="item.claimStatus !== -1">
            <el-tag type="warning" v-if="item.claimStatus === 0">待认领</el-tag>
            <el-tag type="success" v-if="item.claimStatus === 1">已认领</el-tag>
          </span>
          <span v-else>
            <el-tag type="warning" v-if="item.findStatus === 0">待寻回</el-tag>
            <el-tag type="success" v-if="item.findStatus === 1">已寻回</el-tag>
          </span>
          <span v-if="item.need" class="tips"><span>急需</span></span>
        </div>
      </router-link>
    </div>
  </div>
</template>
<script>
export default {
  name: 'itemBox',
  props: ['goodsList'],
  data() {
    return {};
  },
  methods: {},
};
</script>
<style lang="less" scoped>
.itemBox {
  z-index: 1;
  float: left;
  width: 234px;
  height: 280px;
  padding: 10px 0;
  margin: 0 0 14.5px 13.7px;
  background-color: white;
  transition: all 0.2s linear;
  position: relative;
  &:hover {
    z-index: 2;
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    transform: translate3d(0, -2px, 0);
  }
  img {
    display: block;
    width: 160px;
    height: 160px;
    // background: url(../../assets/image/placeholder.png) no-repeat 50%;
    margin: 0 auto;
  }
  h2 {
    margin: 10px 10px 0;
    font-size: 14px;
    font-weight: 400;
    color: #333;
    text-align: center;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
  }
  h3 {
    margin: 5px auto;
    font-size: 13px;
    font-weight: 400;
    color: #b0b0b0;
    text-align: center;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
  }
  .spanBox {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 5px;
    .tips {
      color: #ff6700;
      margin-left: 10px;
      .del {
        margin-left: 0.5em;
        color: #b0b0b0;
        text-decoration: line-through;
      }
    }
  }
}
</style>
