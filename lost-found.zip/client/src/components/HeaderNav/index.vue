<template>
  <el-header>
    <el-menu
      :default-active="activeIndex"
      class="el-menu-demo"
      mode="horizontal"
      active-text-color="#409eff"
      router
    >
      <el-menu-item index="/home">首页</el-menu-item>
      <el-menu-item index="/allGoods">全部物品</el-menu-item>
      <el-menu-item index="/lostGoods">失物</el-menu-item>
      <el-menu-item index="/findGoods">拾物</el-menu-item>
    </el-menu>
  </el-header>
</template>

<script>
export default {
  data() {
    return {
      activeIndex: '', // 头部导航栏选中的标签
    };
  },
  created() {
    this.activeIndex = this.$route.path;
  },
  computed: {},
  watch: {
    /* 监听路由 */
    $route() {
      this.activeIndex = this.$route.path;
    },
  },
  methods: {},
};
</script>

<style scoped>
.el-header {
  padding: 0;
}
.el-header .el-menu {
  max-width: 1225px;
  margin: 0 auto;
}
.el-header .logo {
  height: 60px;
  width: 189px;
  float: left;
  margin-right: 100px;
}
.el-header .so {
  margin-top: 10px;
  width: 300px;
  float: right;
}
.el-menu-item {
  font-size: 16px;
}
</style>
