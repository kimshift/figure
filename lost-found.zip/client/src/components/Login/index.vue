<template>
  <div id="myLogin">
    <el-dialog
      title="登录"
      width="300px"
      :close-on-click-modal="false"
      center
      :visible.sync="showLogin"
      :before-close="resetForm"
    >
      <el-form
        :model="dataForm"
        :rules="rules"
        status-icon
        ref="ruleForm"
        class="demo-ruleForm"
      >
        <el-form-item prop="username">
          <el-input
            prefix-icon="el-icon-user"
            placeholder="请输入账号"
            v-model="dataForm.username"
          ></el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input
            prefix-icon="el-icon-lock"
            type="password"
            placeholder="请输入密码"
            v-model="dataForm.password"
            show-password
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-button size="medium" type="primary" @click="login" style="width: 100%"
            >登录</el-button
          >
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import { mapState, mapMutations } from 'vuex';
import { Login } from '../../api';
export default {
  name: 'Login',
  data() {
    // 用户名表单验证
    const checkUsername = (rule, value, callback) => {
      let pattern = /^[A-Za-z0-9]{4,16}$/;
      if (value) {
        if (!pattern.test(value)) {
          callback(new Error('账号只能由英文、数字组成的4-16位!'));
        } else {
          callback();
        }
      } else {
        callback(new Error('请输入账号!'));
      }
    };
    //验证密码表单
    const checkPwd = (rule, value, callback) => {
      let pattern = /^[A-Za-z0-9]{6,16}$/;
      if (value) {
        if (!pattern.test(value)) {
          callback(new Error('密码只能由英文、数字组成的6-16位!'));
        } else {
          callback();
        }
      } else {
        callback(new Error('请输入密码!'));
      }
    };
    return {
      dataForm: {
        username: '',
        password: '',
      },
      rules: {
        username: [{ required: true, validator: checkUsername, trigger: 'blur' }],
        password: [{ required: true, validator: checkPwd, trigger: 'blur' }],
      },
    };
  },
  computed: {
    ...mapState(['showLogin']),
  },
  methods: {
    ...mapMutations(['setShowLoginOrRegister', 'syncUserInfo']),
    resetForm() {
      this.$refs['ruleForm'].resetFields();
      this.setShowLoginOrRegister({ showLogin: false });
    },
    login() {
      // 通过element自定义表单校验规则，校验用户输入的用户信息
      this.$refs['ruleForm'].validate(async (valid) => {
        if (!valid) return;
        const res = await Login(this.dataForm);
        if (res.code !== 200) return this.notifyError(res.message);
        this.notifySuccess(res.message);
        const userInfo = res.data.user || {};
        const token = res.data.token;
        this.resetForm();
        this.syncUserInfo(userInfo);
        window.sessionStorage.setItem('token', token); //保存token
        window.sessionStorage.setItem('userInfo', JSON.stringify(userInfo)); //保存用户信息
      });
    },
  },
};
</script>
<style scoped>
/* 表单验证成功图标的样式 */
.el-form-item--feedback .el-input__validateIcon {
  color: green;
}
</style>
