<template>
  <div class="main">
    <div class="container">
      <h3>校园失物招领网站后台</h3>
      <el-form
        :model="dataForm"
        :rules="FormRules"
        ref="loginFormRef"
        label-width="100px"
        class="demo-ruleForm"
      >
        <el-form-item label="账号:" prop="username">
          <el-input
            prefix-icon="el-icon-user"
            placeholder="请输入账号"
            v-model="dataForm.username"
          ></el-input>
        </el-form-item>
        <el-form-item label="密码:" prop="password">
          <el-input
            prefix-icon="el-icon-lock"
            type="password"
            placeholder="请输入密码"
            v-model="dataForm.password"
            show-password
            @keyup.enter.native="login"
          ></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="login()">登录</el-button>
          <el-button type="info" @click="resetForm()">重置</el-button>
          <el-button @click="back">返回首页</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
  import { mapMutations } from 'vuex'
  import { Login } from '../../api'
  export default {
    name: 'login',
    data() {
      //用户名表单验证
      const checkUsername = (rule, value, callback) => {
        let pattern = /^[A-Za-z0-9]{4,16}$/
        if (value) {
          if (!pattern.test(value)) {
            callback(new Error('账号只能由英文、数字组成的4-16位!'))
          } else {
            callback()
          }
        } else {
          callback(new Error('请输入账号!'))
        }
      }
      //验证密码
      const checkPass = (rule, value, callback) => {
        let pattern = /^[A-Za-z0-9]{6,16}$/
        if (value) {
          if (!pattern.test(value)) {
            callback(new Error('密码只能由英文、数字组成的6-16位!'))
          } else {
            callback()
          }
        } else {
          callback(new Error('请输入密码!'))
        }
      }
      return {
        // 客户端缓存对象
        dataForm: {
          username: '',
          password: ''
        },
        FormRules: {
          username: [
            { required: true, validator: checkUsername, trigger: 'blur' }
          ],
          password: [{ required: true, validator: checkPass, trigger: 'blur' }]
        }
      }
    },
    methods: {
      ...mapMutations(['syncUserInfo']),
      // 重置
      resetForm() {
        //消除验证反馈
        this.$refs.loginFormRef.resetFields()
      },
      //登录
      login() {
        this.$refs.loginFormRef.validate(async (valid) => {
          if (!valid) return false
          this.dataForm.auth = 1 // 设置权限标识
          const res = await Login(this.dataForm) //调用登录接口
          if (res.code !== 200) return this.$message.error(res.message)
          const userInfo = res.data.user || {}
          const token = res.data.token
          this.syncUserInfo(userInfo)
          window.sessionStorage.setItem('token', token) //保存token到sessionStorage
          window.sessionStorage.setItem('userInfo', JSON.stringify(userInfo)) //保存用户信息到sessionStorage
          if (this.$route.query.redirect) {
            //如果存在参数,则跳转至进入登录页前的路由
            let redirect = this.$route.query.redirect
            this.$message.success(res.message)
            this.$router.push(redirect)
          } else {
            this.$message.success(res.message)
            this.$router.push('/admin')
          }
          this.resetForm()
        })
      },
      //返回首页
      back() {
        this.$router.push('/')
      }
    }
  }
</script>

<style lang="less" scoped="scoped">
  .main {
    height: 100%;
    background-image: url('../../assets/image/bg.jpg');
    background-repeat: no-repeat;
    background-size: 100% 100%;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    .container {
      width: 470px;
      height: 290px;
      background: #fff;
      padding: 25px;
      border-radius: 6px;
      h3 {
        font-size: 18px;
        font-weight: 700;
        color: #767473;
        text-align: center;
        margin-bottom: 20px;
      }
      .el-form-item {
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 5px;
        color: #454545;
      }
    }
  }
</style>
