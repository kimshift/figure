<template>
  <div class="about" id="about" name="about">
    <div class="about-header">
      <div class="about-title">
        <i class="el-icon-tickets" style="color: #ff6700"></i>
        公告和留言
      </div>
    </div>
    <div class="about-content">
      <Markdown></Markdown>
      <div class="msg_box">
        <div class="msg_box_title">留言板</div>
        <div class="comment-list">
          <div class="comment-item" v-for="(item, index) in data" :key="index">
            <div class="comment-discuss">
              <div class="name">{{ item.issues_username }}：{{ item.content }}</div>
              <div class="time">留言时间：{{ item.create_time | dateFormat }}</div>
            </div>
            <div class="comment-discuss" v-if="item.replyContent">
              <div class="name">平台回复：{{ item.replyContent }}</div>
            </div>
          </div>
        </div>
        <el-pagination background layout="total, sizes, prev, pager, next, jumper" :current-page.sync="currentPage"
          :page-sizes="pageSizes" :page-size="pageSize" :total="total" @size-change="handleSizeChange"
          @current-change="handlePageChange">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import Markdown from '@/common/Markdown';
import { fetchIssues } from '@/api'
export default {
  components: {
    Markdown,
  },
  data() {
    return {
      textarea: '',
      data: [],
      total: 0, // 总数据条数
      pageSizes: [1, 5, 10, 15, 20, 30], // 每页显示条数选项
      pageSize: 10, // 当前每页显示条数
      currentPage: 1, // 当前页码
      more: { id: '', flag: false }
    };
  },
  methods: {
    handlePageChange(newPage) {
      this.currentPage = newPage
      this.getDataList()
    },
    handleSizeChange(newSize) {
      this.pageSize = newSize
      this.getDataList()
    },
    async getDataList() {
      const queryParams = { page: this.currentPage, limit: this.pageSize }
      const res = await fetchIssues(queryParams)
      if (res.code !== 200) {
        return this.$message.error(res.message)
      }
      this.data = res.data.rows
      this.total = res.data.count
    },
    handleMore(id) {
      this.more.id = id
      this.more.flag = Boolean(id)
    }
  },
  created() {
    this.getDataList()
  },
};
</script>
<style lang="less" scoped>
.about {
  background-color: #f5f5f5;
  min-height: 693px;

  .about-header {
    height: 64px;
    background-color: #fff;
    border-bottom: 2px solid #ff6700;

    .about-title {
      margin: 0 auto;
      padding: 0 24px;
      height: 64px;
      line-height: 64px;
      font-size: 28px;
    }
  }

  .about-content {
    display: flex;
    background-color: #fff;

    .markdown-body {
      width: 40%;
      padding-right: 0;
    }

    .msg_box {
      width: 60%;
      border-left: 1px solid #eaecef;

      .msg_box_title {
        font-size: 24px;
        color: #24292e;
        margin-top: 24px;
        margin-bottom: 16px;
        font-weight: 600;
        line-height: 1.25;
        padding-bottom: .3em;
        border-bottom: 1px solid #eaecef;
      }

      .comment-list {
        .comment-item {
          padding: 8px 0;
          border-bottom: 1px solid #ccc;

          &:last-child {
            border-bottom: none;
          }

          .comment-discuss {
            margin-bottom: 3px;
          }

          .comment-item-body {
            display: flex;
            align-items: center;

            .time {
              margin-right: 16px;
            }

            .reply {
              color: #409eff;
              cursor: pointer;
            }

            .more {
              display: flex;
              align-items: center;
              margin-left: 16px;
              cursor: pointer;
              color: rgba(0, 0, 0, 0.45);

              svg {
                margin-left: 2px;
                width: 16px;
                height: 16px;
              }
            }
          }

          .comment-reply {
            margin-left: 2em;

            .comment-reply-item {
              margin-top: 3px;
              // 虚线
              border-bottom: 1px dashed #ccc;

              &:last-child {
                border-bottom: none;
              }
            }
          }
        }


      }

      .el-pagination {
        margin: 30px 0;
      }
    }
  }
}
</style>
