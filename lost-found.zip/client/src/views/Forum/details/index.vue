<template>
  <div class="main">
    <div class="header">
      <div class="about-title">
        <i class="el-icon-tickets" style="color: #ff6700"></i>
        论坛详情
      </div>
    </div>
    <div class="content">
      <div class="title">{{ details.title }}</div>
      <div class="sub-box">
        <div class="name" v-if="details.User">楼主：{{ details.User.username }}</div>
        <div class="name" v-else>楼主：匿名用户</div>
        <div class="time">发表时间：{{ details.create_time | dateFormat }}</div>
      </div>
      <div class="body">{{ details.content }}</div>
    </div>
    <div class="comment">
      <div class="comment-title">评论区</div>
      <div class="comment-submit">
        <el-input type="textarea" :rows="4" placeholder="请输入内容" v-model="textarea">
        </el-input>
        <el-button type="primary" @click="submitComment">提交</el-button>
      </div>
      <div class="comment-list">
        <div class="comment-item" v-for="(item, index) in commentList" :key="index">
          <div class="comment-discuss">
            <div class="comment-item-title">
              <div class="name">{{ item.comment_username }}：{{ item.content }}</div>
            </div>
            <div class="comment-item-body">
              <div class="time">{{ item.create_time | dateFormat }}</div>
              <div class="reply" @click="handleReply(item)">回复</div>
              <template v-if="item.replayFlag">
                <div class="more" v-if="!(item.id === more.id && more.flag)" @click="handleMore(item.id)">
                  <div>展开</div>
                  <svg t="1715846876914" class="icon" viewBox="0 0 1024 1024" version="1.1"
                    xmlns="http://www.w3.org/2000/svg" p-id="9610" id="mx_n_1715846876918">
                    <path
                      d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3 0.1-12.7-6.4-12.7z"
                      p-id="9611" fill="#8c8c8c"></path>
                  </svg>
                </div>
              </template>
            </div>
          </div>
          <div class="comment-reply" v-if="item.replayFlag && more.id === item.id && more.flag">
            <div class="comment-reply-item" v-for="(reply, i) in item.ForumCommentReplies">
              <div class="comment-item-title">
                <div class="name">{{ reply.reply_username }}->{{ reply.reply_comment_username }}：{{
                  reply.content }}</div>
              </div>
              <div class="comment-item-body">
                <div class="time">{{ reply.create_time | dateFormat }}</div>
                <div class="reply" @click="handleReply(reply)">回复</div>
                <div class="more" v-if="i === item.ForumCommentReplies.length - 1" @click="handleMore()">
                  <div>收起</div>
                  <svg t="1715847226260" class="icon" viewBox="0 0 1024 1024" version="1.1"
                    xmlns="http://www.w3.org/2000/svg" p-id="9779">
                    <path
                      d="M890.5 755.3L537.9 269.2c-12.8-17.6-39-17.6-51.7 0L133.5 755.3c-3.8 5.3-0.1 12.7 6.5 12.7h75c5.1 0 9.9-2.5 12.9-6.6L512 369.8l284.1 391.6c3 4.1 7.8 6.6 12.9 6.6h75c6.5 0 10.3-7.4 6.5-12.7z"
                      p-id="9780" fill="#8c8c8c"></path>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <el-pagination background layout="total, sizes, prev, pager, next, jumper" :current-page.sync="page"
        :page-sizes="limits" :page-size="limit" :total="total" @size-change="handleSizeChange"
        @current-change="handlePageChange">
      </el-pagination>
    </div>
    <!-- 回复对话框 -->
    <el-dialog title="回复" :visible.sync="replyFlag" width="600px">
      <el-input v-model.trim="tempData.content" type="textarea" rows="3"></el-input>
      <div slot="footer" class="dialog-footer">
        <el-button @click="replyFlag = false">取 消</el-button>
        <el-button type="primary" @click="postReply">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { fetchPostDetail, addComment, fetchComments, replyComment } from '@/api'
import { mapState } from 'vuex'
export default {
  data() {
    return {
      details: {},
      commentList: [],
      textarea: '',
      total: 0, // 总数据条数
      limits: [1, 5, 10, 15, 20, 30], // 每页显示条数选项
      limit: 10, // 当前每页显示条数
      page: 1, // 当前页码
      tempData: { content: '' },
      replyFlag: false,
      more: { id: '', flag: false }
    }
  },
  created() {
    this.getData()
    this.getCommentList()
  },
  computed: {
    ...mapState(['userInfo', 'isLogin'])
  },
  methods: {
    async getData() {
      const id = this.$route.params.id
      const res = await fetchPostDetail(id)
      if (res.code !== 200) {
        return this.$message.error(res.message)
      }
      this.details = res.data
    },
    async submitComment() {
      if (!this.isLogin) {
        return this.$message.warning('请先登录')
      }
      if (!this.textarea) {
        return this.$message.warning('请输入评论内容')
      }
      const id = this.$route.params.id
      const params = {
        content: this.textarea,
        postId: id
      }
      const res = await addComment(params)
      if (res.code !== 200) {
        return this.$message.error(res.message)
      }
      this.$message.success('评发表成功')
      this.textarea = ''
      this.getCommentList()
    },
    handlePageChange(newPage) {
      this.page = newPage
      this.getCommentList() // 切换分页时获取帖子列表
    },
    handleSizeChange(newSize) {
      this.limit = newSize
      this.getCommentList() // 改变每页显示条数时获取帖子列表
    },
    async getCommentList() {
      const id = this.$route.params.id
      const queryParams = { id, page: this.page, limit: this.limit }
      const res = await fetchComments(queryParams)
      if (res.code !== 200) {
        return this.$message.error(res.message)
      }
      this.commentList = res.data.rows
      this.total = res.data.count
    },
    handleReply(item) {
      if (!this.isLogin) {
        return this.$message.warning('请先登录')
      }
      this.tempData = {
        content: '',
        comment_id: item.id,
        reply_uid: item.uid
      }
      this.replyFlag = true
    },
    async postReply() {
      if (!this.isLogin) {
        return this.$message.warning('请先登录')
      }
      if (!this.tempData.content) {
        return this.$message.warning('请输入回复内容')
      }
      let params = JSON.parse(JSON.stringify(this.tempData))
      const res = await replyComment(params)
      if (res.code !== 200) {
        return this.$message.error(res.message)
      }
      this.$message.success('回复成功')
      this.handleMore(params.comment_id)
      this.replyFlag = false
      this.getCommentList()
    },
    handleMore(id) {
      this.more.id = id
      this.more.flag = Boolean(id)
    }
  }
};
</script>
<style lang="less" scoped>
.main {
  background-color: #fff;
  min-height: 693px;
  padding-bottom: 30px;

  .header {
    height: 64px;
    background-color: #fff;
    border-bottom: 2px solid #ff6700;

    .about-title {
      padding: 0 24px;
      margin: 0 auto;
      height: 64px;
      line-height: 64px;
      font-size: 28px;
    }
  }

  .content {
    padding: 0 24px;

    .title {
      font-size: 30px;
      font-weight: 600;
      margin-bottom: 10px;
      text-align: center;
    }

    .sub-box {
      display: flex;
      justify-content: center;
      align-items: center;

      .name {
        margin-right: 16px;
      }


    }
  }

  .comment {
    padding: 0 24px;
    margin-top: 120px;

    .comment-title {
      font-size: 20px;
      font-weight: 600;
      margin-bottom: 10px;
    }

    .comment-list {
      padding: 16px 0;

      .comment-item {
        padding: 8px 0;
        border-bottom: 1px solid #ccc;

        &:last-child {
          border-bottom: none;
        }

        .comment-item-title {
          display: flex;
          margin-bottom: 3px;
        }

        .comment-item-body {
          display: flex;
          align-items: center;

          .time {
            margin-right: 16px;
          }

          .reply {
            color: #409eff;
            cursor: pointer;
          }

          .more {
            display: flex;
            align-items: center;
            margin-left: 16px;
            cursor: pointer;
            color: rgba(0, 0, 0, 0.45);

            svg {
              margin-left: 2px;
              width: 16px;
              height: 16px;
            }
          }
        }

        .comment-reply {
          margin-left: 2em;

          .comment-reply-item {
            margin-top: 3px;
            // 虚线
            border-bottom: 1px dashed #ccc;

            &:last-child {
              border-bottom: none;
            }
          }
        }
      }


    }


    .el-textarea {
      width: 100%;
    }

    .el-pagination {
      margin-top: 30px;
    }
  }
}
</style>
