<template>
  <div class="forum-container">
    <!-- 上部分 -->
    <div class="forum-header">
      <div class="forum-title">论坛</div>
      <el-button type="primary" icon="el-icon-plus" @click="showPublishDialog = true">发布帖子</el-button>
    </div>

    <!-- 下部分 -->
    <div class="forum-content">
      <el-row v-for="post in posts" :key="post.id" class="post-item">
        <el-col :span="18">
          <router-link :to="`/forum_details/${post.id}`">{{ post.title }}</router-link>
          <span class="post-author" v-if="post.User">(发布人：{{ post.User.username }})</span>
          <span class="post-author" v-else>(发布人：已注销)</span>
        </el-col>
        <el-col :span="6" class="post-time">{{ post.create_time }}</el-col>
      </el-row>
      <el-pagination background layout="total, sizes, prev, pager, next, jumper" :current-page.sync="currentPage"
        :page-sizes="pageSizes" :page-size="pageSize" :total="total" @size-change="handleSizeChange"
        @current-change="handlePageChange"></el-pagination>
    </div>

    <!-- 发帖对话框 -->
    <el-dialog title="发布帖子" :visible.sync="showPublishDialog" width="600px">
      <el-form :model="newPost" label-width="80px">
        <el-form-item label="标题">
          <el-input v-model="newPost.title"></el-input>
        </el-form-item>
        <el-form-item label="内容">
          <el-input v-model="newPost.content" type="textarea" rows="5"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="showPublishDialog = false">取 消</el-button>
        <el-button type="primary" @click="publishPost">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 评论对话框 -->
    <el-dialog title="评论" :visible.sync="showCommentDialog" width="600px">
      <el-input v-model="newComment" type="textarea" rows="3"></el-input>
      <div slot="footer" class="dialog-footer">
        <el-button @click="showCommentDialog = false">取 消</el-button>
        <el-button type="primary" @click="postComment">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { mapActions } from 'vuex'
import { createPost } from '../../api'
export default {
  components: {},
  data() {
    return {
      posts: [], // 帖子列表
      total: 0, // 总数据条数
      pageSizes: [1, 5, 10, 15, 20, 30], // 每页显示条数选项
      pageSize: 10, // 当前每页显示条数
      currentPage: 1, // 当前页码
      showPublishDialog: false, // 显示发帖对话框
      newPost: {
        title: '',
        content: ''
      },
      showCommentDialog: false, // 显示评论对话框
      newComment: ''
    }
  },
  created() {
    this.fetchForumPosts() // 组件创建时获取论坛帖子列表
      .catch((error) => {
        console.error('获取论坛帖子列表失败:', error)
      })
  },
  methods: {
    ...mapActions(['reqForumPosts']),
    async fetchForumPosts() {
      const queryParams = { page: this.currentPage, limit: this.pageSize }
      await this.reqForumPosts(queryParams)
      this.posts = this.$store.state.forumPosts
      this.total = this.$store.state.forumTotal
      // console.log(this.posts) // 打印帖子列表
    },

    handlePageChange(newPage) {
      this.currentPage = newPage
      this.fetchPosts() // 切换分页时获取帖子列表
    },

    handleSizeChange(newSize) {
      this.pageSize = newSize
      this.fetchPosts() // 改变每页显示条数时获取帖子列表
    },

    // 发布帖子
    async publishPost() {
      try {
        const { title, content } = this.newPost
        if (!title.trim() || !content.trim()) {
          return this.$message.warning('标题和内容不能为空')
        }

        // 检查用户是否已登录
        const userInfo = this.$store.state.userInfo
        if (!userInfo || !userInfo.id) {
          return this.$message.warning('请先登录')
        }

        const userId = userInfo.id

        // 直接调用 createPost API
        const res = await createPost({ title, content }, userId)
        if (res.code !== 200) {
          return this.$message.error(res.message)
        }

        this.$message.success('发布成功')
        this.showPublishDialog = false
        this.newPost.title = ''
        this.newPost.content = ''
        this.fetchForumPosts() // 重新获取帖子列表
      } catch (error) {
        console.error('发布帖子失败:', error)
        this.$message.error('发布帖子失败')
      }
    },
    openCommentDialog(postId) {
      this.showCommentDialog = true
      // 获取帖子详情
      // ...
    },
    postComment() {
      // 发送请求提交评论
      // ...
      this.showCommentDialog = false
      this.newComment = ''
      this.$message.success('评论成功')
    }
  }
}
</script>
<style lang="less" scoped>
.forum-container {
  padding: 20px;
}

.forum-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #409eff;
  color: #fff;
  padding: 10px 20px;
  margin-bottom: 20px;
}

.forum-title {
  font-size: 24px;
  font-weight: bold;
}

.post-item {
  padding: 10px 0;
  border-bottom: 1px solid #eee;
}

.post-item a {
  color: #409eff;
  text-decoration: none;
}

.post-author {
  margin-left: 10px;
  color: #999;
}

.post-time {
  text-align: right;
  color: #999;
}

.comment-list {
  margin-top: 20px;
  padding: 10px;
  background-color: #f0f9eb;
}

.comment-list-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}

.add-comment {
  color: #67c23a;
  cursor: pointer;
}
</style>
