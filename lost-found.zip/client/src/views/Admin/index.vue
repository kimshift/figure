<template>
  <el-container class="admin-container">
    <!-- 头部区域 -->
    <el-header>
      <div>
        <img src="../../assets/image/system.png" alt />
        <span v-if="!isCollapse">后台管理系统</span>
        <div class="toggle-button" @click="toggleCollapse">
          <svg t="1492500959545" class="hamburger" fill="#fff" fill-opacity="0.8" :class="{ 'is-active': isCollapse }"
            viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1691"
            xmlns:xlink="http://www.w3.org/1999/xlink">
            <path
              d="M966.8023 568.849776 57.196677 568.849776c-31.397081 0-56.850799-25.452695-56.850799-56.850799l0 0c0-31.397081 25.452695-56.849776 56.850799-56.849776l909.605623 0c31.397081 0 56.849776 25.452695 56.849776 56.849776l0 0C1023.653099 543.397081 998.200404 568.849776 966.8023 568.849776z"
              p-id="1692" />
            <path
              d="M966.8023 881.527125 57.196677 881.527125c-31.397081 0-56.850799-25.452695-56.850799-56.849776l0 0c0-31.397081 25.452695-56.849776 56.850799-56.849776l909.605623 0c31.397081 0 56.849776 25.452695 56.849776 56.849776l0 0C1023.653099 856.07443 998.200404 881.527125 966.8023 881.527125z"
              p-id="1693" />
            <path
              d="M966.8023 256.17345 57.196677 256.17345c-31.397081 0-56.850799-25.452695-56.850799-56.849776l0 0c0-31.397081 25.452695-56.850799 56.850799-56.850799l909.605623 0c31.397081 0 56.849776 25.452695 56.849776 56.850799l0 0C1023.653099 230.720755 998.200404 256.17345 966.8023 256.17345z"
              p-id="1694" />
          </svg>
        </div>
      </div>
      <span class="toolbar">
        <el-menu mode="horizontal">
          <el-menu-item v-popover:popover-personal>
            <span class="user-info">
              <img v-if="userInfo.Info && userInfo.Info.image" :src="userInfo.Info.image" />
              <img v-else src="../../assets/image/el-avatar.png" />
              {{ userInfo.username }}
            </span>
            <el-popover ref="popover-personal" placement="bottom" trigger="hover" :visible-arrow="false">
              <router-link :to="{ path: '/admin/home' }">
                <el-dropdown-item>
                  <span>个人中心</span>
                </el-dropdown-item>
              </router-link>
              <router-link :to="{ path: '/admin/home', query: { activeName: 'second' } }">
                <el-dropdown-item>
                  <span>修改密码</span>
                </el-dropdown-item>
              </router-link>
              <router-link :to="{ path: '/home' }">
                <el-dropdown-item>
                  <span>返回首页</span>
                </el-dropdown-item>
              </router-link>
              <el-dropdown-item @click.native="logout">
                <span>退出登录</span>
              </el-dropdown-item>
            </el-popover>
          </el-menu-item>
        </el-menu>
      </span>
    </el-header>
    <!-- 页面主体区域 -->
    <el-container>
      <!-- 侧边栏 -->
      <el-aside :width="isCollapse ? '64px' : '210px'">
        <!-- 侧边栏菜单区域 -->
        <el-menu background-color="#574f4c" text-color="#fff" active-text-color="#ffd04b" unique-opened
          :collapse="isCollapse" :collapse-transition="false" router :default-active="activePath">
          <!-- 一级菜单 -->
          <el-submenu :index="item.id + ''" v-for="item in menuList" :key="item.id">
            <!-- 一级菜单模板区域 -->
            <template slot="title">
              <!-- 字体图标 -->
              <i :class="item.icon"></i>
              <!-- 菜单名 -->
              <span>{{ item.menuName }}</span>
            </template>

            <!-- 二级菜单 -->
            <!-- 导航开启路由模式:将index值作为导航路由 -->
            <el-menu-item :index="subItem.path" v-for="subItem in item.children" :key="subItem.id">
              <!-- 二级菜单的模板区域 -->
              <template slot="title">
                <!-- 字体图标 -->
                <i class="el-icon-menu"></i>
                <!-- 菜单名 -->
                <span>{{ subItem.menuName }}</span>
              </template>
            </el-menu-item>
          </el-submenu>
        </el-menu>
      </el-aside>
      <!-- 右侧内容主体 -->
      <el-main>
        <!-- 子路由占位符 -->
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { mapState, mapActions } from 'vuex'
export default {
  data() {
    return {
      // 左侧菜单数据
      menuList: [
        // 一级菜单
        {
          id: 1,
          menuName: '用户管理',
          // 二级菜单
          children: [
            { id: 110, menuName: '个人中心', path: '/admin/home' },
            { id: 111, menuName: '用户列表', path: '/admin/users' }
          ],
          icon: 'fa el-icon-user'
        },
        {
          id: 2,
          menuName: '物品管理',
          children: [
            { id: 120, menuName: '失物列表', path: '/admin/lostGoods' },
            { id: 121, menuName: '急需列表', path: '/admin/needGoods' },
            { id: 122, menuName: '拾物列表', path: '/admin/collectGoods' },
            { id: 123, menuName: '发布消息', path: '/admin/goods/create' },
            { id: 124, menuName: '分类列表', path: '/admin/category' }
          ],
          icon: 'fa el-icon-goods'
        },
        {
          id: 3,
          menuName: '申请管理',
          children: [
            { id: 130, menuName: '认领申请列表', path: '/admin/claim' },
            { id: 131, menuName: '归还申请列表', path: '/admin/give' }
          ],
          icon: 'fa el-icon-s-help'
        },
        {
          id: 4,
          menuName: '交接管理',
          children: [
            { id: 140, menuName: '失物寻回列表', path: '/admin/claimDock' },
            { id: 141, menuName: '拾物归还列表', path: '/admin/giveDock' }
          ],
          icon: 'fa el-icon-s-promotion'
        },
        {
          id: 5,
          menuName: '其他管理',
          children: [
            { id: 150, menuName: '轮播图列表', path: '/admin/slideshow' },
            { id: 151, menuName: '评论列表', path: '/admin/commentList' },
            { id: 152, menuName: '留言列表', path: '/admin/issuesList' }
          ],
          icon: 'fa el-icon-reading'
        }
      ],
      isCollapse: false, // 是否折叠，默认展开
      activePath: '' // 被激活的链接地址
    }
  },
  computed: {
    ...mapState(['isLogin', 'userInfo']) //引入vuex变量
  },
  created() {
    this.activePath = this.$route.path
  },
  watch: {
    $route() {
      this.activePath = this.$route.path
    }
  },
  methods: {
    ...mapActions(['syncLogout']),
    // 退出登录
    logout() {
      window.sessionStorage.clear()
      this.$message.info('正在退出')
      setTimeout((_) => {
        this.syncLogout()
        window.location.reload()
      }, 1000)
    },
    // 返回前台
    goHome() {
      this.$router.push('/home')
    },
    // 点击按钮，切换菜单的折叠与展开
    toggleCollapse() {
      this.isCollapse = !this.isCollapse
    }
  }
}
</script>

<style lang="less" scoped>
@header-color: #392d2f;
@title-color: #fff;
@side-color: #574f4c;

.admin-container {
  height: 100%;
}

.el-header {
  background-color: @header-color;
  display: flex;
  justify-content: space-between;
  padding-left: 0;
  align-items: center;
  //左上角字体颜色
  color: @title-color;
  font-size: 20px;

  div {
    display: flex;
    align-items: center;

    img {
      height: 40px;
    }

    span {
      margin: 0 10px;
    }
  }

  // 切换栏按钮样式
  .toggle-button {
    margin-left: 10px;
    font-size: 10px;
    line-height: 10px;
    color: @title-color;
    text-align: center;
    letter-spacing: 0.2em;
    // 鼠标放上去变成小手
    cursor: pointer;

    .hamburger {
      display: inline-block;
      cursor: pointer;
      width: 20px;
      height: 20px;
      transform: rotate(90deg);
      transition: 0.38s;
      transform-origin: 50% 50%;

      &.is-active {
        transform: rotate(0deg);
      }
    }
  }

  .toolbar {
    float: right;

    .el-menu {
      background-color: @header-color;
    }

    .user-info {
      font-size: 20px;
      color: @title-color;
      cursor: pointer;

      img {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        margin: 10px 0px 10px 10px;
        float: right;
      }
    }
  }
}

/* 右上角触发响应样式 */
.el-menu--horizontal>.el-menu-item:not(.is-disabled):focus,
.el-menu--horizontal>.el-menu-item:not(.is-disabled):hover,
.el-menu--horizontal>.el-submenu .el-submenu__title:hover {
  background-color: @header-color;
}

a {
  text-decoration: none;
}

.el-aside {
  background-color: @side-color;

  .el-menu {
    border: none;
  }
}

.el-main {
  background-color: #eaedf1;
}

.fa {
  margin-right: 10px;
}
</style>
