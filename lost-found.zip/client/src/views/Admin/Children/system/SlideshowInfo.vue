<template>
  <div class="slideshow-info">
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/admin' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/admin/slideshow' }"
        >轮播图管理</el-breadcrumb-item
      >
      <el-breadcrumb-item>发布轮播图</el-breadcrumb-item>
    </el-breadcrumb>
    <el-form
      :model="slideshowInfo"
      :rules="rules"
      ref="ruleForm"
      label-width="100px"
      class="demo-ruleForm"
    >
      <el-form-item label="物品类型：">
        <el-radio v-model="slideshowInfo.type" :label="0">失物</el-radio>
        <el-radio v-model="slideshowInfo.type" :label="1">拾物</el-radio>
      </el-form-item>
      <el-form-item label="关联商品：">
        <el-select v-model="slideshowInfo.goodsId" placeholder="请选择关联的商品">
          <el-option
            v-for="item in goodsList"
            :key="item.id"
            :label="item.goodsName"
            :value="item.id"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="相关描述：">
        <el-input
          placeholder="请输入相关描述"
          clearable
          :row="10"
          type="textarea"
          v-model="slideshowInfo.introduce"
        ></el-input>
      </el-form-item>
      <el-form-item label="原图：" v-if="editFlag">
        <img
          :src="slideshowInfo.image"
          style="width: 90px"
          @click="handlePreview(slideshowInfo.image)"
        />
      </el-form-item>
      <el-form-item
        label="轮播图："
        style="width: 500px"
        :class="editFlag ? '' : 'upload'"
      >
        <el-upload
          ref="upload"
          class="upload-demo"
          drag
          :on-change="handleChange"
          :on-preview="handlePreview"
          :auto-upload="false"
          :multiple="false"
          :limit="limit"
          action
        >
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          <div class="el-upload__tip" slot="tip">
            建议上传规格为宽1000像素,高350像素的图片
          </div>
        </el-upload>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="handleSubmit()">提 交</el-button>
        <el-button @click="resetForm()">返 回</el-button>
      </el-form-item>
    </el-form>
    <!-- 图片预览 -->
    <el-dialog
      :visible.sync="dialogVisible"
      width="35%"
      title="文件预览"
      @close="dialogVisible = false"
    >
      <img width="100%" :src="dialogImageUrl" alt />
    </el-dialog>
  </div>
</template>

<script>
import {
  getUserGoodsList,
  getSlideshowInfo,
  createSlideshow,
  changeSlideshowInfo,
} from '../../../../api';
import { mapState } from 'vuex';
export default {
  data() {
    return {
      slideshowId: '',
      slideshowInfo: {}, //轮播图信息
      goodsList: [], // 关联商品列表
      fileList: [], //上传图片列表
      limit: 1, //限制图片上传数量
      editFlag: false,
      // 表单验证
      // rules: {
      //   goodsId: [{ required: true, message: '请选择关联商品', trigger: 'change' }],
      //   type: [{ required: true, message: '请选择物品类型', trigger: 'blur' }],
      // },
      dialogImageUrl: '',
      dialogVisible: false,
      oneChange: false,
    };
  },
  created() {
    const { id } = this.$route.query;
    if (id) {
      this.slideshowId = id;
      this.editFlag = true;
      this.getSlideshowInfo(id);
    } else {
      this.getGoodsList();
    }
  },
  computed: {
    ...mapState(['userInfo']),
  },
  watch: {
    'slideshowInfo.type': {
      handler(newVal) {
        // 修改的物品为拾物==>第一次进来不让它发生操作
        if (this.editFlag && !this.oneChange) {
          this.oneChange = true;
          return;
        }
        this.oneChange = true;
        this.slideshowInfo.goodsId = '';
        this.$refs.ruleForm.resetFields();
        this.slideshowInfo.type = newVal;
        this.getGoodsList();
      },
    },
  },
  methods: {
    async getGoodsList() {
      if (!this.userInfo?.id) return;
      const res = await getUserGoodsList({
        status: 1,
        uid: this.userInfo?.id,
        type: this.slideshowInfo.type,
      });
      if (res.code !== 200) return this.$message.error(res.message);
      this.goodsList = res.data.rows;
    },
    async getSlideshowInfo(id) {
      const res = await getSlideshowInfo(id);
      if (res.code !== 200) return this.$message.error(res.message);
      this.slideshowInfo = res.data;
      this.oneChange = this.slideshowInfo.type === 0;
      this.getGoodsList();
    },
    // 选择上传图片
    handleChange(file, fileList) {
      if (fileList.length > 1) {
        fileList = fileList.slice(-1);
      }
      this.fileList = fileList;
    },
    // 图片预览
    handlePreview(url) {
      if (url?.raw) {
        const reader = new FileReader();
        reader.readAsDataURL(url.raw);
        reader.onload = () => {
          this.dialogImageUrl = reader.result;
          this.dialogVisible = true;
        };
      } else {
        this.dialogImageUrl = url;
        this.dialogVisible = true;
      }
    },
    resetForm() {
      this.$router.push('/admin/slideshow');
      this.$refs.upload.clearFiles();
      this.$refs.ruleForm.resetFields();
      this.fileList = [];
    },
    // 提交数据
    handleSubmit() {
      this.$refs.ruleForm.validate(async (valid) => {
        if (!valid) return;
        if (!this.editFlag && this.fileList.length === 0) {
          return this.$message.info('请上传轮播图');
        }
        const formData = new FormData();
        formData.append('slideshowInfo', JSON.stringify(this.slideshowInfo));
        if (this.fileList.length > 0) {
          formData.append('image', this.fileList[0].raw);
        }
        const res = this.editFlag
          ? await changeSlideshowInfo(formData, this.slideshowId)
          : await createSlideshow(formData);
        if (res.code !== 200) return this.$message.error(res.message);
        this.$message.success(res.message);
        this.resetForm();
      });
    },
  },
};
</script>

<style lang="less">
@common_width: 70%;
.slideshow-info {
  width: @common_width;
  .el-input {
    width: @common_width;
  }
  .el-breadcrumb {
    margin-bottom: 15px;
    font-size: 12px;
  }
  .el-select {
    width: @common_width;
  }
  .el-textarea {
    width: @common_width;
  }
  .el-textarea__inner {
    width: @common_width;
    height: 100px;
  }

  // 自定义必填样式
  .upload .el-form-item__label:before {
    content: '*';
    color: #f56c6c;
    margin-right: 4px;
  }
  .el-upload-list {
    width: 100% !important;
  }
}
</style>
