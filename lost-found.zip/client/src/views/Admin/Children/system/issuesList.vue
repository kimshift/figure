<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/admin' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/admin/issuesList' }">留言管理</el-breadcrumb-item>
      <el-breadcrumb-item>留言列表</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 卡片视图区域 -->
    <el-card>
      <pt-table ref="ptTable" :url="url" :columns="columns" :operation="operation" :search="false">
        <!-- 自定义操作列 -->
        <template v-slot:operateBox="{ row }">
          <el-button size="mini" type="primary" icon="el-icon-edit" v-if="!row.replyContent"
            @click="handleShow(row)">回复</el-button>
          <el-button size="mini" type="danger" icon="el-icon-delete" @click="handleRemove(row.id)">删除</el-button>
        </template>
      </pt-table>
    </el-card>
    <!-- 回复对话框 -->
    <el-dialog title="回复" :visible.sync="replyFlag" width="600px">
      <el-input v-model.trim="tempData.content" type="textarea" rows="3"></el-input>
      <div slot="footer" class="dialog-footer">
        <el-button @click="replyFlag = false">取 消</el-button>
        <el-button type="primary" @click="postReply">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import PtTable from '@/common/PtTable';
import { columns, operation } from '@/config/tableOption/issuesTable';
import { replyIssues, removeIssues } from '@/api';
export default {
  components: {
    PtTable,
  },
  data() {
    return {
      columns, //列配置(必传)
      operation, //操作列（选传）
      url: '/public/issues/list', //url、数据源tableData二传一(url优先级比tableData数据源高)
      tempData: { content: "" },
      replyFlag: false,
    };
  },
  methods: {
    // 监听对话框关闭
    dialogClosed(ref) {
      this.$refs[ref].resetFields();
    },
    // 编辑数据
    handleShow(row) {
      console.log('测试row:', row)
      this.tempData = { id: row.id, content: '' }
      this.replyFlag = true
    },
    async postReply() {
      if (!this.tempData.content) {
        return this.$message.warning('请输入回复内容')
      }
      let params = JSON.parse(JSON.stringify(this.tempData))
      const res = await replyIssues(params)
      if (res.code !== 200) {
        return this.$message.error(res.message)
      }
      this.$message.success('回复成功')
      this.replyFlag = false
      this.$refs.ptTable.getTableList();
    },
    // 删除数据
    async handleRemove(id) {
      // 弹框询问用户是否删除数据
      const confirmResult = await this.$confirm(
        '此操作将永久删除该数据, 是否继续?',
        '温馨提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      ).catch((err) => err);
      if (confirmResult !== 'confirm') return
      const res = await removeIssues(id);
      if (res.code !== 200) return this.$message.error(res.message);
      const count = this.$refs.ptTable.items.length - 1; //当前页总数据
      if (count === 0 && this.$refs.ptTable.queryParams.page > 1) {
        // 如果当前页数据被完了，而且不是第一页，则页码减 1
        this.$refs.ptTable.queryParams.page -= 1;
      }
      this.$message.success(res.message);
      this.$refs.ptTable.getTableList();
    },
  },
};
</script>

<style lang="less" scoped>
/* ElementUI面包屑组件样式 */
.el-breadcrumb {
  margin-bottom: 15px;
  font-size: 12px;
}

/* ElementUI卡片组件样式 */
.el-card {
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) !important;
}

.btn {
  margin-left: 1rem;
}

/* 头像样式 */
/deep/.el-image__inner {
  height: 50px;
  border-radius: 10px;
}
</style>
