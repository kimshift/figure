<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/user' }">个人中心</el-breadcrumb-item>
      <el-breadcrumb-item>交接管理</el-breadcrumb-item>
      <el-breadcrumb-item>拾物归还列表</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 卡片视图区域 -->
    <el-card>
      <pt-table
        ref="ptTable"
        :url="url"
        :columns="columns"
        :selectList="selectList"
        :operation="operation"
        :queryParams="queryParams"
        searchTitle="请输入物品名称"
        expand
      >
        <!-- 自定扩展列 -->
        <template v-slot:expandBox="{ row }">
          <el-form label-position="left" inline class="demo-table-expand">
            <el-form-item label="拾主姓名:">
              <span v-if="row.Good && row.Good.User && row.Good.User.Info">{{
                row.Good.User.Info.nikeName
              }}</span>
            </el-form-item>
            <el-form-item label="拾主电话:">
              <span v-if="row.Good && row.Good.User && row.Good.User.Info">{{
                row.Good.User.Info.phone
              }}</span>
            </el-form-item>
            <el-form-item label="拾主地址:">
              <span v-if="row.Good && row.Good.User && row.Good.User.Info">{{
                row.Good.User.Info.address
              }}</span>
            </el-form-item>
            <el-form-item label="申请人姓名:">
              <span>{{ row.nikeName }}</span>
            </el-form-item>
            <el-form-item label="申请人电话:">
              <span>{{ row.phone }}</span>
            </el-form-item>
            <el-form-item label="申请人地址:">
              <span>{{ row.address }}</span>
            </el-form-item>
            <el-form-item label="申请人备注:">
              <span> {{ row.introduce }}</span>
            </el-form-item>
            <el-form-item label="申请说明:">
              <span> {{ row.explain }}</span>
            </el-form-item>

            <el-form-item v-if="row.opinion" label="审核意见:">
              <span> {{ row.opinion }}</span>
            </el-form-item>
            <el-form-item label="申请材料:">
              <img :src="row.image" style="width: 90px" />
            </el-form-item>
          </el-form>
        </template>
        <!-- 自定义操作列 -->
        <template v-slot:operateBox="{ row }">
          <el-button
            v-if="row.claimStatus === 1"
            size="mini"
            type="success"
            icon="el-icon-check"
            @click="handleSubmit(row)"
            >完成</el-button
          >
          <el-button
            size="mini"
            type="danger"
            icon="el-icon-delete"
            @click="handleRemove(row)"
            >删除</el-button
          >
        </template>
      </pt-table>
    </el-card>
  </div>
</template>

<script>
import PtTable from '@/common/PtTable';
import { columns, operation } from '@/config/tableOption/giveDockTable';
import { removeClaimInfo, changeClaimStatus } from '@/api';
export default {
  components: {
    PtTable,
  },
  data() {
    return {
      columns, //列配置(必传)
      operation, //操作列（选传）
      url: '/public/claim/dock', //url、数据源tableData二传一(url优先级比tableData数据源高)
      selectList: [
        { value: 'null', label: '全部' },
        { value: -1, label: '归还终止' },
        { value: 0, label: '归还暂停' },
        { value: 1, label: '归还中' },
        { value: 2, label: '归还完成' },
      ],
      queryParams: {
        search: '', //搜索关键词
        page: 1, // 当前的页数
        limit: 5, // 当前每页显示多少条数据
        select: '', //下拉分类选择
        type: 1, //拾物归还
      },
    };
  },
  methods: {
    async handleSubmit({ id, goodsId }) {
      const confirmResult = await this.$confirm(
        '请确保已经交接完成后再点击完成操作,确定已经完成了吗?',
        '温馨提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      ).catch((err) => err);
      // 如果用户确认删除，则返回值为字符串 confirm
      // 如果用户取消了删除，则返回值为字符串 cancel
      if (confirmResult !== 'confirm') return this.$message.info('已取消操作');
       const params = {
        id,
        goodsId,
        claimStatus: 2,
        goodsStatus: { claimStatus: 1 },
      };
      const res = await changeClaimStatus(params);
      if (res.code !== 200) return this.$message.error(res.message);
      this.$message.success(res.message);
      this.$refs.ptTable.getTableList();
    },
    // 编辑数据
    handleEdit(id) {
      this.$router.push({
        path: '/user/claim/update',
        query: { id, redirect: this.$route.fullPath },
      });
    },
    // 删除数据
    async handleRemove({ id, claimStatus }) {
      if (claimStatus === 0 || claimStatus === 1) {
        return this.$message.info('流程进行中，暂时不能删除!');
      }
      // 弹框询问用户是否删除数据
      const confirmResult = await this.$confirm(
        '此操作将永久删除该数据, 是否继续?',
        '温馨提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      ).catch((err) => err);
      // 如果用户确认删除，则返回值为字符串 confirm
      // 如果用户取消了删除，则返回值为字符串 cancel
      if (confirmResult !== 'confirm') return this.$message.info('已取消删除');
      const res = await removeClaimInfo({ id, status: { status1: -1 } });
      if (res.code !== 200) return this.$message.error(res.message);
      const count = this.$refs.ptTable.items.length - 1; //当前页总数据
      if (count === 0 && this.$refs.ptTable.queryParams.page > 1) {
        // 如果当前页数据被完了，而且不是第一页，则页码减 1
        this.$refs.ptTable.queryParams.page -= 1;
      }
      this.$message.success(res.message);
      this.$refs.ptTable.getTableList();
      return;
    },
  },
};
</script>

<style lang="less" scoped>
/* ElementUI面包屑组件样式 */
.el-breadcrumb {
  margin-bottom: 15px;
  font-size: 12px;
}
/* ElementUI卡片组件样式 */
.el-card {
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) !important;
}
.btn {
  margin-left: 1rem;
}
/* 头像样式 */
/deep/.el-image__inner {
  height: 50px;
  border-radius: 10px;
}
/* 扩展列样式 */
/* 扩展列样式 */
.demo-table-expand {
  font-size: 0;
  padding: 25px;
}

.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}

.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  min-width: 30%;
}
</style>
