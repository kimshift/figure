<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/admin' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/admin/users' }">订单管理</el-breadcrumb-item>
      <el-breadcrumb-item>订单列表</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 卡片视图区域 -->
    <el-card>
      <pt-table
        ref="ptTable"
        :url="url"
        :columns="columns"
        :selectList="selectList"
        :operation="operation"
        searchTitle="请输入商品名字"
        expand
      >
        <!-- 自定扩展列 -->
        <template v-slot:expandBox="{ row }">
          <el-form label-position="left" inline class="demo-table-expand">
            <el-form-item label="卖家姓名:">
              <span>{{ row.User.nikeName }}</span>
            </el-form-item>
            <el-form-item label="买家姓名:">
              <span v-if="row.Order.Info">{{ row.Order.Info.nikeName }}</span>
              <span v-else>{{ row.Order.User.nikeName }}</span>
            </el-form-item>
            <el-form-item label="卖家电话:">
              <span>{{ row.User.phone }}</span>
            </el-form-item>
            <el-form-item label="联系电话:">
              <span v-if="row.Order.Info">{{ row.Order.Info.phone }}</span>
              <span v-else>{{ row.Order.User.phone }}</span>
            </el-form-item>
            <el-form-item label="发货地址:">
              <span>{{ row.User.address }}</span>
            </el-form-item>
            <el-form-item label="配送地址:">
              <span v-if="row.Order.Info">{{ row.Order.Info.address }}</span>
              <span v-else>{{ row.Order.User.address }}</span>
            </el-form-item>
            <el-form-item label="发货时间:">
              <span v-if="row.deliveryTime">
                {{ row.deliveryTime | dateFormat }}
              </span>
              <span v-else>暂未发货</span>
            </el-form-item>
            <el-form-item label="收货时间:">
              <span v-if="row.orderEndTime">
                {{ row.orderEndTime | dateFormat }}
              </span>
              <span v-else>暂未收货</span>
            </el-form-item>
            <el-form-item label="配送方式:">
              <span>{{ row.Order.orderDistribution }}</span>
            </el-form-item>
            <el-form-item
              label="订单操作:"
              v-if="
                row.orderStatus === -1 || row.orderStatus === 1 || row.orderStatus === 2
              "
            >
              <template>
                <el-button
                  type="success"
                  v-if="row.orderStatus === 1"
                  @click="handleEdit(row.id, 2, '发货')"
                  icon="el-icon-edit"
                  size="mini"
                  >准备发货</el-button
                >
                <el-button
                  type="primary"
                  v-if="row.orderStatus === -1"
                  @click="handleEdit(row.id, 0, '同意退货')"
                  icon="el-icon-delete"
                  size="mini"
                  >同意退货</el-button
                >
                <el-button
                  type="info"
                  v-if="row.orderStatus === 2"
                  @click="handleEdit(row.id, 1, '取消发货')"
                  icon="el-icon-scissors"
                  size="mini"
                  >取消发货</el-button
                >
              </template>
            </el-form-item>
          </el-form>
        </template>
        <!-- 自定义操作列 -->
        <template v-slot:operateBox="{ row }">
          <el-button
            size="mini"
            type="danger"
            icon="el-icon-delete"
            @click="handleRemove(row)"
            >删除</el-button
          >
        </template>
      </pt-table>
    </el-card>
  </div>
</template>

<script>
import PtTable from '@/common/PtTable';
import { columns, operation } from '@/config/tableOption/orderTable2';
import { updateOrderByAdmin } from '@/api';
export default {
  components: {
    PtTable,
  },
  data() {
    return {
      columns, //列配置(必传)
      operation, //操作列（选传）
      url: '/admin/order', //url、数据源tableData二传一(url优先级比tableData数据源高)
      selectList: [
        { value: 'null', label: '全部' },
        { value: -1, label: '退货中' },
        { value: 0, label: '已退货' },
        { value: 1, label: '待发货' },
        { value: 2, label: '待收货' },
        { value: 3, label: '已完成' },
      ],
    };
  },

  methods: {
    // 处理订单
    async handleEdit(id, orderStatus, message) {
      const res = await updateOrderByAdmin({ id, orderStatus, auth: true, message });
      if (res.code !== 200) return this.$message.error(res.message);
      this.$message.success(res.message);
      this.$refs.ptTable.getTableList();
    },
    // 删除数据
    async handleRemove({ id, orderStatus }) {
      if (orderStatus === 0 || orderStatus === 3) {
        // 弹框询问用户是否删除数据
        const confirmResult = await this.$confirm(
          '此操作将永久删除该数据, 是否继续?',
          '温馨提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
        ).catch((err) => err);
        // 如果用户确认删除，则返回值为字符串 confirm
        // 如果用户取消了删除，则返回值为字符串 cancel
        if (confirmResult !== 'confirm') return this.$message.info('已取消删除');
        // const res = await removeOrderGoods({ id, auth: true });
        if (res.code !== 200) return this.$message.error(res.message);
        const count = this.$refs.ptTable.items.length - 1; //当前页总数据
        if (count === 0 && this.$refs.ptTable.queryParams.page > 1) {
          // 如果当前页数据被完了，而且不是第一页，则页码减 1
          this.$refs.ptTable.queryParams.page -= 1;
        }
        this.$message.success(res.message);
        this.$refs.ptTable.getTableList();
        return;
      }
      return this.$message.error('交易进行中的订单不能删除！');
    },
  },
};
</script>

<style lang="less" scoped>
/* ElementUI面包屑组件样式 */
.el-breadcrumb {
  margin-bottom: 15px;
  font-size: 12px;
}
/* ElementUI卡片组件样式 */
.el-card {
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) !important;
}
.btn {
  margin-left: 1rem;
}
/* 头像样式 */
/deep/.el-image__inner {
  height: 50px;
  border-radius: 10px;
}
/* 扩展列样式 */
/* 扩展列样式 */
.demo-table-expand {
  font-size: 0;
  padding: 25px;
}

.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}

.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 35%;
}
</style>
