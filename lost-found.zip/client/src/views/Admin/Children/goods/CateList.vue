<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/admin' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>物品管理</el-breadcrumb-item>
      <el-breadcrumb-item>分类列表</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 卡片视图区域 -->
    <el-card>
      <pt-table ref="ptTable" :url="url" :columns="columns" :operation="operation">
        <!-- 表头上方操作按钮 -->
        <template slot="operateBtn">
          <el-button type="primary" @click="handleCreate">新增分类</el-button>
        </template>
        <!-- 自定义操作列 -->
        <template v-slot:operateBox="{ row }">
          <el-button
            size="mini"
            type="primary"
            icon="el-icon-edit"
            @click="handleEdit(row.id)"
            >编辑</el-button
          >
          <el-button
            size="mini"
            type="danger"
            icon="el-icon-delete"
            @click="handleRemove(row.id)"
            >删除</el-button
          >
        </template>
      </pt-table></el-card
    >
    <!-- 编辑对话框 -->
    <el-dialog
      :title="title"
      :visible.sync="operateFlag"
      width="30%"
      @close="dialogClosed('createRef')"
      :close-on-click-modal="false"
    >
      <el-form ref="createRef" :model="tempData" :rules="rules" label-width="100px">
        <el-form-item label="分类名称：" prop="cateName">
          <el-input
            placeholder="请输入分类名称"
            size="small"
            v-model="tempData.cateName"
            clearable
          ></el-input>
        </el-form-item>
        <el-form-item label="分类描述：" prop="introduce">
          <el-input
            type="textarea"
            :rows="3"
            placeholder="请输入分类描述"
            v-model="tempData.introduce"
            clearable
          >
          </el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="operateFlag = false">取 消</el-button>
        <el-button type="primary" @click="handleSubmit">提 交</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import PtTable from '@/common/PtTable';
import { columns, operation } from '@/config/tableOption/cateTable';
import { createCate, queryCateInfo, removeCateInfo, updateCate } from '../../../../api';
export default {
  components: {
    PtTable,
  },
  data() {
    return {
      columns, //列配置(必传)
      operation, //操作列（选传）
      url: '/public/cate', //url、数据源tableData二传一(url优先级比tableData数据源高)
      // 控制修改用户对话框的显示与隐藏
      editFlag: false, //编辑标识
      operateFlag: false, //操作标识
      tempData: {
        cateName: '',
        introduce: '',
      }, // 临时缓存数据对象
      rules: {
        cateName: [{ required: true, message: '请输入分类名称', trigger: 'blur' }],
      },
      title: '新增分类',
    };
  },
  methods: {
    // 监听对话框关闭
    dialogClosed(ref) {
      this.editFlag = false;
      this.$refs[ref].resetFields();
      this.tempData = {};
    },
    handleCreate() {
      this.operateFlag = true;
      this.editFlag = false;
      this.title = '新增分类';
    },
    // 提交数据
    handleSubmit() {
      this.$refs.createRef.validate(async (valid) => {
        if (!valid) return;
        const res = this.editFlag
          ? await updateCate(this.tempData)
          : await createCate(this.tempData);
        if (res.code !== 200) return this.$message.error(res.message);
        this.$message.success(res.message);
        this.operateFlag = false;
        this.$refs.ptTable.getTableList();
      });
    },
    // 编辑数据
    async handleEdit(id) {
      const res = await queryCateInfo(id);
      if (res.code !== 200) return this.$message.error(res.message);
      this.tempData = res.data;
      this.operateFlag = true;
      this.editFlag = true;
      this.title = '分类编辑';
    },
    // 删除数据
    async handleRemove(id) {
      // 弹框询问用户是否删除数据
      const confirmResult = await this.$confirm(
        '此操作将永久删除该数据, 是否继续?',
        '温馨提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      ).catch((err) => err);
      // 如果用户确认删除，则返回值为字符串 confirm
      // 如果用户取消了删除，则返回值为字符串 cancel
      if (confirmResult !== 'confirm') return this.$message.info('已取消删除');
      const res = await removeCateInfo(id);
      if (res.code !== 200) return this.$message.error(res.message);
      const count = this.$refs.ptTable.items.length - 1; //当前页总数据
      if (count === 0 && this.$refs.ptTable.queryParams.page > 1) {
        // 如果当前页数据被完了，而且不是第一页，则页码减 1
        this.$refs.ptTable.queryParams.page -= 1;
      }
      this.$message.success(res.message);
      this.$refs.ptTable.getTableList();
    },
  },
};
</script>

<style lang="less" scoped>
/* ElementUI面包屑组件样式 */
.el-breadcrumb {
  margin-bottom: 15px;
  font-size: 12px;
}
/* ElementUI卡片组件样式 */
.el-card {
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) !important;
}
.btn {
  margin-left: 1rem;
}
/* 头像样式 */
/deep/.el-image__inner {
  height: 50px;
  border-radius: 10px;
}
/deep/.el-input--small .el-input__inner {
  width: 270px;
}
/deep/.el-textarea__inner {
  width: 270px;
}
</style>
