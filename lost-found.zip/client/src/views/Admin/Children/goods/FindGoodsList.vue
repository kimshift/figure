<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/admin' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>物品管理</el-breadcrumb-item>
      <el-breadcrumb-item>拾物列表</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 卡片视图区域 -->
    <el-card>
      <pt-table
        ref="ptTable"
        :url="url"
        :columns="columns"
        :operation="operation"
        :queryParams="queryParams"
        searchTitle="请输入物品名称"
        @onSwitch="handleSwitch"
      >
        <!-- 表头上方操作按钮 -->
        <template slot="operateBtn">
          <el-button type="primary" @click="handleCreate">发布信息</el-button>
        </template>
        <!-- 自定义操作列 -->
        <template v-slot:operateBox="{ row }">
          <el-tooltip effect="dark" content="查看" placement="top" :enterable="false">
            <el-button
              type="success"
              icon="el-icon-search"
              circle
              @click="handleView(row.id)"
            ></el-button>
          </el-tooltip>
          <el-tooltip effect="dark" content="编辑" placement="top" :enterable="false">
            <el-button
              type="primary"
              icon="el-icon-edit"
              circle
              @click="handleEdit(row.id)"
            ></el-button>
          </el-tooltip>
          <el-tooltip effect="dark" content="删除" placement="top" :enterable="false">
            <el-button
              type="danger"
              icon="el-icon-delete"
              circle
              @click="handleRemove(row.id)"
            ></el-button>
          </el-tooltip>
        </template> </pt-table
    ></el-card>
  </div>
</template>

<script>
import PtTable from '@/common/PtTable';
import { columns, operation } from '@/config/tableOption/findGoodsTable';
import { changeGoodsStatus, removeGoodsInfo } from '../../../../api';
export default {
  components: {
    PtTable,
  },
  data() {
    return {
      columns, //列配置(必传)
      operation, //操作列（选传）
      url: '/public/goods', //url、数据源tableData二传一(url优先级比tableData数据源高)
      queryParams: {
        search: '', //搜索关键词
        page: 1, // 当前的页数
        limit: 5, // 当前每页显示多少条数据
        status: '', //默认查询条件''为对应后端操作的查询所有<除了逻辑删除的>
        type: 1, //物品类型<0:失物,1:拾物>
      },
    };
  },
  methods: {
    async handleSwitch(status, row) {
      const res = await changeGoodsStatus({ id: row.id, status});
      if (res.code !== 200) return this.$message.error(res.message);
      this.$message.success(res.message);
      this.$refs.ptTable.getTableList();
    },
    // 监听对话框关闭
    dialogClosed(ref) {
      this.$refs[ref].resetFields();
    },
    // 新增数据
    handleCreate() {
      this.$router.push({
        path: '/admin/goods/create',
        query: { redirect: this.$route.fullPath },
      });
    },
    // 查看数据
    handleView(id) {
      this.$router.push({
        path: '/admin/goods/view',
        query: { id, editFlag: false, redirect: this.$route.fullPath },
      });
    },
    // 编辑数据
    handleEdit(id) {
      this.$router.push({
        path: '/admin/goods/update',
        query: { id, editFlag: true, redirect: this.$route.fullPath },
      });
    },
    // 删除数据
    async handleRemove(id) {
      // 弹框询问用户是否删除数据
      const confirmResult = await this.$confirm(
        '此操作将永久删除该数据, 是否继续?',
        '温馨提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      ).catch((err) => err);
      // 如果用户确认删除，则返回值为字符串 confirm
      // 如果用户取消了删除，则返回值为字符串 cancel
      if (confirmResult !== 'confirm') return this.$message.info('已取消删除');
      const res = await removeGoodsInfo(id);
      if (res.code !== 200) return this.$message.error(res.message);
      const count = this.$refs.ptTable.items.length - 1; //当前页总数据
      if (count === 0 && this.$refs.ptTable.queryParams.page > 1) {
        // 如果当前页数据被完了，而且不是第一页，则页码减 1
        this.$refs.ptTable.queryParams.page -= 1;
      }
      this.$message.success(res.message);
      this.$refs.ptTable.getTableList();
    },
  },
};
</script>

<style lang="less" scoped>
/* ElementUI面包屑组件样式 */
.el-breadcrumb {
  margin-bottom: 15px;
  font-size: 12px;
}
/* ElementUI卡片组件样式 */
.el-card {
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) !important;
}
.btn {
  margin-left: 1rem;
}
/* 头像样式 */
/deep/.el-image__inner {
  height: 50px;
  border-radius: 10px;
}
</style>
