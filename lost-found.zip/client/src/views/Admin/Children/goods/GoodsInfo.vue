<template>
  <div class="goods-detail">
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/admin' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: redirect }">物品管理</el-breadcrumb-item>
      <el-breadcrumb-item>物品信息详情</el-breadcrumb-item>
    </el-breadcrumb>
    <el-form
      :model="goodsInfo"
      :rules="rules"
      ref="ruleForm"
      label-width="100px"
      class="demo-ruleForm"
      v-loading="loading"
      element-loading-text="loading..."
    >
      <el-row :gutter="20">
        <el-col :span="10">
          <el-form-item label="物品图片：">
            <img :src="goodsInfo.image" style="width: 90px" />
          </el-form-item>
        </el-col>
        <el-col :span="10" v-if="editFlag">
          <el-form-item label="更换图片：" style="width: 500px">
            <el-upload
              ref="upload"
              list-type="picture-card"
              :on-preview="handlePreview"
              :on-change="handleChange"
              :auto-upload="false"
              :multiple="false"
              :limit="limit"
              action
            >
              <i class="el-icon-plus"></i>
            </el-upload>
            <el-dialog :visible.sync="dialogVisible" width="35%">
              <img width="100%" :src="dialogImageUrl" alt />
            </el-dialog>
          </el-form-item>
        </el-col>
      </el-row>

      <el-form-item label="发布者：">
        <span v-if="goodsInfo.User && goodsInfo.User.Info">{{
          goodsInfo.User.Info.nikeName
        }}</span>
      </el-form-item>
      <el-form-item label="物品类型：">
        <el-tag v-if="goodsInfo.type === 0" type="info">失物</el-tag>
        <el-tag v-else type="success">拾物</el-tag>
      </el-form-item>
      <el-form-item label="是否紧急：" v-if="goodsInfo.type === 0">
        <template v-if="editFlag">
          <el-switch
            v-model="goodsInfo.need"
            active-color="#13ce66"
            :active-value="1"
            :inactive-value="0"
          ></el-switch>
        </template>
        <template v-else>
          <el-tag v-if="goodsInfo.type === 0">正常</el-tag>
          <el-tag v-else type="danger">急需</el-tag>
        </template>
      </el-form-item>
      <el-form-item label="物品名称：" prop="goodsName">
        <el-input v-model="goodsInfo.goodsName" :disabled="!editFlag"></el-input>
      </el-form-item>
      <el-form-item label="物品分类：" prop="cateId">
        <el-select
          v-model="goodsInfo.cateId"
          placeholder="请选择分类"
          :disabled="!editFlag"
        >
          <el-option
            v-for="item in cateList"
            :key="item.id"
            :label="item.cateName"
            :value="item.id"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="详情描述：" prop="introduce">
        <el-input
          :cols="30"
          :row="10"
          clearable
          :disabled="!editFlag"
          type="textarea"
          v-model="goodsInfo.introduce"
        ></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="editSubmit()" v-if="editFlag">保 存</el-button>
        <el-button @click="resetForm()">返 回</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import { updateGoodsInfo, getCateList, getGoodsInfo } from '../../../../api';
export default {
  data() {
    return {
      editFlag: false,
      goodsId: '',
      goodsInfo: {}, //物品信息
      cateList: [], // 分类
      fileList: [], //上传图片列表
      limit: 1, //限制图片上传数量
      dialogImageUrl: '', //缓存地址
      dialogVisible: false,
      // 表单验证
      rules: {
        goodsName: [{ required: true, message: '请输入物品名称', trigger: 'blur' }],
        type: [{ required: true, message: '请选择物品类型', trigger: 'blur' }],
        cateId: [{ required: true, message: '请选择物品分类', trigger: 'blur' }],
        introduce: [{ required: true, message: '请输入详情描述', trigger: 'blur' }],
      },
      redirect: '/admin', //上一级路由
      loading: false,
    };
  },
  created() {
    const { id, editFlag, redirect } = this.$route.query;
    if (!id) return this.$message.error('物品id获取失败');
    this.goodsId = id;
    this.editFlag = editFlag === 'true';
    this.getCateList();
    this.getGoodsInfo(id);
    if (redirect) this.redirect = redirect;
  },
  methods: {
    async getCateList() {
      const res = await getCateList();
      if (res.code !== 200) return this.$message.error(res.message);
      this.cateList = res.data.rows;
    },
    async getGoodsInfo(id) {
      this.loading = true;
      const res = await getGoodsInfo(id);
      this.loading = false;
      if (res.code !== 200) return this.$message.error(res.message);
      this.goodsInfo = res.data;
    },
    // 选择上传图片
    handleChange(file, fileList) {
      if (fileList.length > 1) {
        fileList = fileList.slice(-1);
      }
      this.fileList = fileList;
    },
    // 预览图片
    handlePreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    resetForm() {
      if (this.editFlag) this.$refs.upload.clearFiles();
      this.$refs.ruleForm.resetFields();
      this.fileList = [];
      this.$router.push(this.redirect);
    },
    // 修改物品信息
    editSubmit() {
      this.$refs.ruleForm.validate(async (valid) => {
        if (!valid) return;
        const formData = new FormData();
        delete this.goodsInfo['User'];
        delete this.goodsInfo['Cate'];
        formData.append('goodsInfo', JSON.stringify(this.goodsInfo));
        if (this.fileList.length) {
          formData.append('image', this.fileList[0].raw);
        }
        const res = await updateGoodsInfo(formData, this.goodsId);
        if (res.code !== 200) return this.$message.error(res.message);
        this.$message.success(res.message);
        this.resetForm();
      });
    },
  },
};
</script>

<style scoped lang="less" scoped>
@common_width: 70%;
.goods-detail {
  width: @common_width;
  .el-input {
    width: @common_width;
  }
}
.el-breadcrumb {
  margin-bottom: 15px;
  font-size: 12px;
}
.el-select {
  width: @common_width;
}
.el-textarea {
  width: @common_width;
}
/deep/.el-textarea__inner {
  height: 100px;
}

/deep/.el-input.is-disabled .el-input__inner,
/deep/.el-textarea.is-disabled .el-textarea__inner {
  color: #333;
}
</style>
