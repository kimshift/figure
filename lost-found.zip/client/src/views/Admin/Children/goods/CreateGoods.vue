<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/admin' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item v-if="redirect" :to="{ path: redirect }"
        >物品管理</el-breadcrumb-item
      >
      <el-breadcrumb-item v-else>物品管理</el-breadcrumb-item>
      <el-breadcrumb-item>信息发布</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 卡片视图 -->
    <el-card>
      <!-- 提示区域 -->
      <el-alert
        title="信息发布"
        type="info"
        center
        show-icon
        :closable="false"
      ></el-alert>
      <div class="form">
        <el-form
          :model="tempData"
          :rules="rules"
          ref="addFormRef"
          label-width="100px"
          label-position="left"
        >
          <el-form-item label="物品类型：" prop="type">
            <el-radio v-model="tempData.type" :label="0">失物</el-radio>
            <el-radio v-model="tempData.type" :label="1">拾物</el-radio>
          </el-form-item>
          <el-form-item label="是否紧急：" v-if="tempData.type === 0">
            <el-switch
              v-model="tempData.need"
              active-color="#13ce66"
              :active-value="1"
              :inactive-value="0"
            ></el-switch>
          </el-form-item>
          <el-form-item label="物品名称：" prop="goodsName">
            <el-input v-model="tempData.goodsName" placeholder="请输入物品名称"></el-input>
          </el-form-item>
          <el-form-item label="物品分类：" prop="cateId">
            <el-select v-model="tempData.cateId" placeholder="请选择分类">
              <el-option
                v-for="item in cateList"
                :key="item.id"
                :label="item.cateName"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="详情描述：" prop="introduce">
            <el-input
              :cols="30"
              :row="10"
              type="textarea"
              v-model="tempData.introduce"
              placeholder="请输入详情描述："
            ></el-input>
          </el-form-item>
          <el-form-item label="物品图片：">
            <el-upload
              ref="upload"
              list-type="picture-card"
              :on-preview="handlePreview"
              :on-change="handleChange"
              :auto-upload="false"
              :multiple="false"
              :limit="limit"
              action
            >
              <i class="el-icon-plus"></i>
            </el-upload>
          </el-form-item>
          <el-button type="primary" class="btnAdd" @click="addSubmit">发布信息</el-button>
        </el-form>
      </div>
    </el-card>

    <!-- 图片预览 -->
    <el-dialog :visible.sync="dialogVisible" width="35%" title="图片预览">
      <img width="100%" :src="dialogImageUrl" alt />
    </el-dialog>
  </div>
</template>

<script>
import { createGoods, getCateList } from '../../../../api';
export default {
  data() {
    return {
      // 添加物品的表单数据对象
      tempData: { type: 0, need: 0 },
      rules: {
        goodsName: [{ required: true, message: '请输入物品名称', trigger: 'blur' }],
        type: [{ required: true, message: '请选择物品类型', trigger: 'blur' }],
        cateId: [{ required: true, message: '请选择物品分类', trigger: 'change' }],
        introduce: [{ required: true, message: '请输入详情描述', trigger: 'blur' }],
      },
      // 物品分类列表
      cateList: [],
      limit: 1, //限制图片上传数量
      fileList: [], //上传图片列表
      dialogImageUrl: '', //图片缓存地址
      dialogVisible: false,
      previewPath: '',
      previewVisible: false,
      redirect: '', //上一级路由
    };
  },
  created() {
    this.getCateList();
    const { redirect } = this.$route.query;
    if (redirect) this.redirect = redirect;
  },
  watch: {
    'tempData.type': {
      handler(newVal) {
        if (newVal === 1) {
          this.tempData.need = 0;
        }
      },
    },
  },
  methods: {
    // 获取所有物品分类数据
    async getCateList() {
      const res = await getCateList();
      if (res.code !== 200) return this.$message.error(res.message);
      this.cateList = res.data.rows;
    },
    //文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
    handleChange(file, fileList) {
      if (fileList.length > 1) {
        fileList = fileList.slice(-1);
      }
      this.fileList = fileList;
    },
    // 处理图片预览效果
    handlePreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    // 添加物品
    addSubmit() {
      this.$refs.addFormRef.validate(async (valid) => {
        if (!valid) return;
        if (!this.fileList.length) {
          return this.$message.info('请上传物品图像');
        }
        if (this.tempData.type) {
          // 物品类型为拾物
          this.tempData.claimStatus = 0; //待认领
          this.redirect='/admin/collectGoods'
        } else {
          // 物品类型为失物
          this.tempData.findStatus = 0; //带寻回
          this.redirect=this.tempData.need?'/admin/needGoods':'/admin/lostGoods'
        }
        const formData = new FormData();
        formData.append('image', this.fileList[0].raw);
        formData.append('goodsInfo', JSON.stringify(this.tempData));
        const res = await createGoods(formData);
        if (res.code !== 200) return this.$message.error(res.message);
        this.$message.success(res.message);
        this.$refs.addFormRef.resetFields();
        this.fileList = [];
        this.$refs.upload.clearFiles();
        this.$router.push({ path: this.redirect });
      });
    },
  },
};
</script>

<style lang="less" scoped>
@input-width: 50%;
/* ElementUI面包屑组件样式 */
.el-breadcrumb {
  margin-bottom: 15px;
  font-size: 12px;
}
/* ElementUI卡片组件样式 */
.el-card {
  min-height: 600px;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) !important;
}
.form {
  padding: 25px;
}
/deep/.el-form--label-left .el-form-item__label {
  text-align: right;
}
.el-input {
  width: @input-width;
}
.el-select {
  width: @input-width;
}
.el-select-dropdown__item.selected {
  color: #606266;
}
/deep/.el-textarea__inner {
  width: @input-width;
  height: 100px;
}

.btnAdd {
  display: block;
  margin: 100px auto;
  width: 400px;
  height: 50px;
  border-radius: 25px;
}
</style>
