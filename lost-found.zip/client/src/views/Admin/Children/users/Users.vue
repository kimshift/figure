<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/admin' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/admin/users' }">用户管理</el-breadcrumb-item>
      <el-breadcrumb-item>用户列表</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 卡片视图区域 -->
    <el-card>
      <pt-table
        ref="ptTable"
        :url="url"
        :columns="columns"
        :operation="operation"
        select
        @onSelect="handleSelect"
        @onSwitch="handleSwitch"
      >
        <!-- 表头上方操作按钮 -->
        <template slot="operateBtn" v-if="checked">
          <el-button plain @click="resetFlag = true">重置密码</el-button>
        </template>
        <!-- 自定义操作列 -->
        <template v-slot:operateBox="{ row }">
          <el-button
            size="mini"
            type="success"
            icon="el-icon-search"
            @click="handleView(row.id)"
            >查看</el-button
          >
          <el-button
            size="mini"
            type="primary"
            icon="el-icon-edit"
            v-if="row.Info && row.Info.status === 2"
            @click="handleAuth(row.id)"
            >审核</el-button
          >
        </template>
      </pt-table></el-card
    >
    <!-- 操作对话框 -->
    <el-dialog
      :title="title"
      :visible.sync="operateFlag"
      width="50%"
      @close="dialogClosed('operateRef')"
      :close-on-click-modal="false"
    >
      <el-form :model="authData" ref="operateRef" :rules="rules" label-width="100px">
        <el-form-item label="用户头像：">
          <img
            v-if="tempData.Info && tempData.Info.image"
            :src="tempData.Info.image"
            alt
            width="90px"
          />
        </el-form-item>
        <el-form-item label="账号：">
          <span>{{ tempData.username }}</span>
        </el-form-item>
        <el-form-item label="姓名：">
          <span v-if="tempData.Info">{{ tempData.Info.nikeName }}</span>
        </el-form-item>
        <el-form-item label="性别：">
          <el-tag v-if="tempData.Info && tempData.Info.sex === 1"> 男 </el-tag>
          <el-tag v-else type="success"> 女 </el-tag>
        </el-form-item>
        <el-form-item label="电话：">
          <span v-if="tempData.Info">{{ tempData.Info.phone }}</span>
        </el-form-item>
        <el-form-item label="地址：">
          <span v-if="tempData.Info">{{ tempData.Info.address }}</span>
        </el-form-item>
        <el-form-item label="注册时间：">
          <span>{{ tempData.createTime | dateFormat }}</span>
        </el-form-item>
        <el-form-item label="实名状态：">
          <el-tag v-if="tempData.Info && tempData.Info.status === 1" type="success">
            已实名
          </el-tag>
          <el-tag v-else-if="tempData.Info && tempData.Info.status === 2" type="warning">
            待审核
          </el-tag>
          <el-tag v-else type="info"> 未实名 </el-tag>
        </el-form-item>
        <el-form-item
          label="申请材料："
          v-if="editFlag || (tempData.Info && tempData.Info.authImage)"
        >
          <img
            v-if="tempData.Info && tempData.Info.authImage"
            :src="tempData.Info.authImage"
            width="90px"
            @click="handlePreview(tempData.Info.authImage)"
          />
          <span v-else>暂无</span>
        </el-form-item>
        <el-form-item label="审核：" prop="status" v-if="editFlag">
          <template>
            <el-radio v-model="authData.status" :label="1">通过</el-radio>
            <el-radio v-model="authData.status" :label="0">不通过</el-radio>
          </template>
        </el-form-item>
        <el-form-item label="审核意见：" v-if="editFlag" prop="opinion">
          <el-input
            :cols="30"
            :row="10"
            type="textarea"
            v-model="authData.opinion"
            placeholder="请输入审核意见"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="审核意见："
          v-if="
            !editFlag &&
            tempData.Info &&
            tempData.Info.status !== 1 &&
            tempData.Info.opinion
          "
        >
          <p>{{ tempData.Info.opinion }}</p>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="operateFlag = false">关 闭</el-button>
        <el-button @click="hanldeSubmit" type="primary">提 交</el-button>
      </span>
    </el-dialog>
    <!-- 编辑对话框 -->
    <el-dialog
      title="重置密码"
      :visible.sync="resetFlag"
      width="25%"
      @close="dialogClosed('resetRef')"
      :close-on-click-modal="false"
    >
      <el-form ref="resetRef" :model="resetData" :rules="rules" label-width="100px">
        <el-form-item label="密码：" prop="password">
          <el-input
            placeholder="请输入重置密码"
            size="small"
            v-model="resetData.password"
            clearable
          ></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="resetFlag = false">取 消</el-button>
        <el-button type="primary" @click="resetSubmit">提 交</el-button>
      </span>
    </el-dialog>
    <!-- 图片预览 -->
    <el-dialog
      :visible.sync="dialogVisible"
      width="35%"
      title="审核文件"
      @close="dialogClosed"
    >
      <img width="100%" :src="dialogImageUrl" alt />
    </el-dialog>
  </div>
</template>

<script>
import { mapState } from 'vuex';
import PtTable from '@/common/PtTable';
import { columns, operation } from '@/config/tableOption/userTable';
import { changeUserStatus, queryUserInfo, resetPwd, updateAuth } from '@/api';
export default {
  components: {
    PtTable,
  },
  data() {
    const checkPwd = (rule, value, callback) => {
      let pattern = /^[A-Za-z0-9]{6,16}$/;
      if (!pattern.test(value)) {
        callback(new Error('密码只能由英文、数字组成的6-16位!'));
      } else {
        callback();
      }
    };
    return {
      columns, //列配置(必传)
      operation, //操作列（选传）
      url: '/admin/user', //url、数据源tableData二传一(url优先级比tableData数据源高)
      title: '',
      operateFlag: false, //查看标识
      editFlag: false, //编辑标识
      resetFlag: false, //重置标识
      resetData: { password: '' }, //重置密码
      authData: { status: 1, opinion: '' }, //审核缓存对象
      tempData: {}, // 临时缓存数据对象
      checked: false, //复选框是否存在被选中
      selectList: [], //选中的数据
      rules: {
        password: [
          { required: true, message: '请输入重置密码', trigger: 'blur' },
          { validator: checkPwd, trigger: 'blur' },
        ],
        status: [{ required: true, message: '请选择审核状态', trigger: 'blur' }],
      },
      dialogVisible: false,
      dialogImageUrl: '',
    };
  },
  computed: {
    ...mapState(['userInfo']),
  },
  methods: {
    handleSelect(rows) {
      this.selectList = rows;
      this.checked = rows.length > 0;
    },
    async handleSwitch(status, row) {
      const res = await changeUserStatus({ id: row.id, status });
      if (res.code !== 200) return this.$message.error(res.message);
      this.$message.success(res.message);
      this.$refs.ptTable.getTableList();
    },
    // 查看数据
    handleView(id) {
      this.editFlag = false;
      this.getUserInfo(id);
    },
    // 审核数据
    async handleAuth(id) {
      this.editFlag = true;
      this.getUserInfo(id);
    },
    async getUserInfo(id) {
      const res = await queryUserInfo(id);
      if (res.code !== 200) return this.$message.error(res.message);
      this.tempData = res.data;
      this.operateFlag = true;
    },
    // 提交审核
    async hanldeSubmit() {
      const res = await updateAuth(this.tempData.id, this.authData);
      if (res.code !== 200) return this.$message.error(res.message);
      this.operateFlag = false;
      this.$message.success(res.message);
      this.$refs.ptTable.getTableList();
    },
    // 监听对话框关闭
    dialogClosed(ref) {
      if (ref) {
        this.$refs[ref].resetFields();
        this.tempData = {};
        this.editFlag = false;
      }
      this.dialogImageUrl = '';
    },
    // 重置密码
    resetSubmit() {
      this.$refs.resetRef.validate(async (valid) => {
        if (!valid) return;
        const { password } = this.resetData;
        const userList = this.selectList.map((item) => {
          return item.id;
        });
        const params = { password, userList };
        const res = await resetPwd(params);
        if (res.code !== 200) return this.$message.error(res.message);
        this.$message.success(res.message);
        this.resetFlag = false;
        this.$refs.ptTable.getTableList();
      });
    },
    // 图片预览
    handlePreview(url) {
      this.dialogImageUrl = url;
      this.dialogVisible = true;
    },
  },
};
</script>

<style lang="less" scoped>
/* ElementUI面包屑组件样式 */
.el-breadcrumb {
  margin-bottom: 15px;
  font-size: 12px;
}
/* ElementUI卡片组件样式 */
.el-card {
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) !important;
}
.btn {
  margin-left: 1rem;
}
/* 头像样式 */
/deep/.el-image__inner {
  height: 50px;
  border-radius: 10px;
}
</style>
