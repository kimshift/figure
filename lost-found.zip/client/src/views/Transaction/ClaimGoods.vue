<template>
  <div class="goodsBox">
    <!-- 卡片视图 -->
    <el-card>
      <!-- 提示区域 -->
      <el-alert
        :title="goodsInfo.type ? '物品认领申请' : '物品归还申请'"
        type="info"
        center
        show-icon
        :closable="false"
      ></el-alert>
      <div class="form">
        <el-form
          :model="tempData"
          :rules="rules"
          ref="createRef"
          label-width="110px"
          label-position="left"
        >
          <el-form-item
            v-if="goodsInfo.User && goodsInfo.User.Info"
            :label="goodsInfo.type ? '拾主姓名：' : '失主姓名：'"
          >
            <span>{{ goodsInfo.User.Info.nikeName }}</span>
          </el-form-item>
          <el-form-item label="物品名称：">
            <span>{{ goodsInfo.goodsName }}</span>
          </el-form-item>
          <el-form-item label="物品图片：">
            <img
              :src="goodsInfo.image"
              alt=""
              @click="handlePreview(goodsInfo.image)"
              width="90px"
            />
          </el-form-item>
          <el-form-item label="交接方式：" prop="distribution">
            <el-radio v-model="tempData.distribution" :label="0">自取</el-radio>
            <el-radio v-model="tempData.distribution" :label="1">邮寄</el-radio>
          </el-form-item>
          <el-form-item label="申请人姓名：" prop="nikeName">
            <el-input v-model="tempData.nikeName" placeholder="请输入姓名"></el-input>
          </el-form-item>
          <el-form-item label="申请人电话：" prop="phone">
            <el-input v-model="tempData.phone" placeholder="请输入电话"></el-input>
          </el-form-item>
          <el-form-item label="申请人地址：" prop="address">
            <el-input v-model="tempData.address" placeholder="请输入地址"></el-input>
          </el-form-item>
          <el-form-item label="备注说明：">
            <el-input
              :cols="30"
              :row="10"
              type="textarea"
              v-model="tempData.introduce"
              placeholder="请输入备注说明"
            ></el-input>
          </el-form-item>
          <el-form-item label="申请材料：">
            <el-upload
              ref="upload"
              list-type="picture-card"
              :on-preview="handlePreview"
              :on-change="handleChange"
              :on-remove="handleRemove"
              :auto-upload="false"
              :multiple="false"
              :limit="limit"
              action
            >
              <i class="el-icon-plus"></i>
            </el-upload>
          </el-form-item>
          <el-form-item label="申请说明：" prop="explain">
            <el-input
              :cols="30"
              :row="10"
              type="textarea"
              v-model="tempData.explain"
              placeholder="此处填写申请理由，详细描述能该物品的相关信息能方便工作人员审核。"
            ></el-input>
          </el-form-item>
          <el-button type="primary" class="btnAdd" @click="addSubmit">提交申请</el-button>
        </el-form>
      </div>
    </el-card>
    <!-- 图片预览 -->
    <el-dialog :visible.sync="dialogVisible" width="35%" title="图片预览">
      <img width="100%" :src="dialogImageUrl" alt />
    </el-dialog>
    <!-- 申请成功模态框 -->
    <el-dialog
      title="温馨提示"
      :visible.sync="visible"
      width="30%"
      center
      :close-on-click-modal="false"
      :destroy-on-close="true"
    >
      <span stype="text-align:center">{{ message }}</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="goPath(false)">返回浏览页</el-button>
        <el-button type="primary" @click="goPath(true)">前往申请管理</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';
import { createClaim } from '../../api';
import { checkMobile } from '@/utils/regexp.js';
export default {
  data() {
    return {
      tempData: { distribution: 0 },
      rules: {
        nikeName: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        phone: [
          { required: true, message: '请输入电话', trigger: 'blur' },
          { validator: checkMobile, trigger: 'blur' },
        ],
        address: [{ required: true, message: '请输入地址', trigger: 'blur' }],
        distribution: [{ required: true, message: '请选择交接方式', trigger: 'blur' }],
        explain: [{ required: true, message: '请输入申请说明', trigger: 'blur' }],
      },
      limit: 1, //限制图片上传数量
      fileList: [], //上传图片列表
      dialogImageUrl: '', //图片缓存地址
      dialogVisible: false,
      previewPath: '',
      previewVisible: false,
      visible: false,
      message: '',
    };
  },
  created() {
    const { goodsId } = this.$route.query;
    if (!goodsId) {
      this.notifyError('物品id获取失败!');
      return;
    }
    this.reqGoodsInfo(goodsId);
  },
  computed: {
    ...mapState(['goodsInfo']),
  },
  methods: {
    ...mapActions(['reqGoodsInfo']),
    // 删除文件回调
    handleRemove(file, fileList) {
      if (fileList.length < this.limit) {
        this.$el.style.setProperty('--displayStyle', 'inline-block');
      }
    },
    //文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
    handleChange(file, fileList) {
      this.fileList = fileList;
      if (fileList.length === this.limit) {
        this.$el.style.setProperty('--displayStyle', 'none');
      }
    },
    // 处理图片预览效果
    handlePreview(file) {
      this.dialogImageUrl = file.url || file; //兼容物品图片预览
      this.dialogVisible = true;
    },
    // 添加物品
    addSubmit() {
      this.$refs.createRef.validate(async (valid) => {
        if (!valid) return;
        if (!this.fileList.length) {
          return this.notifyInfo('请上传申请材料');
        }
        this.tempData.goodsId = this.goodsInfo.id;
        this.tempData.type = this.goodsInfo.type;
        const formData = new FormData();
        formData.append('image', this.fileList[0].raw);
        formData.append('claimInfo', JSON.stringify(this.tempData));
        const res = await createClaim(this.goodsInfo.id, formData);
        if (res.code !== 200) return this.notifyError(res.message);
        this.message = res.message;
        this.visible = true;
      });
    },
    goPath(flag) {
      if (flag) {
        const url = this.goodsInfo.type ? '/user/claim' : '/user/give';
        this.$router.replace({ path: url });
      } else {
        this.$router.replace({ path: this.$route.query.redirect });
      }
      this.$refs.createRef.resetFields();
      this.fileList = [];
      this.$refs.upload.clearFiles();
    },
  },
};
</script>

<style lang="less" scoped>
.goodsBox {
  width: 1225px;
  margin: 0 auto;
  --displayStyle: inline-block;
  /deep/.el-upload--picture-card {
    display: var(--displayStyle);
  }
}
@input-width: 50%;
/* ElementUI面包屑组件样式 */
.el-breadcrumb {
  margin-bottom: 15px;
  font-size: 12px;
}
/* ElementUI卡片组件样式 */
.el-card {
  min-height: 600px;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) !important;
}
.form {
  padding: 25px;
}
/deep/.el-form--label-left .el-form-item__label {
  text-align: right;
}
.el-input {
  width: @input-width;
}
.el-select {
  width: @input-width;
}
.el-select-dropdown__item.selected {
  color: #606266;
}
/deep/.el-textarea__inner {
  width: @input-width;
  height: 100px;
}

.btnAdd {
  display: block;
  margin: 100px auto;
  width: 400px;
  height: 50px;
  border-radius: 25px;
}
</style>
