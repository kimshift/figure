<template>
  <div class="home" id="home" name="home">
    <!-- 轮播图 -->
    <div class="slideshow">
      <el-carousel>
        <el-carousel-item v-for="item in carousel" :key="item.id">
          <img
            :src="item.image"
            :alt="item.introduce"
            @click="handleClickImg(item.goodsId)"
          />
        </el-carousel-item>
      </el-carousel>
    </div>
    <!-- 轮播图END -->
    <div class="main-box">
      <div class="main">
        <div>
          <div class="box-hd">
            <div class="title">急需物品</div>
            <div class="more" @click="handleNeedMore">
              MORE <i class="el-icon-arrow-right"></i>
            </div>
          </div>
          <div class="box-bd">
            <div class="goodsListBox">
              <GoodsItem
                :goodsList="goodsList"
                v-if="goodsList.length > 0"
                :hot="true"
              ></GoodsItem>
              <div v-else class="none-goodsList">
                抱歉没有找到相关的物品，请看看其他的物品
              </div>
            </div>
          </div>
        </div>
        <template v-if="homeGoodsList.length > 0">
          <div v-for="item in homeGoodsList" :key="item.id">
            <div class="box-hd">
              <div class="title" v-if="item[0] && item[0].Cate">
                {{ item[0].Cate.cateName }}
              </div>
              <div
                class="more"
                v-if="item[0] && item[0].Cate"
                @click="handleMore(item[0].Cate.id, item.length)"
              >
                MORE <i class="el-icon-arrow-right"></i>
              </div>
            </div>
            <div class="box-bd">
              <div class="goodsListBox">
                <GoodsItem
                  :goodsList="item"
                  v-if="item.length > 0"
                  :hot="true"
                ></GoodsItem>
                <div v-else class="none-goodsList">
                  抱歉没有找到相关的物品，请看看其他的物品
                </div>
              </div>
            </div>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapActions } from 'vuex';
import GoodsItem from '../../components/GoodsItem';
export default {
  components: {
    GoodsItem,
  },
  data() {
    return {
      params: {
        page: 1, // 当前的页数
        limit: 5, // 当前每页显示多少条数据
        status: 1, //默认查询上架物品
        need: 1, //急需
        sort: JSON.stringify({}), //排序方式:升序1，降序-1
      }, //首页物品请求参数
    };
  },
  created() {
    this.reqHomeCasual(); //查询轮播图
    this.reqGoodsList(this.params); //查询首页急需物品数据
    this.reqHomeGoodsList(this.params); //查询首页物品数据
  },
  computed: {
    ...mapState(['carousel', 'goodsList', 'homeGoodsList']),
  },
  methods: {
    ...mapActions(['reqHomeCasual', 'reqGoodsList', 'reqHomeGoodsList']),
    handleClickImg(goodsId) {
      if (goodsId) this.$router.push({ path: '/goodsInfo', query: { goodsId } });
    },
    // 急需查看更多
    handleNeedMore() {
      if (this.goodsList.length === 0) return this.notifyInfo('没有更多数据了');
      this.$router.push({ path: '/lostGoods', query: { need: 1 } });
    },
    // 分类查看更多
    handleMore(cateId, length) {
      if (length === 0) return this.notifyInfo('没有更多数据了');
      this.$router.push({ path: '/allGoods', query: { cateId } });
    },
  },
};
</script>
<style lang="less" scoped>
.main-box {
  background-color: #f5f5f5;
  padding-bottom: 20px;
}

.main {
  margin: 0 auto;
  max-width: 1225px;
}

/* 轮播图CSS */
.slideshow {
  margin: 20px auto;
  max-width: 1000px;
  cursor: pointer;
  .el-carousel {
    height: 350px;
    img {
      width: 1000px;
      height: 350px;
    }
  }
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }

  .el-carousel__item:nth-child(2n + 1) {
    background-color: #d3dce6;
  }
}
/* 轮播图CSS END */

.box-hd {
  height: 58px;
  margin: 20px 0 0 0;
  display: flex;
  .title {
    font-size: 22px;
    font-weight: 400;
    line-height: 58px;
    color: #333;
  }
  .more {
    margin-left: 10px;
    line-height: 51px;
    color: #d44d44;
    cursor: pointer;
  }
}

.box-bd {
  .goodsListBox {
    padding-top: 14.5px;
    margin-left: -13.7px;
    overflow: auto;
    .none-goodsList {
      color: #333;
      margin-left: 13.7px;
    }
  }
}
</style>
