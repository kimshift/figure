<template>
  <div class="goods" id="goods" name="goods">
    <!-- 分类标签 -->
    <div class="nav">
      <div class="goodsList-nav">
        <el-tabs v-model="queryParams.cateId" type="card">
          <el-tab-pane
            v-for="item in cateList"
            :key="item.id"
            :label="item.cateName"
            :name="`${item.id}`"
          />
        </el-tabs>
      </div>
    </div>
    <!-- 分类标签END -->

    <!-- 主要内容区 -->
    <div class="main">
      <div class="goodsListBox">
        <!-- 筛选栏 -->
        <div class="order-box">
          <div class="order text-center">
            <div class="item" @click="reseted">重置筛选</div>
            <div
              class="item"
              v-for="screen in screenList"
              :key="screen.id"
              :class="{ active: screen.status > 0 }"
              @click="handleSort(screen)"
            >
              <span>{{ screen.lable }}</span>
              <i :class="screen.icon"></i>
            </div>
          </div>
        </div>
        <GoodsItem :goodsList="goodsList" v-if="goodsList.length > 0"></GoodsItem>
        <div v-else class="none-goodsList">抱歉没有找到相关的商品，请看看其他的商品</div>
      </div>
      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          background
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="queryParams.page"
          :page-sizes="pageSizes"
          :page-size="queryParams.limit"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        ></el-pagination>
      </div>
      <!-- 分页END -->
    </div>
    <!-- 主要内容区END -->
  </div>
</template>
<script>
import GoodsItem from '@/components/GoodsItem';
import { mapState, mapActions, mapMutations } from 'vuex';
export default {
  components: {
    GoodsItem,
  },
  data() {
    return {
      pageSizes: [1, 5, 10, 15, 20, 30],
      screenList: [
        { id: 1, lable: '综合排序', value: 'id', icon: '', status: 0 },
        { id: 2, lable: '时间排序', value: 'createTime', icon: '', status: 0 },
        { id: 3, lable: '是否急需', value: 'need', icon: '', status: 0 },
      ], //筛选栏
    };
  },
  created() {
    this.reqCateList();
    const { cateId } = this.$route.query;
    if (cateId) this.queryParams.cateId = cateId;
    else this.queryParams.cateId = '0'; //默认全部
    this.reqGoodsList(this.queryParams);
  },
  computed: {
    ...mapState(['cateList', 'goodsList', 'queryParams', 'total']),
  },
  watch: {
    'queryParams.cateId': {
      handler: function (newVal, oldVal) {
        if (newVal !== oldVal) {
          this.queryParams.cateId = newVal;
          const params = { cateId: newVal };
          if (this.queryParams.search?.trim()) params.search = this.queryParams.search;
          this.queryParams.page = 1;
          this.setQueryParams(this.queryParams); //同步参数体
          this.$router.push({
            path: '/allGoods',
            query: params,
          });
        }
      },
      deep: true,
    },
    $route() {
      const { search, cateId } = this.$route.query;
      this.queryParams.search = search;
      if (cateId) this.queryParams.cateId = cateId;
      else this.queryParams.cateId = '0'; //默认全部
      this.setQueryParams(this.queryParams);
      this.reqGoodsList(this.queryParams);
    },
  },
  methods: {
    ...mapMutations(['setQueryParams']),
    ...mapActions(['reqGoodsList', 'reqCateList']),
    // 监听 加载量 改变的事件
    handleSizeChange(newSize) {
      this.queryParams.limit = newSize;
      this.reqGoodsList(this.queryParams);
      this.backtop();
    },
    // 监听 页码值 改变的事件
    handleCurrentChange(newPage) {
      this.queryParams.page = newPage;
      this.reqGoodsList(this.queryParams);
      this.backtop();
    },
    // 排序
    handleSort(val) {
      let [icon, iconDesc, iconAsc] = ['', 'el-icon-bottom', 'el-icon-top']; //解构赋值
      let order = {};
      let status = 0;
      // 当前状态-->将改变的状态
      switch (val.status) {
        case 0: //未排序-->倒序
          status = 1;
          icon = iconDesc;
          order = { [val.value]: -1 };
          break;
        case 1: //倒序-->正序
          status = 2;
          icon = iconAsc;
          order = { [val.value]: 1 };
          break;
        case 2: //正序-->倒序
          status = 1;
          icon = iconDesc;
          order = { [val.value]: -1 };
          break;
        default:
          break;
      }
      this.queryParams.sort = JSON.stringify(order);
      this.queryParams.page = 1;
      this.screenList.forEach((item) => {
        if (item.id == val.id) {
          item.status = status;
          item.icon = icon;
        } else {
          item.status = 0;
          item.icon = '';
        }
      });
      this.reqGoodsList(this.queryParams);
    },
    reseted() {
      this.screenList.forEach((item) => {
        item.icon = '';
        item.status = 0;
      });
      this.queryParams.sort = undefined;
      this.queryParams.page = 1;
      this.reqGoodsList(this.queryParams);
    },
    // 返回顶部
    backtop() {
      const timer = setInterval(function () {
        const top = document.documentElement.scrollTop || document.body.scrollTop;
        const speed = Math.floor(-top / 5);
        document.documentElement.scrollTop = document.body.scrollTop = top + speed;
        if (top === 0) {
          clearInterval(timer);
        }
      }, 20);
    },
  },
  beforeDestroy() {
    // 销毁前重置请求参数
    this.queryParams.page = 1;
    this.queryParams.limit = 10;
    this.queryParams.search = '';
    this.queryParams.cateId = '0';
    this.queryParams.sort = undefined;
    this.setQueryParams(this.queryParams);
  },
};
</script>

<style lang="less" scoped>
.goods {
  background-color: #f5f5f5;
  // 分类css
  .nav {
    background-color: white;
    .goodsList-nav {
      width: 1225px;
      height: 40px;
      line-height: 40px;
      margin: 0 auto;
      .title {
        width: 50px;
        font-size: 16px;
        font-weight: 700;
        float: left;
      }
    }
  }
  // 主体
  .main {
    margin: 0 auto;
    max-width: 1225px;
    .goodsListBox {
      min-height: 650px;
      padding-top: 14.5px;
      margin-left: -13.7px;
      overflow: auto;
    }
    .pagination {
      height: 50px;
      text-align: center;
    }
    .none-goodsList {
      color: #333;
      margin-left: 13.7px;
    }
  }
}
/* 筛选 */
.order-box {
  border-radius: 5px;
  padding: 10px 30px 20px 20px;
  .order {
    display: flex; //弹性盒子
    font-size: 15px;
    .item {
      align-items: center; //侧轴方向居中对齐
      margin: 0 10px;
      cursor: pointer; //获取焦点时呈现鼠标手
      &.active {
        color: #5683ea;
      }
    }
  }
}
</style>
