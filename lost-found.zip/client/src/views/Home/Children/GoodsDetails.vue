<template>
  <!-- 详情界面 -->
  <div class="w store-content" v-loading="loading" element-loading-text="loading...">
    <!-- 上边产品信息 -->
    <div class="gray-box">
      <!-- 左边图片 -->
      <div class="gallery-wrapper">
        <img class="gallery" :src="goodsInfo.image" />
      </div>
      <!--右边详情-->
      <div class="banner">
        <div class="info-box">
          <div class="top-info clearfix" v-if="goodsInfo.User && goodsInfo.User.Info">
            <span class="avatar ivu-avatar"><img :src="goodsInfo.User.Info.image" /></span
            ><span class="username">{{ goodsInfo.User.Info.nikeName }}</span>
          </div>
          <div class="title">
            <span>{{ goodsInfo.goodsName }}</span>
          </div>
          <div class="info-item" v-if="goodsInfo.User && goodsInfo.User.Info">
            <div class="t-title">
              <i class="fa fa-map-marker fa-2x" aria-hidden="true"></i>
            </div>
            <div>
              <span>{{ goodsInfo.User.Info.address }}</span>
            </div>
          </div>
          <div class="info-item" v-if="goodsInfo.User && goodsInfo.User.Info">
            <div class="t-title">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </div>
            <div>
              <span>{{ goodsInfo.createTime | dateFormat }}</span>
            </div>
          </div>
          <div class="info-item" v-if="goodsInfo.User && goodsInfo.User.Info">
            <div class="t-title">
              <i class="fa fa-commenting-o" aria-hidden="true"></i>
            </div>
            <div>
              <div>
                <span class="contact-type">{{ goodsInfo.User.Info.phone }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="buy" v-if="goodsInfo.claimStatus !== 1 && goodsInfo.findStatus !== 1">
          <el-button type="primary" @click="addCart()" v-if="goodsInfo.claimStatus !== -1"
            >申请认领</el-button
          >
          <el-button type="primary" @click="addCart()" v-else>申请归还</el-button>
        </div>
      </div>
    </div>
    <!--下边产品动态信息-->
    <div class="item-info">
      <Shelf title="详情描述" v-if="goodsInfo.introduce">
        <div slot="content" class="contentBox">{{ goodsInfo.introduce }}</div>
      </Shelf>
    </div>
  </div>
</template>

<script>
import Shelf from '@/common/Shelf'; //产品动态信息
import { mapState, mapActions, mapMutations } from 'vuex';
export default {
  data() {
    return {
      loading: false,
    };
  },
  components: {
    Shelf,
  },

  async created() {
    const { goodsId } = this.$route.query;
    if (!goodsId) {
      this.notifyError('物品id获取失败!');
      return;
    }
    this.loading = true;
    await this.reqGoodsInfo(goodsId);
    this.loading = false;
  },
  computed: {
    ...mapState(['goodsInfo', 'isLogin', 'userInfo']),
  },
  methods: {
    ...mapActions(['reqAddCartInfo', 'reqGoodsInfo']),
    ...mapMutations(['setGoodsInfo']),
    addCart() {
      if (!this.isLogin) return this.notifyInfo('请先进行登录操作!');
      if (this.userInfo.id == this.goodsInfo.uid) {
        return this.notifyWarn('不能申请操作自己发布的物品!');
      }
      if (this.userInfo?.Info.status !== 1) {
        return this.notifyInfo(
          '请先前往个人中心进行实名认证，发布信息需要先进行是实名认证'
        );
      }
      this.$router.push({
        path: '/claimGoods',
        query: { goodsId: this.goodsInfo.id, redirect: this.$route.fullPath },
      });
    },
  },
  beforeDestroy() {
    this.setGoodsInfo({});
  },
};
</script>

<style lang="less" scoped>
.store-content {
  clear: both;
  width: 1080px;
  min-height: 630px;
  padding: 0 0 25px;
  margin: 0 auto;
  .breadcrumb {
    height: 25px;
    background-color: white;
    .el-breadcrumb {
      width: 1225px;
      line-height: 45px;
      font-size: 16px;
      margin: 0 auto;
    }
  }
  // 上边
  .gray-box {
    display: flex; //弹性盒子
    align-items: center;
    padding: 60px;
    margin: 20px 0;
    overflow: hidden;
    background: #fff;
    border-radius: 8px;
    border: 1px solid #dcdcdc;
    border-color: rgba(0, 0, 0, 0.14);
    box-shadow: 0 3px 8px -6px rgb(0 0 0 / 10%);
    // 左边
    .gallery-wrapper {
      width: 640px;
      text-align: center;
      img {
        width: 45%;
      }
    }
    // 右边
    .banner {
      width: 450px;
      margin-left: 10px;
      .info-box {
        padding-left: 30px;
        width: 590px;
        font-size: 14px;
        .top-info {
          display: flex;
          align-items: center;
          font-size: 14px;
          .avatar,
          .dev-time,
          .username {
            margin-right: 8px;
            font-size: 14px;
          }
          .ivu-avatar {
            display: inline-block;
            text-align: center;
            background: #ccc;
            color: #fff;
            white-space: nowrap;
            position: relative;
            overflow: hidden;
            vertical-align: middle;
            width: 32px;
            height: 32px;
            line-height: 16px;
            border-radius: 16px;
            img {
              width: 100%;
              height: 100%;
              border-style: none;
            }
          }
        }
        .title {
          margin: 12px 0;
          color: #17233d;
          font-weight: 700;
          font-size: 16px;
        }
        .content {
          color: #616776;
        }
        .info-item {
          display: flex;
          align-items: center;
          margin-top: 15px;
          color: #616776;
          .t-title {
            font-size: 14px;
            margin-right: 15px;
          }
          .price {
            color: #f01414;
          }
          .fa-clock-o {
            font-size: 1.5em;
          }
          .fa-commenting-o {
            font-size: 1.3em;
          }
        }
      }
      .params-name {
        padding-right: 20px;
        font-size: 14px;
        color: #616776;
        line-height: 36px;
      }
      .num {
        margin-top: 10px;
        padding: 10px 0 10px 26px;
        border-top: 1px solid #ebebeb;
      }
      .buy {
        position: relative;
        border-top: 1px solid #ebebeb;
        padding: 26px 0 0 22px;
      }
    }
  }
  // 下边
  .item-info {
    .gray-box {
      padding: 0;
      display: block;
    }
    .contentBox {
      padding: 24px;
      font-size: 16px;
    }
  }
}
</style>
