//通知提示组件

import Vue from 'vue'
// 封装提示成功的弹出框
Vue.prototype.notifySuccess = function (msg) {
  this.$notify.success({
    title: '成功',
    message: msg,
    offset: 100, //通知位置偏移量
    duration: 2000 //通知显示时间
  })
}
// 封装提示失败的弹出框
Vue.prototype.notifyError = function (msg) {
  this.$notify.error({
    title: '错误',
    message: msg,
    offset: 100,
    duration: 2000
  })
}

// 封装提示警告的弹出框
Vue.prototype.notifyWarn = function (msg) {
  this.$notify.warning({
    title: '警告',
    message: msg,
    offset: 100,
    duration: 2000
  })
}

// 封装提示警告的弹出框
Vue.prototype.notifyInfo = function (msg) {
  this.$notify.info({
    title: '提示',
    message: msg,
    offset: 100,
    duration: 2000
  })
}
