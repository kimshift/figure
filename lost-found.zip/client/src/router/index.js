import Vue from 'vue'
import VueRouter from 'vue-router'

//声明使用
Vue.use(VueRouter)

// 解决路由命名冲突的方法，避免在路由跳转时因为重复触发相同的路由而可能导致的错误
// 保存原始的VueRouter的push方法
const routerPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location, onResolve, onReject) {
  // 如果提供了解决或拒绝的回调函数，则使用原始的push方法
  if (onResolve || onReject) return routerPush.call(this, location, onResolve, onReject)
  return routerPush.call(this, location).catch(error => error)
}
// 保存原始的VueRouter的replace方法
const routerReplace = VueRouter.prototype.replace
VueRouter.prototype.replace = function replace(location) {
  return routerReplace.call(this, location).catch(err => err)
}

// 异步加载路由组件
// 首页平台界面路由
const Home = () => import('../views/Home') //首页
const Forum = () => import('../views/Forum') //论坛
const ForumDetails = () => import('../views/Forum/details') //论坛详情
const About = () => import('../views/About') //关于
const Goods = () => import('../views/Home/Children/Goods.vue') //全部物品展示页
const LostGoods = () => import('../views/Home/Children/LostGoods.vue') //失物物品展示页
const FindGoods = () => import('../views/Home/Children/FindGoods.vue') //拾物物品展示页
const GoodsDetails = () => import('../views/Home/Children/GoodsDetails.vue') //物品详情页
const CreateInfo = () => import('../views/Home/Children/CreateGoods.vue') //发布消息

/* 认领-换物申请流程 */
const ClaimGoods = () => import('../views/Transaction/ClaimGoods.vue') //申请认领

/* 管理员后台管理 */
const AdminLogin = () => import('../views/Login/index.vue') //管理员单独的登录页面
const Admin = () => import('../views/Admin/index.vue') //管理员后台导航父组件
const Info = () => import('../views/Admin/Children/users/Info.vue') //默认首页子组件
const Users = () => import('../views/Admin/Children/users/Users.vue') //用户管理

/* 物品管理 */
const CateList = () => import('../views/Admin/Children/goods/CateList.vue') //分类列表
const LostGoodsList = () => import('../views/Admin/Children/goods/LostGoodsList.vue') //丢失物品列表
const NeedGoodsList = () => import('../views/Admin/Children/goods/NeedGoodsList.vue') //急需物品列表
const FindGoodsList = () => import('../views/Admin/Children/goods/FindGoodsList.vue') //拾取物品列表
const CreateGoods = () => import('../views/Admin/Children/goods/CreateGoods.vue') //发布物品
const GoodsInfo = () => import('../views/Admin/Children/goods/GoodsInfo.vue') //物品详情
const AuthClaimList = () => import('../views/Admin/Children/claim/ClaimGoodsList.vue') //认领审核列表
const AuthGiveList = () => import('../views/Admin/Children/claim/GiveGoodsList.vue') //归还审核列表
const DockClaimList = () => import('../views/Admin/Children/dock/ClaimDockList.vue') //失物认领交接列表
const DockGiveList = () => import('../views/Admin/Children/dock/GiveDockList.vue') //拾物归还交接列表
const SlideshowList = () => import('../views/Admin/Children/system/SlideshowList.vue') //轮播图列表
const SlideshowInfo = () => import('../views/Admin/Children/system/SlideshowInfo.vue') //轮播图发布
const CommentList = () => import('../views/Admin/Children/system/commentList.vue') //评论列表
const IssuesList = () => import('../views/Admin/Children/system/issuesList.vue') //留言列表

// 404界面
const Error = () => import('../views/Error/index.vue')

//配置路由规则
const routes = [
  {
    path: '/',
    redirect: '/home',
  },
  {
    path: '/home',
    name: '首页',
    component: Home,
  },
  {
    path: '/forum',
    name: '论坛',
    component: Forum,
    meta: { hideHeaderNav: true, hideFooter: true },
  },
  {
    path: '/forum_details/:id',
    name: '论坛',
    component: ForumDetails,
    meta: { hideHeaderNav: true, hideFooter: true },
  },
  {
    path: '/about',
    name: '公告和留言',
    component: About,
    meta: { hideHeaderNav: true },
  },
  {
    path: '/allGoods',
    name: '全部物品',
    component: Goods,
  },
  {
    path: '/lostGoods',
    name: '失物',
    component: LostGoods,
  },
  {
    path: '/findGoods',
    name: '拾物',
    component: FindGoods,
  },
  {
    path: '/goodsInfo',
    name: '物品详情',
    component: GoodsDetails,
  },
  {
    path: '/createGoods',
    name: '信息发布中心',
    component: CreateInfo,
    meta: { login: true, hideHeaderNav: true },
  },

  {
    path: '/claimGoods',
    name: '申请流程',
    component: ClaimGoods,
    meta: { login: true },
  },
  {
    // 管理员端
    path: '/admin',
    name: 'Admin',
    component: Admin,
    children: [
      // /admin路由下的二级路由==>拼接全路由为：/admin/home
      { path: 'home', name: '个人中心', component: Info },
      { path: 'users', name: '用户列表', component: Users },
      { path: 'lostGoods', name: '失物列表', component: LostGoodsList },
      { path: 'needGoods', name: '急需列表', component: NeedGoodsList },
      { path: 'collectGoods', name: '拾物列表', component: FindGoodsList },
      { path: 'goods/create', name: '发布信息', component: CreateGoods },
      { path: 'goods/update', name: '编辑物品', component: GoodsInfo },
      { path: 'goods/view', name: '查看物品', component: GoodsInfo },
      { path: 'category', name: '分类列表', component: CateList },
      { path: 'claim', name: '认领审核列表', component: AuthClaimList },
      { path: 'give', name: '归还审核列表', component: AuthGiveList },
      { path: 'claimDock', name: '失物寻回列表', component: DockClaimList },
      { path: 'giveDock', name: '拾物归还列表', component: DockGiveList },
      { path: 'slideshow', name: '轮播图列表', component: SlideshowList },
      { path: 'commentList', name: '评论列表', component: CommentList },
      { path: 'issuesList', name: '留言列表', component: IssuesList },
      {
        path: 'slideshow/create',
        name: '发布轮播图',
        component: SlideshowInfo,
      },
      {
        path: 'slideshow/update',
        name: '编辑轮播图',
        component: SlideshowInfo,
      },
      { path: '/admin', redirect: '/admin/home' }, //路由重定向，默认显示个人中心
    ],
    // 需要守卫
    meta: {
      auth: true,
      login: true,
      hideHeaderNav: true,
      hideHeaderTop: true,
      hideFooter: true,
    },
  },
  {
    path: '/login',
    component: AdminLogin,
    meta: { hideHeaderNav: true, hideHeaderTop: true },
  },
  //404界面
  {
    path: '/notfound',
    name: '页面不存在',
    component: Error,
    meta: { hideHeaderNav: true, hideHeaderTop: true, hideFooter: true },
  },
  {
    path: '*', // 页面不存在的情况下会跳到404页面
    redirect: '/notfound',
    name: 'notFound',
    hidden: true,
  },
]
//导出路由对象
//改成history模式
export default new VueRouter({
  mode: 'history',
  routes,
})
