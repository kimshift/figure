//axios二次封装

/**
 * 接收响应数据有两种方式
 * 1.使用链式操作来接收.then(res=>{}).catch(err=>{})
 * 2.使用async await来接收建议外层搭配上try catch
 */

import axios from 'axios'
import qs from 'qs' //引入qs库，用于将对象序列化成URL的查询字符串，用于POST请求的数据
axios.defaults.timeout = 30000 //设置超时时间
axios.defaults.withCredentials = true //允许跨域携带凭证
axios.defaults.headers['Access-Control-Allow-Origin'] = '*' //设置响应头，允许任何源访问资源
axios.defaults.headers['Access-Control-Allow-Methods'] =
  'GET, POST, PATCH, PUT, DELETE, OPTIONS' //设置允许的HTTP请求方法
axios.defaults.headers['Access-Control-Allow-Headers'] =
  'Origin, Content-Type, X-Auth-Token' //设置允许的HTTP请求头
axios.defaults.headers.get['X-Requested-With'] = 'XMLHttpRequest' //设置GET请求标识，表明这是一个Ajax请求
axios.defaults.headers.post['X-Requested-With'] = 'XMLHttpRequest' //设置POST请求标识
axios.defaults.headers.post['Content-Type'] =
  'application/x-www-form-urlencoded;charset=utf-8' //设置POST请求的内容类型，用于解决请求参数获取不到的问题
axios.defaults.headers.post['Accept'] = 'application/json' //设置POST请求期望返回的数据类型为JSON
axios.defaults.headers.put['X-Requested-With'] = 'XMLHttpRequest' //设置PUT请求标识
axios.defaults.headers.delete['X-Requested-With'] = 'XMLHttpRequest' //设置DELETE请求标识

/* axios请求拦截器 */
axios.interceptors.request.use((config) => {
  let user = window.sessionStorage.getItem('userInfo')
  const token = window.sessionStorage.getItem('token')
  try {
    if (user) {
      user = JSON.parse(user)
      config.headers.get['userId'] = user.id
      config.headers.post['userId'] = user.id
      config.headers.put['userId'] = user.id
      config.headers.delete['userId'] = user.id
    }
    /* 携带token值 */
    if (token) {
      config.headers.Authorization = token
    }
    //get请求添加附带时间戳参数
    if (config.method == 'get') {
      config.params = {
        ...config.params,
        _t: Date.parse(new Date()) / 1000
      }
    }
  } catch (error) {
    console.log('请求异常:', error)
  } finally {
    return config
  }
})

/* axios响应拦截器 */
axios.interceptors.response.use(
  (res) => {
    return res.data
  },
  (error) => {
    const { response } = error
    if (response) {
      let message = ''
      switch (response.status) {
        case 401: //服务器认证失败
          message = '权限异常：401'
          break
        case 403: //服务器拒绝访问（token过期了）
          message = '服务器拒绝执行/token过期了：403'
          break
        case 404: //地址错了
          message = '请求失败：404'
          break
        case 500: //服务器遇到意外
          message = 'Internal Server Error'
          break
        default:
          message = '系统繁忙,请联系管理员！'
          console.log('服务器异常响应:', response)
      }
      return { code: 500, data: null, message }
    } else {
      if (!window.navigator.onLine) {
        return Promise.reject(response)
      }
      return Promise.reject(response)
    }
  }
)
export default axios //默认导出原对象

/*******
 * @description: 对 (get post put delete) 方法进行二次封装
 * @author: Mr.Ye
 * @param {url} 请求路径
 * @param {formData} 请求数据体/body参数
 * @param {params}
 * @param {config} 请求头参数
 * @return {Promise} 服务器响应后再二次处理好的Promise对象
 */

/* 增 */
/**
 * 默认'Content-Type': 'application/json'，可在头部参数config中，修改Content-Type
 */
export const post = (url, formData, params, config = {}) => {
  return new Promise((resolve, reject) => {
    axios
      .post(url, formData, { params: params, ...config })
      .then((res) => {
        resolve(res)
      })
      .catch((err) => {
        reject(err)
      })
  })
}

/* 删 */
export const remove = (url, params, config = {}) => {
  return new Promise((resolve, reject) => {
    axios
      .delete(url, { params: params, ...config })
      .then((res) => {
        resolve(res)
      })
      .catch((err) => {
        reject(err)
      })
  })
}

/* 改 */
export const update = (url, formData, params, config = {}) => {
  return new Promise((resolve, reject) => {
    axios
      .put(url, formData, { params: params, ...config })
      .then((res) => {
        resolve(res)
      })
      .catch((err) => {
        reject(err)
      })
  })
}

/* 查 */
export const query = (url, params, config = {}) => {
  return new Promise((resolve, reject) => {
    axios
      .get(url, { params: params, ...config })
      .then((res) => {
        resolve(res)
      })
      .catch((err) => {
        reject(err)
      })
  })
}

/* 表单形式提交:请求头config 上面已设置Content-Type默认application/x-www-form-urlencoded;charset=UTF-8 */
export const postForm = (url, formData, params, config = {}) => {
  return new Promise((resolve, reject) => {
    axios
      .post(url, qs.stringify(formData), { params: params, ...config })
      .then((res) => {
        resolve(res)
      })
      .catch((err) => {
        reject(err)
      })
  })
}
