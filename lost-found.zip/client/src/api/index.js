import axios, { query, post, update, remove } from './request'

axios.defaults.baseURL = '/api'

/*用户*/
// 账号登录
export const Login = params => post('/login', params)
//账号注册
export const Register = params => post('/register', params)
// 获取用户信息
export const getUserInfo = () => query('/userInfo')
// 修改用户信息
export const changeUserInfo = params => update('/public/user/update_info', params)
// 修改用户密码
export const changeUserPwd = params => update('/public/user/update_pwd', params)
// 更换头像
export const changeUserImage = params => update('/public/user/update_img', params)
// 用户申请实名认证
export const changeUserAuth = params => update('/update_auth', params)
// 修改用户状态
export const changeUserStatus = params =>
  update(`/admin/user/update_status/${params.id}/${params.status}`)
// 查询单个用户信息
export const queryUserInfo = params => query(`/admin/user/query/${params}`)
// 重置用户密码
export const resetPwd = params => update('/admin/user/reset_pwd', params)
// 审核实名申请
export const updateAuth = (id, params) => update(`/admin/user/update_auth/${id}`, params)

/*物品*/
export const getHomeGoodsList = params => query('/public/goods/home', params)
// 请求所有物品
export const getGoodsList = params => query('/public/goods', params)
// 修改物品状态
export const changeGoodsStatus = params =>
  update(`/public/goods/updateStatus/${params.id}/${params.status}`)
// 删除物品
export const removeGoodsInfo = params => remove(`/public/goods/delete/${params}`)
// 请求物品详细数据
export const getGoodsInfo = params => query(`/public/goods/query/${params}`)
// 发布物品
export const createGoods = params => post('/public/goods/create', params)
//修改物品信息
export const updateGoodsInfo = (params, id) => update(`/public/goods/update/${id}`, params)

/*物品分类*/
// 请求物品分类列表
export const getCateList = params => query('/public/cate', params)
// 新增分类
export const createCate = params => post('/admin/cate/create', params)
// 编辑分类
export const updateCate = params => update(`/admin/cate/update/${params.id}`, params)
// 查询分类
export const queryCateInfo = params => query(`/admin/cate/query/${params}`)
// 删除分类
export const removeCateInfo = params => remove(`/admin/cate/delete/${params}`)

/*首页相关*/
// 请求轮播图列表
export const getSlideshowList = params => query('/public/slideshow', params)
// 请求轮播图关联物品列表
export const getUserGoodsList = params => query('/public/goods', params)
// 修改轮播图状态
export const changeSlideshowStatus = params =>
  update(`/admin/slideshow/update_status/${params.id}/${params.status}`)
// 删除轮播图
export const removeSlideshowInfo = params => remove(`/admin/slideshow/delete/${params}`)
// 请求轮播图详细数据
export const getSlideshowInfo = params => query(`/public/slideshow/query/${params}`)
// 发布轮播图
export const createSlideshow = params => post('/admin/slideshow/create', params)
//修改轮播图信息
export const changeSlideshowInfo = (params, id) => update(`/admin/slideshow/update/${id}`, params)

/*认领-还物*/
// 申请操作
export const createClaim = (goodsId, params) => post(`/public/claim/create/${goodsId}`, params)
// 申请者查询申请列表
export const getClaimList = params => query('/public/claim', params)
// 删除认领数据
export const removeClaimInfo = params => post(`/public/claim/delete`, params)
// 查询申请数据
export const getClaimInfo = params => query(`/public/claim/query/${params}`)
// 修改申请数据
export const updateClaimInfo = (id, params) => update(`/public/claim/update/${id}`, params)
// 修改交接状态状态
export const changeClaimStatus = params => update(`/public/claim/updateStatus`, params)
// 审核数据
export const authClaimInfo = params => update(`/admin/claim/updateAuth`, params)

/*论坛相关*/
// 获取帖子列表
export const fetchPosts = params => query('/public/forum/posts', params)

// 创建新帖子
export const createPost = (data, userId) => post('/public/forum/posts', { ...data, uid: userId })

// 获取单个帖子详情
export const fetchPostDetail = id => query(`/public/forum/posts/${id}`)

// 为帖子添加评论
export const addComment = params => post(`/public/forum/posts/comments`, params)

// 获取帖子的评论列表
export const fetchComments = params => post(`/public/forum/posts/comments_list`, params)

// 回复评论
export const replyComment = params => post(`/public/forum/posts/comments/reply`, params)
// 删除评论
export const removeComment = params => remove(`/public/forum/posts/comments/delete/${params}`)

// 发表留言
export const postIssues = params => post(`/public/issues/create`, params)
// 回复留言
export const replyIssues = params => post(`/public/issues/reply`, params)
// 留言列表
export const fetchIssues = params => query(`/public/issues/list`, params)
// 删除留言
export const removeIssues = params => remove(`/public/issues/delete/${params}`)
