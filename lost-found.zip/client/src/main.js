import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import './plugins/element.js'
import './plugins/notifyTips'
import './plugins/filters'
// 导入全局样式表
import './assets/css/global.css'
// 引入字体样式
import 'font-awesome/css/font-awesome.min.css'
import { getUserInfo } from './api'

Vue.config.productionTip = false //关闭Vue在控制台显示生产提示

/* 路由守卫 */
router.beforeEach(async function (to, from, next) {
  const token = window.sessionStorage.getItem('token') //获取缓存token
  if (!token) {
    /* 检测路由是否需要守卫 :(auth:true则返回true,否则返回false)*/
    if (!to.matched.some((item) => item.meta.login)) return next() //token不存在且路由不需要守卫（路由放行）
    //token不存在但是路由需要守卫(路由重定向--->登录后返回原路由)
    if (to.matched.some((item) => item.meta.auth)) {
      return next({ path: '/login', query: { redirect: to.fullPath } })
    }
    Vue.prototype.$message({
      type: 'info',
      message: '请先进行登录!',
      duration: 2000,
      offset: 100
    })
    return next({ path: '/' })
  }
  try {
    //token存在,验证token信息
    const res = await getUserInfo('/userInfo')
    // console.log('验证信息:', res)
    if (res.code === 200) {
      /* token 验证成功 用户已登录 */
      if (res.data.status !== 1) {
        store.commit('syncLogout') //清除登录状态
        Vue.prototype.$message({
          type: 'error',
          message: '该账号已封停,如有疑问请联系管理员!'
        })
        return next({ path: '/' })
      }
      store.commit('syncUserInfo', res.data) //保存用户的信息
      if (!to.matched.some((item) => item.meta.auth)) return next() //不需要权限(放行)
      if (res.data.isAdmin) return next() //管理员有权限访问(放行)
      Vue.prototype.$message({ type: 'error', message: '权限不足,无法访问!' })
      return next({ path: `${from.fullPath}` }) //权限不足,拦截后原路径返回
    }
    /* token 验证失败 */
    store.commit('syncLogout') //清除登录状态
    if (!to.matched.some((item) => item.meta.auth)) return next() //路由不需要守卫
    if (!to.matched.some((item) => item.meta.auth)) {
      // token已失效但是路由需要守卫
      Vue.prototype.$message({
        type: 'info',
        message: '登录已失效,请重新登录!',
        duration: 2000,
        offset: 100
      })
      return next({ path: '/' })
    }
    /* token已失效但是路由需要守卫且访问的是管理员后台管理(路由重定向--->登录后返回原路由) */
    next({ path: '/login', query: { redirect: to.fullPath } })
  } catch (error) {
    console.log('路由守卫:', error)
    store.commit('syncLogout') //清除登录状态
    next({ path: '/' })
  }
})

new Vue({
  router,
  store,
  render: (h) => h(App) //渲染App组件
}).$mount('#app')
